const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/OneShot-Dxo89WPn.js","assets/vendor-9NzPy1Pf.js","assets/OneShot-C2s9ws0V.css","assets/NoPage-BMxcsfhS.js"])))=>i.map(i=>d[i]);
import{r as b,j as o,S as Tr,a as Nr,N as ra,I as so,b as ro,D as Ks,P as cs,u as jr,O as ia,c as io,T as ts,R as Js,d as er,e as ao,f as oo,g as Ge,h as jt,i as lo,C as Gn,k as co,l as si,M as Er,m as tt,L as aa,n as Yt,o as ho,p as uo,q as po,s as go,t as fo}from"./vendor-9NzPy1Pf.js";(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))s(r);new MutationObserver(r=>{for(const i of r)if(i.type==="childList")for(const a of i.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&s(a)}).observe(document,{childList:!0,subtree:!0});function t(r){const i={};return r.integrity&&(i.integrity=r.integrity),r.referrerPolicy&&(i.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?i.credentials="include":r.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function s(r){if(r.ep)return;r.ep=!0;const i=t(r);fetch(r.href,i)}})();const mo="modulepreload",yo=function(n){return"/"+n},ri={},ii=function(e,t,s){let r=Promise.resolve();if(t&&t.length>0){let a=function(h){return Promise.all(h.map(u=>Promise.resolve(u).then(g=>({status:"fulfilled",value:g}),g=>({status:"rejected",reason:g}))))};document.getElementsByTagName("link");const l=document.querySelector("meta[property=csp-nonce]"),c=(l==null?void 0:l.nonce)||(l==null?void 0:l.getAttribute("nonce"));r=a(t.map(h=>{if(h=yo(h),h in ri)return;ri[h]=!0;const u=h.endsWith(".css"),g=u?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${h}"]${g}`))return;const p=document.createElement("link");if(p.rel=u?"stylesheet":mo,u||(p.as="script"),p.crossOrigin="",p.href=h,c&&p.setAttribute("nonce",c),document.head.appendChild(p),u)return new Promise((v,w)=>{p.addEventListener("load",v),p.addEventListener("error",()=>w(new Error(`Unable to preload CSS for ${h}`)))})}))}function i(a){const l=new Event("vite:preloadError",{cancelable:!0});if(l.payload=a,window.dispatchEvent(l),!l.defaultPrevented)throw a}return r.then(a=>{for(const l of a||[])l.status==="rejected"&&i(l.reason);return e().catch(i)})};var vo=(n=>(n.RetrieveThenRead="rtr",n.ReadRetrieveRead="rrr",n.ReadDecomposeAsk="rda",n))(vo||{}),pt=(n=>(n.Hybrid="hybrid",n.Vectors="vectors",n.Text="text",n))(pt||{});const Z="https://apexcoachai-api.mangocoast-f4cc7159.eastus2.azurecontainerapps.io";async function bo(n){const e=await fetch(`${Z}/chats/${n}/messages`,{credentials:"include"});if(!e.ok)throw new Error("Failed to load chat messages");return e.json()}async function xo(){const n=await fetch(`${Z}/meta-prompts`,{credentials:"include"});if(!n.ok)throw new Error("Failed to load personalities");return n.json()}async function _o(){const n=await fetch(`${Z}/me/settings`,{credentials:"include"});if(!n.ok)throw new Error("Failed to load settings");return n.json()}async function wo(n){const e=await fetch(`${Z}/me/settings`,{method:"PUT",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify(n)});if(!e.ok)throw new Error("Failed to update settings");return e.json()}const oa=b.createContext(void 0);function Co({children:n}){const[e,t]=b.useState(void 0),[s,r]=b.useState(!0);b.useEffect(()=>{async function u(){try{const g=await fetch(`${Z}/auth/me`,{credentials:"include"});if(g.ok){const p=await g.json();t(p.user)}}catch(g){console.error("Auth check failed:",g)}finally{r(!1)}}u()},[]);const i=async(u,g)=>{const p=await fetch(`${Z}/auth/login`,{method:"POST",headers:{"Content-Type":"application/json"},credentials:"include",body:JSON.stringify({email:u,password:g})});if(!p.ok){const w=await p.json();throw new Error(w.error||"Login failed")}const v=await p.json();t(v.user)},a=async()=>{const u=await fetch(`${Z}/auth/demo-login`,{method:"POST",headers:{"Content-Type":"application/json"},credentials:"include"});if(!u.ok){const p=await u.json();throw new Error(p.error||"Demo login failed")}const g=await u.json();t(g.user)},l=async u=>{const g=await fetch(`${Z}/auth/demo-login`,{method:"POST",headers:{"Content-Type":"application/json"},credentials:"include",body:JSON.stringify({role:u})});if(!g.ok){const v=await g.json();throw new Error(v.error||"Demo login failed")}const p=await g.json();t(p.user)},c=async(u,g,p)=>{const v=await fetch(`${Z}/auth/signup`,{method:"POST",headers:{"Content-Type":"application/json"},credentials:"include",body:JSON.stringify({email:u,password:g,name:p})});if(!v.ok){const L=await v.json();throw new Error(L.error||"Signup failed")}const w=await v.json();t(w.user)},h=async()=>{await fetch(`${Z}/auth/logout`,{method:"POST",credentials:"include"}),t(void 0)};return o.jsx(oa.Provider,{value:{user:e,login:i,demoLogin:a,demoLoginWithRole:l,signup:c,logout:h,loading:s},children:n})}function fn(){const n=b.useContext(oa);if(n===void 0)throw new Error("useAuth must be used within an AuthProvider");return n}const la=b.createContext(void 0);function ko({children:n}){const[e,t]=b.useState([]),[s,r]=b.useState(),[i,a]=b.useState(!0),[l,c]=b.useState(void 0);return b.useEffect(()=>{async function h(){try{const g=(await xo()).metaPrompts||[];t(g);const p=g.find(v=>v.isDefault);p?r(p.id):g.length>0&&r(g[0].id)}catch(u){console.error("Failed to load personalities:",u),c("Failed to load personalities")}finally{a(!1)}}h()},[]),o.jsx(la.Provider,{value:{personalities:e,selectedPersonalityId:s,setSelectedPersonalityId:r,isLoading:i,error:l},children:n})}function ca(){const n=b.useContext(la);if(n===void 0)throw new Error("usePersonality must be used within a PersonalityProvider");return n}function So({children:n}){const{user:e,loading:t}=fn();return t?o.jsx("div",{style:{display:"flex",justifyContent:"center",alignItems:"center",height:"100vh"},children:o.jsx(Tr,{size:Nr.large,label:"Loading..."})}):e?o.jsx(o.Fragment,{children:n}):o.jsx(ra,{to:"/login",replace:!0})}const Yn=[{title:"Welcome to Apex Coach AI",description:"Transform your coaching content into an interactive AI expert. This tour will guide you through the key features of the platform.",icon:"WavingHand"},{title:"Chat with Your AI Coach",description:"Start a conversation with your AI coaching assistant. Ask questions and get personalized guidance backed by your content.",icon:"Chat",targetElement:"chat-interface"},{title:"Choose Your Coaching Style",description:"Select from multiple AI personalities that adapt to different coaching approaches. Switch between empathetic, analytical, or motivational styles.",icon:"Emoji2",targetElement:"personality-selector"},{title:"Library & Knowledge Base",description:"Upload and manage your coaching content. Videos, documents, and training materials are indexed to power your AI coach.",icon:"Library",targetElement:"library-link"},{title:"Programs & Access Control",description:"Organize content into structured programs. Assign clients and coaches to specific programs for controlled access.",icon:"Group",targetElement:"programs-link"},{title:"Ready to Get Started!",description:"You are all set! Begin by uploading your content or start chatting with your AI coach. You can always replay this tour from the settings menu.",icon:"Rocket"}],Ao=({onComplete:n,onSkip:e})=>{const[t,s]=b.useState(0),[r,i]=b.useState(null),a=Yn[t],l=t===Yn.length-1,c=t===0;b.useEffect(()=>{if(a.targetElement){const g=document.querySelector(`[data-tour="${a.targetElement}"]`);if(g){const p=g.getBoundingClientRect();i({top:p.top+window.scrollY,left:p.left+window.scrollX,width:p.width,height:p.height}),g.scrollIntoView({behavior:"smooth",block:"center"})}else i(null)}else i(null)},[t,a.targetElement]);const h=()=>{l?n():s(g=>g+1)},u=()=>{c||s(g=>g-1)};return o.jsxs(o.Fragment,{children:[o.jsx("div",{className:"fixed inset-0 bg-black bg-opacity-50 z-[60]",onClick:e}),r&&o.jsx("div",{className:"fixed z-[60] border-4 border-blue-500 rounded-lg pointer-events-none",style:{top:`${r.top-8}px`,left:`${r.left-8}px`,width:`${r.width+16}px`,height:`${r.height+16}px`,boxShadow:"0 0 0 99999px rgba(0, 0, 0, 0.5)"}}),o.jsxs("div",{className:"fixed z-[70] bg-white rounded-lg shadow-2xl max-w-md w-full mx-4",style:{top:"20vh",left:"50%",transform:"translateX(-50%)"},children:[o.jsx("div",{className:"absolute top-4 right-4",children:o.jsx(so,{iconProps:{iconName:"Cancel"},onClick:e,title:"Close tour"})}),o.jsxs("div",{className:"p-8",children:[o.jsx("div",{className:"flex justify-center mb-6",children:o.jsx("div",{className:"w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center",children:o.jsx(ro,{iconName:a.icon,style:{fontSize:32,color:"#0078D4"}})})}),o.jsx("h2",{className:"text-2xl font-bold text-center mb-4",children:a.title}),o.jsx("p",{className:"text-gray-600 text-center mb-6",children:a.description}),o.jsx("div",{className:"flex justify-center gap-2 mb-6",children:Yn.map((g,p)=>o.jsx("div",{className:`h-2 rounded-full transition-all ${p===t?"w-8 bg-blue-500":"w-2 bg-gray-300"}`},p))}),o.jsxs("div",{className:"flex justify-between items-center",children:[o.jsx("div",{children:!c&&o.jsx(Ks,{text:"Previous",onClick:u})}),o.jsxs("div",{className:"flex gap-2",children:[o.jsx(Ks,{text:"Skip Tour",onClick:e}),o.jsx(cs,{text:l?"Get Started":"Next",onClick:h,iconProps:l?{iconName:"Rocket"}:{iconName:"ChevronRight"}})]})]}),o.jsxs("div",{className:"text-center text-sm text-gray-500 mt-4",children:["Step ",t+1," of ",Yn.length]})]})]})]})},To=({onClose:n})=>{const[e,t]=b.useState(void 0),[s,r]=b.useState(!1),i=async()=>{r(!0),t(void 0);try{const c=await fetch(`${Z}/me/export-data`,{method:"POST",credentials:"include"});if(!c.ok)throw new Error(`Failed to export data: ${c.statusText}`);const h=await c.blob(),u=window.URL.createObjectURL(h),g=document.createElement("a");g.href=u,g.download="export.json",document.body.append(g),g.click(),g.remove(),window.URL.revokeObjectURL(u)}catch(c){t(c instanceof Error?c.message:"Failed to export data")}finally{r(!1)}},a=async()=>{if(window.confirm("Are you sure you want to delete all your chats? This action cannot be undone.")){r(!0),t(void 0);try{const c=await fetch(`${Z}/me/delete-all-chats`,{method:"POST",credentials:"include"});if(!c.ok)throw new Error(`Failed to delete chats: ${c.statusText}`);window.location.reload()}catch(c){t(c instanceof Error?c.message:"Failed to delete chats"),r(!1)}}},l=async()=>{if(window.confirm("Are you sure you want to delete your account? This action cannot be undone.")){r(!0),t(void 0);try{const c=await fetch(`${Z}/me/delete-account`,{method:"POST",credentials:"include"});if(!c.ok)throw new Error(`Failed to delete account: ${c.statusText}`);window.location.href="/#/login"}catch(c){t(c instanceof Error?c.message:"Failed to delete account"),r(!1)}}};return o.jsx("div",{className:"fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50",children:o.jsxs("div",{className:"bg-white p-8 rounded-lg max-w-md w-full mx-4 shadow-xl",children:[o.jsx("h2",{className:"text-2xl font-bold mb-4",children:"Data & Privacy"}),e&&o.jsx("div",{className:"mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded",children:e}),o.jsxs("div",{className:"mb-6 space-y-3",children:[o.jsx("p",{className:"text-gray-600 mb-4",children:"Manage your data and account settings."}),o.jsx("button",{onClick:i,className:"w-full bg-blue-500 text-white p-3 rounded hover:bg-blue-600 disabled:opacity-50 transition-colors",disabled:s,children:s?"Processing...":"Export My Data"}),o.jsx("button",{onClick:a,className:"w-full bg-red-500 text-white p-3 rounded hover:bg-red-600 disabled:opacity-50 transition-colors",disabled:s,children:s?"Processing...":"Delete All Chats"}),o.jsx("button",{onClick:l,className:"w-full bg-red-700 text-white p-3 rounded hover:bg-red-800 disabled:opacity-50 transition-colors",disabled:s,children:s?"Processing...":"Delete Account"})]}),o.jsx("button",{onClick:n,className:"w-full bg-gray-200 text-gray-700 p-3 rounded hover:bg-gray-300 transition-colors",disabled:s,children:"Close"})]})})},No="_appShell_x00la_1",jo="_sidebar_x00la_13",Eo="_sidebarHeader_x00la_39",Io="_logo_x00la_51",$o="_brandName_x00la_79",Ro="_newChatButton_x00la_93",Oo="_sidebarNav_x00la_129",Po="_navSection_x00la_139",Lo="_navSectionTitle_x00la_147",Do="_mainContent_x00la_165",Mo="_sidebarFooter_x00la_181",Bo="_userInfo_x00la_193",Ho="_userName_x00la_201",Uo="_logoutButton_x00la_235",zo="_chatsList_x00la_269",Fo="_chatItem_x00la_281",qo="_loadingChats_x00la_319",Vo="_noChats_x00la_321",Wo="_navSectionButton_x00la_335",Go="_adminButton_x00la_389",oe={appShell:No,sidebar:jo,sidebarHeader:Eo,logo:Io,brandName:$o,newChatButton:Ro,sidebarNav:Oo,navSection:Po,navSectionTitle:Lo,mainContent:Do,sidebarFooter:Mo,userInfo:Bo,userName:Ho,logoutButton:Uo,chatsList:zo,chatItem:Fo,loadingChats:qo,noChats:Vo,navSectionButton:Wo,adminButton:Go},Yo=()=>{const{user:n,logout:e}=fn(),t=jr(),[s,r]=b.useState([]),[i,a]=b.useState(!1),[l,c]=b.useState(!1),[h,u]=b.useState(!1);function g(){return/Mobi|Android|iPhone|iPad|iPod|BlackBerry|Windows Phone/i.test(navigator.userAgent)}b.useEffect(()=>{if(!localStorage.getItem("onboarding_completed")){let R=function(){const D=g()?1200:500;setTimeout(()=>{u(!0)},D)};document.readyState==="complete"?R():window.addEventListener("load",R,{once:!0})}},[]),b.useEffect(()=>{p()},[]),b.useEffect(()=>{const B=()=>{p()};return window.addEventListener("chat-created",B),()=>{window.removeEventListener("chat-created",B)}},[]);const p=async()=>{a(!0);try{const B=await fetch(`${Z}/chats`,{credentials:"include"});if(B.ok){const R=await B.json();r(R.chats)}}catch(B){console.error("Failed to fetch chats:",B)}finally{a(!1)}},v=()=>{t("/"),setTimeout(()=>{p()},500)},w=B=>{t(`/?chatId=${B}`)},L=async()=>{await e(),t("/login")},U=()=>{localStorage.setItem("onboarding_completed","true"),u(!1)},Q=()=>{localStorage.setItem("onboarding_completed","true"),u(!1)};return o.jsxs("div",{className:oe.appShell,children:[o.jsxs("aside",{className:oe.sidebar,children:[o.jsxs("div",{className:oe.sidebarHeader,children:[o.jsx("div",{className:oe.logo,children:"AC"}),o.jsx("h2",{className:oe.brandName,children:"Apex Coach AI"})]}),o.jsx("button",{className:oe.newChatButton,type:"button","aria-label":"Start a new chat conversation",onClick:v,children:"+ New Chat"}),o.jsxs("nav",{className:oe.sidebarNav,children:[o.jsxs("div",{className:oe.navSection,children:[o.jsx("h3",{className:oe.navSectionTitle,children:"Chats"}),i?o.jsx("div",{className:oe.loadingChats,children:"Loading..."}):s.length>0?o.jsx("div",{className:oe.chatsList,children:s.map(B=>o.jsx("button",{className:oe.chatItem,onClick:()=>w(B.id),type:"button",children:B.title},B.id))}):o.jsx("div",{className:oe.noChats,children:"No chats yet"})]}),o.jsxs("div",{className:oe.navSection,children:[o.jsx("h3",{className:oe.navSectionTitle,children:"Settings"}),o.jsx("button",{className:oe.navSectionButton,onClick:()=>t("/settings"),type:"button",children:"Profile & Preferences"}),o.jsx("button",{className:oe.navSectionButton,onClick:()=>c(!0),type:"button",children:"Data & Privacy"}),o.jsx("button",{className:oe.navSectionButton,onClick:()=>u(!0),type:"button",children:"Replay Tour"})]})]}),o.jsxs("div",{className:oe.sidebarFooter,children:[o.jsx("div",{className:oe.userInfo,children:o.jsx("span",{className:oe.userName,children:(n==null?void 0:n.name)||(n==null?void 0:n.email)})}),(n==null?void 0:n.role)==="admin"&&o.jsx("button",{className:oe.adminButton,onClick:()=>t("/admin"),type:"button",children:"⚙️ Admin Panel"}),o.jsx("button",{className:oe.logoutButton,onClick:L,type:"button",children:"Logout"})]})]}),o.jsx("main",{className:oe.mainContent,children:o.jsx(ia,{})}),l&&o.jsx(To,{onClose:()=>c(!1)}),h&&o.jsx(Ao,{onComplete:U,onSkip:Q})]})};var Zo=Object.defineProperty,da=n=>{throw TypeError(n)},Xo=(n,e,t)=>e in n?Zo(n,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):n[e]=t,_=(n,e,t)=>Xo(n,typeof e!="symbol"?e+"":e,t),Ir=(n,e,t)=>e.has(n)||da("Cannot "+t),ae=(n,e,t)=>(Ir(n,e,"read from private field"),t?t.call(n):e.get(n)),yt=(n,e,t)=>e.has(n)?da("Cannot add the same private member more than once"):e instanceof WeakSet?e.add(n):e.set(n,t),mt=(n,e,t,s)=>(Ir(n,e,"write to private field"),e.set(n,t),t),tr=(n,e,t)=>(Ir(n,e,"access private method"),t),ai=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{},oi={};/*! *****************************************************************************
Copyright (C) Microsoft. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */var li;function Qo(){if(li)return oi;li=1;var n;return(function(e){(function(t){var s=typeof globalThis=="object"?globalThis:typeof ai=="object"?ai:typeof self=="object"?self:typeof this=="object"?this:c(),r=i(e);typeof s.Reflect<"u"&&(r=i(s.Reflect,r)),t(r,s),typeof s.Reflect>"u"&&(s.Reflect=e);function i(h,u){return function(g,p){Object.defineProperty(h,g,{configurable:!0,writable:!0,value:p}),u&&u(g,p)}}function a(){try{return Function("return this;")()}catch{}}function l(){try{return(0,eval)("(function() { return this; })()")}catch{}}function c(){return a()||l()}})(function(t,s){var r=Object.prototype.hasOwnProperty,i=typeof Symbol=="function",a=i&&typeof Symbol.toPrimitive<"u"?Symbol.toPrimitive:"@@toPrimitive",l=i&&typeof Symbol.iterator<"u"?Symbol.iterator:"@@iterator",c=typeof Object.create=="function",h={__proto__:[]}instanceof Array,u=!c&&!h,g={create:c?function(){return Vt(Object.create(null))}:h?function(){return Vt({__proto__:null})}:function(){return Vt({})},has:u?function(f,m){return r.call(f,m)}:function(f,m){return m in f},get:u?function(f,m){return r.call(f,m)?f[m]:void 0}:function(f,m){return f[m]}},p=Object.getPrototypeOf(Function),v=typeof Map=="function"&&typeof Map.prototype.entries=="function"?Map:zn(),w=typeof Set=="function"&&typeof Set.prototype.entries=="function"?Set:Fn(),L=typeof WeakMap=="function"?WeakMap:qn(),U=i?Symbol.for("@reflect-metadata:registry"):void 0,Q=bn(),B=qt(Q);function R(f,m,y,x){if(N(y)){if(!Ft(f))throw new TypeError;if(!ct(m))throw new TypeError;return Pt(f,m)}else{if(!Ft(f))throw new TypeError;if(!K(m))throw new TypeError;if(!K(x)&&!N(x)&&!qe(x))throw new TypeError;return qe(x)&&(x=void 0),y=ke(y),Lt(f,m,y,x)}}t("decorate",R);function D(f,m){function y(x,I){if(!K(x))throw new TypeError;if(!N(I)&&!De(I))throw new TypeError;rn(f,m,x,I)}return y}t("metadata",D);function se(f,m,y,x){if(!K(y))throw new TypeError;return N(x)||(x=ke(x)),rn(f,m,y,x)}t("defineMetadata",se);function re(f,m,y){if(!K(m))throw new TypeError;return N(y)||(y=ke(y)),Dt(f,m,y)}t("hasMetadata",re);function ot(f,m,y){if(!K(m))throw new TypeError;return N(y)||(y=ke(y)),Mt(f,m,y)}t("hasOwnMetadata",ot);function Pe(f,m,y){if(!K(m))throw new TypeError;return N(y)||(y=ke(y)),sn(f,m,y)}t("getMetadata",Pe);function Ct(f,m,y){if(!K(m))throw new TypeError;return N(y)||(y=ke(y)),lt(f,m,y)}t("getOwnMetadata",Ct);function vn(f,m){if(!K(f))throw new TypeError;return N(m)||(m=ke(m)),Bt(f,m)}t("getMetadataKeys",vn);function me(f,m){if(!K(f))throw new TypeError;return N(m)||(m=ke(m)),ce(f,m)}t("getOwnMetadataKeys",me);function Ot(f,m,y){if(!K(m))throw new TypeError;if(N(y)||(y=ke(y)),!K(m))throw new TypeError;N(y)||(y=ke(y));var x=Ue(m,y,!1);return N(x)?!1:x.OrdinaryDeleteMetadata(f,m,y)}t("deleteMetadata",Ot);function Pt(f,m){for(var y=f.length-1;y>=0;--y){var x=f[y],I=x(m);if(!N(I)&&!qe(I)){if(!ct(I))throw new TypeError;m=I}}return m}function Lt(f,m,y,x){for(var I=f.length-1;I>=0;--I){var ue=f[I],de=ue(m,y,x);if(!N(de)&&!qe(de)){if(!K(de))throw new TypeError;x=de}}return x}function Dt(f,m,y){var x=Mt(f,m,y);if(x)return!0;var I=St(m);return qe(I)?!1:Dt(f,I,y)}function Mt(f,m,y){var x=Ue(m,y,!1);return N(x)?!1:Be(x.OrdinaryHasOwnMetadata(f,m,y))}function sn(f,m,y){var x=Mt(f,m,y);if(x)return lt(f,m,y);var I=St(m);if(!qe(I))return sn(f,I,y)}function lt(f,m,y){var x=Ue(m,y,!1);if(!N(x))return x.OrdinaryGetOwnMetadata(f,m,y)}function rn(f,m,y,x){var I=Ue(y,x,!0);I.OrdinaryDefineOwnMetadata(f,m,y,x)}function Bt(f,m){var y=ce(f,m),x=St(f);if(x===null)return y;var I=Bt(x,m);if(I.length<=0)return y;if(y.length<=0)return I;for(var ue=new w,de=[],z=0,k=y;z<k.length;z++){var A=k[z],E=ue.has(A);E||(ue.add(A),de.push(A))}for(var j=0,q=I;j<q.length;j++){var A=q[j],E=ue.has(A);E||(ue.add(A),de.push(A))}return de}function ce(f,m){var y=Ue(f,m,!1);return y?y.OrdinaryOwnMetadataKeys(f,m):[]}function Ht(f){if(f===null)return 1;switch(typeof f){case"undefined":return 0;case"boolean":return 2;case"string":return 3;case"symbol":return 4;case"number":return 5;case"object":return f===null?1:6;default:return 6}}function N(f){return f===void 0}function qe(f){return f===null}function ie(f){return typeof f=="symbol"}function K(f){return typeof f=="object"?f!==null:typeof f=="function"}function Ut(f,m){switch(Ht(f)){case 0:return f;case 1:return f;case 2:return f;case 3:return f;case 4:return f;case 5:return f}var y="string",x=kt(f,a);if(x!==void 0){var I=x.call(f,y);if(K(I))throw new TypeError;return I}return Je(f)}function Je(f,m){var y,x;{var I=f.toString;if(Le(I)){var x=I.call(f);if(!K(x))return x}var y=f.valueOf;if(Le(y)){var x=y.call(f);if(!K(x))return x}}throw new TypeError}function Be(f){return!!f}function zt(f){return""+f}function ke(f){var m=Ut(f);return ie(m)?m:zt(m)}function Ft(f){return Array.isArray?Array.isArray(f):f instanceof Object?f instanceof Array:Object.prototype.toString.call(f)==="[object Array]"}function Le(f){return typeof f=="function"}function ct(f){return typeof f=="function"}function De(f){switch(Ht(f)){case 3:return!0;case 4:return!0;default:return!1}}function dt(f,m){return f===m||f!==f&&m!==m}function kt(f,m){var y=f[m];if(y!=null){if(!Le(y))throw new TypeError;return y}}function P(f){var m=kt(f,l);if(!Le(m))throw new TypeError;var y=m.call(f);if(!K(y))throw new TypeError;return y}function M(f){return f.value}function Se(f){var m=f.next();return m.done?!1:m}function He(f){var m=f.return;m&&m.call(f)}function St(f){var m=Object.getPrototypeOf(f);if(typeof f!="function"||f===p||m!==p)return m;var y=f.prototype,x=y&&Object.getPrototypeOf(y);if(x==null||x===Object.prototype)return m;var I=x.constructor;return typeof I!="function"||I===f?m:I}function et(){var f;!N(U)&&typeof s.Reflect<"u"&&!(U in s.Reflect)&&typeof s.Reflect.defineMetadata=="function"&&(f=At(s.Reflect));var m,y,x,I=new L,ue={registerProvider:de,getProvider:k,setProvider:E};return ue;function de(j){if(!Object.isExtensible(ue))throw new Error("Cannot add provider to a frozen registry.");switch(!0){case f===j:break;case N(m):m=j;break;case m===j:break;case N(y):y=j;break;case y===j:break;default:x===void 0&&(x=new w),x.add(j);break}}function z(j,q){if(!N(m)){if(m.isProviderFor(j,q))return m;if(!N(y)){if(y.isProviderFor(j,q))return m;if(!N(x))for(var J=P(x);;){var F=Se(J);if(!F)return;var xe=M(F);if(xe.isProviderFor(j,q))return He(J),xe}}}if(!N(f)&&f.isProviderFor(j,q))return f}function k(j,q){var J=I.get(j),F;return N(J)||(F=J.get(q)),N(F)&&(F=z(j,q),N(F)||(N(J)&&(J=new v,I.set(j,J)),J.set(q,F))),F}function A(j){if(N(j))throw new TypeError;return m===j||y===j||!N(x)&&x.has(j)}function E(j,q,J){if(!A(J))throw new Error("Metadata provider not registered.");var F=k(j,q);if(F!==J){if(!N(F))return!1;var xe=I.get(j);N(xe)&&(xe=new v,I.set(j,xe)),xe.set(q,J)}return!0}}function bn(){var f;return!N(U)&&K(s.Reflect)&&Object.isExtensible(s.Reflect)&&(f=s.Reflect[U]),N(f)&&(f=et()),!N(U)&&K(s.Reflect)&&Object.isExtensible(s.Reflect)&&Object.defineProperty(s.Reflect,U,{enumerable:!1,configurable:!1,writable:!1,value:f}),f}function qt(f){var m=new L,y={isProviderFor:function(A,E){var j=m.get(A);return N(j)?!1:j.has(E)},OrdinaryDefineOwnMetadata:de,OrdinaryHasOwnMetadata:I,OrdinaryGetOwnMetadata:ue,OrdinaryOwnMetadataKeys:z,OrdinaryDeleteMetadata:k};return Q.registerProvider(y),y;function x(A,E,j){var q=m.get(A),J=!1;if(N(q)){if(!j)return;q=new v,m.set(A,q),J=!0}var F=q.get(E);if(N(F)){if(!j)return;if(F=new v,q.set(E,F),!f.setProvider(A,E,y))throw q.delete(E),J&&m.delete(A),new Error("Wrong provider for target.")}return F}function I(A,E,j){var q=x(E,j,!1);return N(q)?!1:Be(q.has(A))}function ue(A,E,j){var q=x(E,j,!1);if(!N(q))return q.get(A)}function de(A,E,j,q){var J=x(j,q,!0);J.set(A,E)}function z(A,E){var j=[],q=x(A,E,!1);if(N(q))return j;for(var J=q.keys(),F=P(J),xe=0;;){var Vn=Se(F);if(!Vn)return j.length=xe,j;var Wn=M(Vn);try{j[xe]=Wn}catch(xn){try{He(F)}finally{throw xn}}xe++}}function k(A,E,j){var q=x(E,j,!1);if(N(q)||!q.delete(A))return!1;if(q.size===0){var J=m.get(E);N(J)||(J.delete(j),J.size===0&&m.delete(J))}return!0}}function At(f){var m=f.defineMetadata,y=f.hasOwnMetadata,x=f.getOwnMetadata,I=f.getOwnMetadataKeys,ue=f.deleteMetadata,de=new L,z={isProviderFor:function(k,A){var E=de.get(k);return!N(E)&&E.has(A)?!0:I(k,A).length?(N(E)&&(E=new w,de.set(k,E)),E.add(A),!0):!1},OrdinaryDefineOwnMetadata:m,OrdinaryHasOwnMetadata:y,OrdinaryGetOwnMetadata:x,OrdinaryOwnMetadataKeys:I,OrdinaryDeleteMetadata:ue};return z}function Ue(f,m,y){var x=Q.getProvider(f,m);if(!N(x))return x;if(y){if(Q.setProvider(f,m,B))return B;throw new Error("Illegal state.")}}function zn(){var f={},m=[],y=(function(){function z(k,A,E){this._index=0,this._keys=k,this._values=A,this._selector=E}return z.prototype["@@iterator"]=function(){return this},z.prototype[l]=function(){return this},z.prototype.next=function(){var k=this._index;if(k>=0&&k<this._keys.length){var A=this._selector(this._keys[k],this._values[k]);return k+1>=this._keys.length?(this._index=-1,this._keys=m,this._values=m):this._index++,{value:A,done:!1}}return{value:void 0,done:!0}},z.prototype.throw=function(k){throw this._index>=0&&(this._index=-1,this._keys=m,this._values=m),k},z.prototype.return=function(k){return this._index>=0&&(this._index=-1,this._keys=m,this._values=m),{value:k,done:!0}},z})(),x=(function(){function z(){this._keys=[],this._values=[],this._cacheKey=f,this._cacheIndex=-2}return Object.defineProperty(z.prototype,"size",{get:function(){return this._keys.length},enumerable:!0,configurable:!0}),z.prototype.has=function(k){return this._find(k,!1)>=0},z.prototype.get=function(k){var A=this._find(k,!1);return A>=0?this._values[A]:void 0},z.prototype.set=function(k,A){var E=this._find(k,!0);return this._values[E]=A,this},z.prototype.delete=function(k){var A=this._find(k,!1);if(A>=0){for(var E=this._keys.length,j=A+1;j<E;j++)this._keys[j-1]=this._keys[j],this._values[j-1]=this._values[j];return this._keys.length--,this._values.length--,dt(k,this._cacheKey)&&(this._cacheKey=f,this._cacheIndex=-2),!0}return!1},z.prototype.clear=function(){this._keys.length=0,this._values.length=0,this._cacheKey=f,this._cacheIndex=-2},z.prototype.keys=function(){return new y(this._keys,this._values,I)},z.prototype.values=function(){return new y(this._keys,this._values,ue)},z.prototype.entries=function(){return new y(this._keys,this._values,de)},z.prototype["@@iterator"]=function(){return this.entries()},z.prototype[l]=function(){return this.entries()},z.prototype._find=function(k,A){if(!dt(this._cacheKey,k)){this._cacheIndex=-1;for(var E=0;E<this._keys.length;E++)if(dt(this._keys[E],k)){this._cacheIndex=E;break}}return this._cacheIndex<0&&A&&(this._cacheIndex=this._keys.length,this._keys.push(k),this._values.push(void 0)),this._cacheIndex},z})();return x;function I(z,k){return z}function ue(z,k){return k}function de(z,k){return[z,k]}}function Fn(){var f=(function(){function m(){this._map=new v}return Object.defineProperty(m.prototype,"size",{get:function(){return this._map.size},enumerable:!0,configurable:!0}),m.prototype.has=function(y){return this._map.has(y)},m.prototype.add=function(y){return this._map.set(y,y),this},m.prototype.delete=function(y){return this._map.delete(y)},m.prototype.clear=function(){this._map.clear()},m.prototype.keys=function(){return this._map.keys()},m.prototype.values=function(){return this._map.keys()},m.prototype.entries=function(){return this._map.entries()},m.prototype["@@iterator"]=function(){return this.keys()},m.prototype[l]=function(){return this.keys()},m})();return f}function qn(){var f=16,m=g.create(),y=x();return(function(){function k(){this._key=x()}return k.prototype.has=function(A){var E=I(A,!1);return E!==void 0?g.has(E,this._key):!1},k.prototype.get=function(A){var E=I(A,!1);return E!==void 0?g.get(E,this._key):void 0},k.prototype.set=function(A,E){var j=I(A,!0);return j[this._key]=E,this},k.prototype.delete=function(A){var E=I(A,!1);return E!==void 0?delete E[this._key]:!1},k.prototype.clear=function(){this._key=x()},k})();function x(){var k;do k="@@WeakMap@@"+z();while(g.has(m,k));return m[k]=!0,k}function I(k,A){if(!r.call(k,y)){if(!A)return;Object.defineProperty(k,y,{value:g.create()})}return k[y]}function ue(k,A){for(var E=0;E<A;++E)k[E]=Math.random()*255|0;return k}function de(k){if(typeof Uint8Array=="function"){var A=new Uint8Array(k);return typeof crypto<"u"?crypto.getRandomValues(A):typeof msCrypto<"u"?msCrypto.getRandomValues(A):ue(A,k),A}return ue(new Array(k),k)}function z(){var k=de(f);k[6]=k[6]&79|64,k[8]=k[8]&191|128;for(var A="",E=0;E<f;++E){var j=k[E];(E===4||E===6||E===8)&&(A+="-"),j<16&&(A+="0"),A+=j.toString(16).toLowerCase()}return A}}function Vt(f){return f.__=void 0,delete f.__,f}})})(n||(n={})),oi}Qo();/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const ns=window,$r=ns.ShadowRoot&&(ns.ShadyCSS===void 0||ns.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,Rr=Symbol(),ci=new WeakMap;let ha=class{constructor(n,e,t){if(this._$cssResult$=!0,t!==Rr)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=n,this.t=e}get styleSheet(){let n=this.o;const e=this.t;if($r&&n===void 0){const t=e!==void 0&&e.length===1;t&&(n=ci.get(e)),n===void 0&&((this.o=n=new CSSStyleSheet).replaceSync(this.cssText),t&&ci.set(e,n))}return n}toString(){return this.cssText}};const Ko=n=>new ha(typeof n=="string"?n:n+"",void 0,Rr),it=(n,...e)=>{const t=n.length===1?n[0]:e.reduce(((s,r,i)=>s+(a=>{if(a._$cssResult$===!0)return a.cssText;if(typeof a=="number")return a;throw Error("Value passed to 'css' function must be a 'css' function result: "+a+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(r)+n[i+1]),n[0]);return new ha(t,n,Rr)},Jo=(n,e)=>{$r?n.adoptedStyleSheets=e.map((t=>t instanceof CSSStyleSheet?t:t.styleSheet)):e.forEach((t=>{const s=document.createElement("style"),r=ns.litNonce;r!==void 0&&s.setAttribute("nonce",r),s.textContent=t.cssText,n.appendChild(s)}))},di=$r?n=>n:n=>n instanceof CSSStyleSheet?(e=>{let t="";for(const s of e.cssRules)t+=s.cssText;return Ko(t)})(n):n;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var Os;const ds=window,hi=ds.trustedTypes,el=hi?hi.emptyScript:"",ui=ds.reactiveElementPolyfillSupport,nr={toAttribute(n,e){switch(e){case Boolean:n=n?el:null;break;case Object:case Array:n=n==null?n:JSON.stringify(n)}return n},fromAttribute(n,e){let t=n;switch(e){case Boolean:t=n!==null;break;case Number:t=n===null?null:Number(n);break;case Object:case Array:try{t=JSON.parse(n)}catch{t=null}}return t}},ua=(n,e)=>e!==n&&(e==e||n==n),Ps={attribute:!0,type:String,converter:nr,reflect:!1,hasChanged:ua},sr="finalized";let an=class extends HTMLElement{constructor(){super(),this._$Ei=new Map,this.isUpdatePending=!1,this.hasUpdated=!1,this._$El=null,this._$Eu()}static addInitializer(n){var e;this.finalize(),((e=this.h)!==null&&e!==void 0?e:this.h=[]).push(n)}static get observedAttributes(){this.finalize();const n=[];return this.elementProperties.forEach(((e,t)=>{const s=this._$Ep(t,e);s!==void 0&&(this._$Ev.set(s,t),n.push(s))})),n}static createProperty(n,e=Ps){if(e.state&&(e.attribute=!1),this.finalize(),this.elementProperties.set(n,e),!e.noAccessor&&!this.prototype.hasOwnProperty(n)){const t=typeof n=="symbol"?Symbol():"__"+n,s=this.getPropertyDescriptor(n,t,e);s!==void 0&&Object.defineProperty(this.prototype,n,s)}}static getPropertyDescriptor(n,e,t){return{get(){return this[e]},set(s){const r=this[n];this[e]=s,this.requestUpdate(n,r,t)},configurable:!0,enumerable:!0}}static getPropertyOptions(n){return this.elementProperties.get(n)||Ps}static finalize(){if(this.hasOwnProperty(sr))return!1;this[sr]=!0;const n=Object.getPrototypeOf(this);if(n.finalize(),n.h!==void 0&&(this.h=[...n.h]),this.elementProperties=new Map(n.elementProperties),this._$Ev=new Map,this.hasOwnProperty("properties")){const e=this.properties,t=[...Object.getOwnPropertyNames(e),...Object.getOwnPropertySymbols(e)];for(const s of t)this.createProperty(s,e[s])}return this.elementStyles=this.finalizeStyles(this.styles),!0}static finalizeStyles(n){const e=[];if(Array.isArray(n)){const t=new Set(n.flat(1/0).reverse());for(const s of t)e.unshift(di(s))}else n!==void 0&&e.push(di(n));return e}static _$Ep(n,e){const t=e.attribute;return t===!1?void 0:typeof t=="string"?t:typeof n=="string"?n.toLowerCase():void 0}_$Eu(){var n;this._$E_=new Promise((e=>this.enableUpdating=e)),this._$AL=new Map,this._$Eg(),this.requestUpdate(),(n=this.constructor.h)===null||n===void 0||n.forEach((e=>e(this)))}addController(n){var e,t;((e=this._$ES)!==null&&e!==void 0?e:this._$ES=[]).push(n),this.renderRoot!==void 0&&this.isConnected&&((t=n.hostConnected)===null||t===void 0||t.call(n))}removeController(n){var e;(e=this._$ES)===null||e===void 0||e.splice(this._$ES.indexOf(n)>>>0,1)}_$Eg(){this.constructor.elementProperties.forEach(((n,e)=>{this.hasOwnProperty(e)&&(this._$Ei.set(e,this[e]),delete this[e])}))}createRenderRoot(){var n;const e=(n=this.shadowRoot)!==null&&n!==void 0?n:this.attachShadow(this.constructor.shadowRootOptions);return Jo(e,this.constructor.elementStyles),e}connectedCallback(){var n;this.renderRoot===void 0&&(this.renderRoot=this.createRenderRoot()),this.enableUpdating(!0),(n=this._$ES)===null||n===void 0||n.forEach((e=>{var t;return(t=e.hostConnected)===null||t===void 0?void 0:t.call(e)}))}enableUpdating(n){}disconnectedCallback(){var n;(n=this._$ES)===null||n===void 0||n.forEach((e=>{var t;return(t=e.hostDisconnected)===null||t===void 0?void 0:t.call(e)}))}attributeChangedCallback(n,e,t){this._$AK(n,t)}_$EO(n,e,t=Ps){var s;const r=this.constructor._$Ep(n,t);if(r!==void 0&&t.reflect===!0){const i=(((s=t.converter)===null||s===void 0?void 0:s.toAttribute)!==void 0?t.converter:nr).toAttribute(e,t.type);this._$El=n,i==null?this.removeAttribute(r):this.setAttribute(r,i),this._$El=null}}_$AK(n,e){var t;const s=this.constructor,r=s._$Ev.get(n);if(r!==void 0&&this._$El!==r){const i=s.getPropertyOptions(r),a=typeof i.converter=="function"?{fromAttribute:i.converter}:((t=i.converter)===null||t===void 0?void 0:t.fromAttribute)!==void 0?i.converter:nr;this._$El=r,this[r]=a.fromAttribute(e,i.type),this._$El=null}}requestUpdate(n,e,t){let s=!0;n!==void 0&&(((t=t||this.constructor.getPropertyOptions(n)).hasChanged||ua)(this[n],e)?(this._$AL.has(n)||this._$AL.set(n,e),t.reflect===!0&&this._$El!==n&&(this._$EC===void 0&&(this._$EC=new Map),this._$EC.set(n,t))):s=!1),!this.isUpdatePending&&s&&(this._$E_=this._$Ej())}async _$Ej(){this.isUpdatePending=!0;try{await this._$E_}catch(e){Promise.reject(e)}const n=this.scheduleUpdate();return n!=null&&await n,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){var n;if(!this.isUpdatePending)return;this.hasUpdated,this._$Ei&&(this._$Ei.forEach(((s,r)=>this[r]=s)),this._$Ei=void 0);let e=!1;const t=this._$AL;try{e=this.shouldUpdate(t),e?(this.willUpdate(t),(n=this._$ES)===null||n===void 0||n.forEach((s=>{var r;return(r=s.hostUpdate)===null||r===void 0?void 0:r.call(s)})),this.update(t)):this._$Ek()}catch(s){throw e=!1,this._$Ek(),s}e&&this._$AE(t)}willUpdate(n){}_$AE(n){var e;(e=this._$ES)===null||e===void 0||e.forEach((t=>{var s;return(s=t.hostUpdated)===null||s===void 0?void 0:s.call(t)})),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(n)),this.updated(n)}_$Ek(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$E_}shouldUpdate(n){return!0}update(n){this._$EC!==void 0&&(this._$EC.forEach(((e,t)=>this._$EO(t,this[t],e))),this._$EC=void 0),this._$Ek()}updated(n){}firstUpdated(n){}};an[sr]=!0,an.elementProperties=new Map,an.elementStyles=[],an.shadowRootOptions={mode:"open"},ui==null||ui({ReactiveElement:an}),((Os=ds.reactiveElementVersions)!==null&&Os!==void 0?Os:ds.reactiveElementVersions=[]).push("1.6.3");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var Ls;const hs=window,cn=hs.trustedTypes,pi=cn?cn.createPolicy("lit-html",{createHTML:n=>n}):void 0,rr="$lit$",Nt=`lit$${(Math.random()+"").slice(9)}$`,pa="?"+Nt,tl=`<${pa}>`,Qt=document,On=()=>Qt.createComment(""),Pn=n=>n===null||typeof n!="object"&&typeof n!="function",ga=Array.isArray,nl=n=>ga(n)||typeof(n==null?void 0:n[Symbol.iterator])=="function",Ds=`[ 	
\f\r]`,_n=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,gi=/-->/g,fi=/>/g,Zt=RegExp(`>|${Ds}(?:([^\\s"'>=/]+)(${Ds}*=${Ds}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`,"g"),mi=/'/g,yi=/"/g,fa=/^(?:script|style|textarea|title)$/i,sl=n=>(e,...t)=>({_$litType$:n,strings:e,values:t}),$=sl(1),Kt=Symbol.for("lit-noChange"),ye=Symbol.for("lit-nothing"),vi=new WeakMap,Xt=Qt.createTreeWalker(Qt,129,null,!1);function ma(n,e){if(!Array.isArray(n)||!n.hasOwnProperty("raw"))throw Error("invalid template strings array");return pi!==void 0?pi.createHTML(e):e}const rl=(n,e)=>{const t=n.length-1,s=[];let r,i=e===2?"<svg>":"",a=_n;for(let l=0;l<t;l++){const c=n[l];let h,u,g=-1,p=0;for(;p<c.length&&(a.lastIndex=p,u=a.exec(c),u!==null);)p=a.lastIndex,a===_n?u[1]==="!--"?a=gi:u[1]!==void 0?a=fi:u[2]!==void 0?(fa.test(u[2])&&(r=RegExp("</"+u[2],"g")),a=Zt):u[3]!==void 0&&(a=Zt):a===Zt?u[0]===">"?(a=r??_n,g=-1):u[1]===void 0?g=-2:(g=a.lastIndex-u[2].length,h=u[1],a=u[3]===void 0?Zt:u[3]==='"'?yi:mi):a===yi||a===mi?a=Zt:a===gi||a===fi?a=_n:(a=Zt,r=void 0);const v=a===Zt&&n[l+1].startsWith("/>")?" ":"";i+=a===_n?c+tl:g>=0?(s.push(h),c.slice(0,g)+rr+c.slice(g)+Nt+v):c+Nt+(g===-2?(s.push(void 0),l):v)}return[ma(n,i+(n[t]||"<?>")+(e===2?"</svg>":"")),s]};let ir=class ya{constructor({strings:e,_$litType$:t},s){let r;this.parts=[];let i=0,a=0;const l=e.length-1,c=this.parts,[h,u]=rl(e,t);if(this.el=ya.createElement(h,s),Xt.currentNode=this.el.content,t===2){const g=this.el.content,p=g.firstChild;p.remove(),g.append(...p.childNodes)}for(;(r=Xt.nextNode())!==null&&c.length<l;){if(r.nodeType===1){if(r.hasAttributes()){const g=[];for(const p of r.getAttributeNames())if(p.endsWith(rr)||p.startsWith(Nt)){const v=u[a++];if(g.push(p),v!==void 0){const w=r.getAttribute(v.toLowerCase()+rr).split(Nt),L=/([.?@])?(.*)/.exec(v);c.push({type:1,index:i,name:L[2],strings:w,ctor:L[1]==="."?al:L[1]==="?"?ll:L[1]==="@"?cl:Cs})}else c.push({type:6,index:i})}for(const p of g)r.removeAttribute(p)}if(fa.test(r.tagName)){const g=r.textContent.split(Nt),p=g.length-1;if(p>0){r.textContent=cn?cn.emptyScript:"";for(let v=0;v<p;v++)r.append(g[v],On()),Xt.nextNode(),c.push({type:2,index:++i});r.append(g[p],On())}}}else if(r.nodeType===8)if(r.data===pa)c.push({type:2,index:i});else{let g=-1;for(;(g=r.data.indexOf(Nt,g+1))!==-1;)c.push({type:7,index:i}),g+=Nt.length-1}i++}}static createElement(e,t){const s=Qt.createElement("template");return s.innerHTML=e,s}};function dn(n,e,t=n,s){var r,i,a,l;if(e===Kt)return e;let c=s!==void 0?(r=t._$Co)===null||r===void 0?void 0:r[s]:t._$Cl;const h=Pn(e)?void 0:e._$litDirective$;return(c==null?void 0:c.constructor)!==h&&((i=c==null?void 0:c._$AO)===null||i===void 0||i.call(c,!1),h===void 0?c=void 0:(c=new h(n),c._$AT(n,t,s)),s!==void 0?((a=(l=t)._$Co)!==null&&a!==void 0?a:l._$Co=[])[s]=c:t._$Cl=c),c!==void 0&&(e=dn(n,c._$AS(n,e.values),c,s)),e}let il=class{constructor(n,e){this._$AV=[],this._$AN=void 0,this._$AD=n,this._$AM=e}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(n){var e;const{el:{content:t},parts:s}=this._$AD,r=((e=n==null?void 0:n.creationScope)!==null&&e!==void 0?e:Qt).importNode(t,!0);Xt.currentNode=r;let i=Xt.nextNode(),a=0,l=0,c=s[0];for(;c!==void 0;){if(a===c.index){let h;c.type===2?h=new Bn(i,i.nextSibling,this,n):c.type===1?h=new c.ctor(i,c.name,c.strings,this,n):c.type===6&&(h=new dl(i,this,n)),this._$AV.push(h),c=s[++l]}a!==(c==null?void 0:c.index)&&(i=Xt.nextNode(),a++)}return Xt.currentNode=Qt,r}v(n){let e=0;for(const t of this._$AV)t!==void 0&&(t.strings!==void 0?(t._$AI(n,t,e),e+=t.strings.length-2):t._$AI(n[e])),e++}};class Bn{constructor(e,t,s,r){var i;this.type=2,this._$AH=ye,this._$AN=void 0,this._$AA=e,this._$AB=t,this._$AM=s,this.options=r,this._$Cp=(i=r==null?void 0:r.isConnected)===null||i===void 0||i}get _$AU(){var e,t;return(t=(e=this._$AM)===null||e===void 0?void 0:e._$AU)!==null&&t!==void 0?t:this._$Cp}get parentNode(){let e=this._$AA.parentNode;const t=this._$AM;return t!==void 0&&(e==null?void 0:e.nodeType)===11&&(e=t.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,t=this){e=dn(this,e,t),Pn(e)?e===ye||e==null||e===""?(this._$AH!==ye&&this._$AR(),this._$AH=ye):e!==this._$AH&&e!==Kt&&this._(e):e._$litType$!==void 0?this.g(e):e.nodeType!==void 0?this.$(e):nl(e)?this.T(e):this._(e)}k(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}$(e){this._$AH!==e&&(this._$AR(),this._$AH=this.k(e))}_(e){this._$AH!==ye&&Pn(this._$AH)?this._$AA.nextSibling.data=e:this.$(Qt.createTextNode(e)),this._$AH=e}g(e){var t;const{values:s,_$litType$:r}=e,i=typeof r=="number"?this._$AC(e):(r.el===void 0&&(r.el=ir.createElement(ma(r.h,r.h[0]),this.options)),r);if(((t=this._$AH)===null||t===void 0?void 0:t._$AD)===i)this._$AH.v(s);else{const a=new il(i,this),l=a.u(this.options);a.v(s),this.$(l),this._$AH=a}}_$AC(e){let t=vi.get(e.strings);return t===void 0&&vi.set(e.strings,t=new ir(e)),t}T(e){ga(this._$AH)||(this._$AH=[],this._$AR());const t=this._$AH;let s,r=0;for(const i of e)r===t.length?t.push(s=new Bn(this.k(On()),this.k(On()),this,this.options)):s=t[r],s._$AI(i),r++;r<t.length&&(this._$AR(s&&s._$AB.nextSibling,r),t.length=r)}_$AR(e=this._$AA.nextSibling,t){var s;for((s=this._$AP)===null||s===void 0||s.call(this,!1,!0,t);e&&e!==this._$AB;){const r=e.nextSibling;e.remove(),e=r}}setConnected(e){var t;this._$AM===void 0&&(this._$Cp=e,(t=this._$AP)===null||t===void 0||t.call(this,e))}}let Cs=class{constructor(n,e,t,s,r){this.type=1,this._$AH=ye,this._$AN=void 0,this.element=n,this.name=e,this._$AM=s,this.options=r,t.length>2||t[0]!==""||t[1]!==""?(this._$AH=Array(t.length-1).fill(new String),this.strings=t):this._$AH=ye}get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}_$AI(n,e=this,t,s){const r=this.strings;let i=!1;if(r===void 0)n=dn(this,n,e,0),i=!Pn(n)||n!==this._$AH&&n!==Kt,i&&(this._$AH=n);else{const a=n;let l,c;for(n=r[0],l=0;l<r.length-1;l++)c=dn(this,a[t+l],e,l),c===Kt&&(c=this._$AH[l]),i||(i=!Pn(c)||c!==this._$AH[l]),c===ye?n=ye:n!==ye&&(n+=(c??"")+r[l+1]),this._$AH[l]=c}i&&!s&&this.j(n)}j(n){n===ye?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,n??"")}},al=class extends Cs{constructor(){super(...arguments),this.type=3}j(n){this.element[this.name]=n===ye?void 0:n}};const ol=cn?cn.emptyScript:"";let ll=class extends Cs{constructor(){super(...arguments),this.type=4}j(n){n&&n!==ye?this.element.setAttribute(this.name,ol):this.element.removeAttribute(this.name)}},cl=class extends Cs{constructor(n,e,t,s,r){super(n,e,t,s,r),this.type=5}_$AI(n,e=this){var t;if((n=(t=dn(this,n,e,0))!==null&&t!==void 0?t:ye)===Kt)return;const s=this._$AH,r=n===ye&&s!==ye||n.capture!==s.capture||n.once!==s.once||n.passive!==s.passive,i=n!==ye&&(s===ye||r);r&&this.element.removeEventListener(this.name,this,s),i&&this.element.addEventListener(this.name,this,n),this._$AH=n}handleEvent(n){var e,t;typeof this._$AH=="function"?this._$AH.call((t=(e=this.options)===null||e===void 0?void 0:e.host)!==null&&t!==void 0?t:this.element,n):this._$AH.handleEvent(n)}},dl=class{constructor(n,e,t){this.element=n,this.type=6,this._$AN=void 0,this._$AM=e,this.options=t}get _$AU(){return this._$AM._$AU}_$AI(n){dn(this,n)}};const bi=hs.litHtmlPolyfillSupport;bi==null||bi(ir,Bn),((Ls=hs.litHtmlVersions)!==null&&Ls!==void 0?Ls:hs.litHtmlVersions=[]).push("2.8.0");const hl=(n,e,t)=>{var s,r;const i=(s=t==null?void 0:t.renderBefore)!==null&&s!==void 0?s:e;let a=i._$litPart$;if(a===void 0){const l=(r=t==null?void 0:t.renderBefore)!==null&&r!==void 0?r:null;i._$litPart$=a=new Bn(e.insertBefore(On(),l),l,void 0,t??{})}return a._$AI(n),a};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var Ms,Bs;let Ne=class extends an{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){var n,e;const t=super.createRenderRoot();return(n=(e=this.renderOptions).renderBefore)!==null&&n!==void 0||(e.renderBefore=t.firstChild),t}update(n){const e=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(n),this._$Do=hl(e,this.renderRoot,this.renderOptions)}connectedCallback(){var n;super.connectedCallback(),(n=this._$Do)===null||n===void 0||n.setConnected(!0)}disconnectedCallback(){var n;super.disconnectedCallback(),(n=this._$Do)===null||n===void 0||n.setConnected(!1)}render(){return Kt}};Ne.finalized=!0,Ne._$litElement$=!0,(Ms=globalThis.litElementHydrateSupport)===null||Ms===void 0||Ms.call(globalThis,{LitElement:Ne});const xi=globalThis.litElementPolyfillSupport;xi==null||xi({LitElement:Ne});((Bs=globalThis.litElementVersions)!==null&&Bs!==void 0?Bs:globalThis.litElementVersions=[]).push("3.3.3");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Ke=n=>e=>typeof e=="function"?((t,s)=>(customElements.define(t,s),s))(n,e):((t,s)=>{const{kind:r,elements:i}=s;return{kind:r,elements:i,finisher(a){customElements.define(t,a)}}})(n,e);/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const ul=(n,e)=>e.kind==="method"&&e.descriptor&&!("value"in e.descriptor)?{...e,finisher(t){t.createProperty(e.key,n)}}:{kind:"field",key:Symbol(),placement:"own",descriptor:{},originalKey:e.key,initializer(){typeof e.initializer=="function"&&(this[e.key]=e.initializer.call(this))},finisher(t){t.createProperty(e.key,n)}},pl=(n,e,t)=>{e.constructor.createProperty(t,n)};function H(n){return(e,t)=>t!==void 0?pl(n,e,t):ul(n,e)}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function tn(n){return H({...n,state:!0})}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const gl=({finisher:n,descriptor:e})=>(t,s)=>{var r;if(s===void 0){const i=(r=t.originalKey)!==null&&r!==void 0?r:t.key,a=e!=null?{kind:"method",placement:"prototype",key:i,descriptor:e(t.key)}:{...t,key:i};return n!=null&&(a.finisher=function(l){n(l,i)}),a}{const i=t.constructor;e!==void 0&&Object.defineProperty(t,s,e(s)),n==null||n(i,s)}};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function va(n,e){return gl({descriptor:t=>({get(){var s,r;return(r=(s=this.renderRoot)===null||s===void 0?void 0:s.querySelector(n))!==null&&r!==void 0?r:null},enumerable:!0,configurable:!0})})}/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var Hs;((Hs=window.HTMLSlotElement)===null||Hs===void 0?void 0:Hs.prototype.assignedElements)!=null;const fl=it`
  a svg {
    width: calc(var(--width-base) - var(--d-small));
    height: calc(var(--width-base) - var(--d-small));
    position: relative;
    z-index: 1;
  }
  a {
    flex-shrink: 0;
    border-radius: calc(var(--radius-large) * 3);
    border: var(--border-thicker) solid transparent;
    background-origin: border-box;
    background-clip: content-box, border-box;
    background-size: cover;
    background-image: linear-gradient(to right, var(--c-accent-light), var(--c-accent-high));
    width: calc(var(--d-xlarge) * 2);
    height: calc(var(--d-xlarge) * 2);
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: var(--d-large);
    overflow: hidden;
    padding: var(--d-small);
    position: relative;
  }
  a::after {
    content: '';
    border-radius: calc(var(--radius-large) * 3);
    width: calc(var(--width-base) - var(--d-small));
    height: calc(var(--width-base) - var(--d-small));
    position: absolute;
    background-color: var(--c-secondary);
  }
`;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const ml={CHILD:2},ba=n=>(...e)=>({_$litDirective$:n,values:e});let yl=class{constructor(n){}get _$AU(){return this._$AM._$AU}_$AT(n,e,t){this._$Ct=n,this._$AM=e,this._$Ci=t}_$AS(n,e){return this.update(n,e)}update(n,e){return this.render(...e)}};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let us=class extends yl{constructor(n){if(super(n),this.et=ye,n.type!==ml.CHILD)throw Error(this.constructor.directiveName+"() can only be used in child bindings")}render(n){if(n===ye||n==null)return this.ft=void 0,this.et=n;if(n===Kt)return n;if(typeof n!="string")throw Error(this.constructor.directiveName+"() called with a non-string value");if(n===this.et)return this.ft;this.et=n;const e=[n];return e.raw=e,this.ft={_$litType$:this.constructor.resultType,strings:e,values:[]}}};us.directiveName="unsafeHTML",us.resultType=1;const ps=ba(us);/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let ar=class extends us{};ar.directiveName="unsafeSVG",ar.resultType=2;const rt=ba(ar);var vl=Object.defineProperty,bl=Object.getOwnPropertyDescriptor,ks=(n,e,t,s)=>{for(var r=s>1?void 0:s?bl(e,t):e,i=n.length-1,a;i>=0;i--)(a=n[i])&&(r=(s?a(e,t,r):a(r))||r);return s&&r&&vl(e,t,r),r};let hn=class extends Ne{constructor(){super(...arguments),this.label="",this.svgIcon="",this.url=""}render(){return $`
      <a title="${this.label}" href="${this.url}" target="_blank" rel="noopener noreferrer">
        ${rt(this.svgIcon)}
      </a>
    `}};hn.styles=[fl];ks([H({type:String})],hn.prototype,"label",2);ks([H({type:String})],hn.prototype,"svgIcon",2);ks([H({type:String})],hn.prototype,"url",2);hn=ks([Ke("link-icon")],hn);const xl=it`
  .chat-stage__header {
    display: flex;
    width: var(--width-base);
    margin: 0 auto var(--d-large);
    justify-content: center;
    align-items: center;

    @media (min-width: 1024px) {
      width: var(--width-narrow);
    }
  }
  .chat-stage__link svg {
    width: calc(var(--width-base) - var(--d-small));
    height: calc(var(--width-base) - var(--d-small));
    position: relative;
    z-index: 1;
  }
  .chat-stage__link {
    flex-shrink: 0;
    border-radius: calc(var(--radius-large) * 3);
    border: var(--border-thicker) solid transparent;
    background-origin: border-box;
    background-clip: content-box, border-box;
    background-size: cover;
    background-image: linear-gradient(to right, var(--c-accent-light), var(--c-accent-high));
    width: calc(var(--d-xlarge) * 2);
    height: calc(var(--d-xlarge) * 2);
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: var(--d-large);
    overflow: hidden;
    padding: var(--d-small);
    position: relative;
  }
  .chat-stage__link::after {
    content: '';
    border-radius: calc(var(--radius-large) * 3);
    width: calc(var(--width-base) - var(--d-small));
    height: calc(var(--width-base) - var(--d-small));
    position: absolute;
    background-color: var(--c-secondary);
  }
`;var _l=Object.defineProperty,wl=Object.getOwnPropertyDescriptor,Ss=(n,e,t,s)=>{for(var r=s>1?void 0:s?wl(e,t):e,i=n.length-1,a;i>=0;i--)(a=n[i])&&(r=(s?a(e,t,r):a(r))||r);return s&&r&&_l(e,t,r),r};let un=class extends Ne{constructor(){super(...arguments),this.pagetitle="",this.url="",this.svgIcon=""}render(){return $`
      <header class="chat-stage__header" data-testid="chat-branding">
        <link-icon url="${this.url}" svgIcon="${this.svgIcon}"></link-icon>
        <h1 class="chat-stage__hl">${this.pagetitle}</h1>
      </header>
    `}};un.styles=[xl];Ss([H({type:String})],un.prototype,"pagetitle",2);Ss([H({type:String})],un.prototype,"url",2);Ss([H({type:String})],un.prototype,"svgIcon",2);un=Ss([Ke("chat-stage")],un);const Cl=it`
  @keyframes spinneranimation {
    0% {
      transform: rotate(0deg);
    }
    100% {
      transform: rotate(360deg);
    }
  }
  p {
    display: flex;
    align-items: center;
  }
  svg {
    width: var(--d-large);
    height: 30px;
    fill: var(--c-accent-light);
    animation: spinneranimation 1s linear infinite;
    margin-right: 10px;
  }
`,kl=`<svg viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">\r
  <path d="M10 3.5C6.41015 3.5 3.5 6.41015 3.5 10C3.5 10.4142 3.16421 10.75 2.75 10.75C2.33579 10.75 2 10.4142 2 10C2 5.58172 5.58172 2 10 2C14.4183 2 18 5.58172 18 10C18 14.4183 14.4183 18 10 18C9.58579 18 9.25 17.6642 9.25 17.25C9.25 16.8358 9.58579 16.5 10 16.5C13.5899 16.5 16.5 13.5899 16.5 10C16.5 6.41015 13.5899 3.5 10 3.5Z" />\r
</svg>`;var Sl=Object.defineProperty,Al=Object.getOwnPropertyDescriptor,xa=(n,e,t,s)=>{for(var r=s>1?void 0:s?Al(e,t):e,i=n.length-1,a;i>=0;i--)(a=n[i])&&(r=(s?a(e,t,r):a(r))||r);return s&&r&&Sl(e,t,r),r};let gs=class extends Ne{constructor(){super(...arguments),this.label=""}render(){return $`
      <p data-testid="loading-indicator" aria-label="${this.label}">
        <span>${rt(kl)}</span>
        <span>${this.label}</span>
      </p>
    `}};gs.styles=[Cl];xa([H({type:String})],gs.prototype,"label",2);gs=xa([Ke("loading-indicator")],gs);const Tl=it`
  .subheadline--small {
    font-size: 12px;
    display: inline-block;
  }
  .items__list {
    border-top: none;
    padding: 0 var(--d-base);
    margin: var(--d-small) 0;
    display: block;
  }
  .items__listItem {
    display: inline-block;
    background-color: var(--c-accent-light);
    border-radius: var(--radius-small);
    text-decoration: none;
    padding: var(--d-xsmall);
    margin-top: 5px;
    font-size: var(--font-small);
  }
  .items__listItem.active {
    background-color: var(--c-accent-high);
  }
  .items__listItem:not(first-child) {
    margin-left: 5px;
  }
  .items__link {
    text-decoration: none;
    color: var(--text-color);
  }
  .items__listItem.active .items__link {
    color: var(--c-white);
  }
`;var Nl=Object.defineProperty,jl=Object.getOwnPropertyDescriptor,As=(n,e,t,s)=>{for(var r=s>1?void 0:s?jl(e,t):e,i=n.length-1,a;i>=0;i--)(a=n[i])&&(r=(s?a(e,t,r):a(r))||r);return s&&r&&Nl(e,t,r),r};let pn=class extends Ne{constructor(){super(...arguments),this.label=void 0,this.citations=void 0,this.selectedCitation=void 0}handleCitationClick(n,e){e.preventDefault(),this.selectedCitation=n;const t=new CustomEvent("on-citation-click",{detail:{citation:n},bubbles:!0,composed:!0});this.dispatchEvent(t)}compareCitation(n,e){return!!(n&&e&&n.text===e.text)}renderCitation(n){return n&&n.length>0?$`
        <ol class="items__list">
          ${this.label?$`<h3 class="subheadline--small">${this.label}</h3>`:""}
          ${n.map(e=>$`
              <li class="items__listItem ${this.compareCitation(e,this.selectedCitation)?"active":""}">
                <a
                  class="items__link"
                  href="#"
                  data-testid="citation"
                  @click="${t=>this.handleCitationClick(e,t)}"
                  >${e.ref}. ${e.text}</a
                >
              </li>
            `)}
        </ol>
      `:""}render(){return this.renderCitation(this.citations)}};pn.styles=[Tl];As([H({type:String})],pn.prototype,"label",2);As([H({type:Array})],pn.prototype,"citations",2);As([H({type:Object})],pn.prototype,"selectedCitation",2);pn=As([Ke("citation-list")],pn);const El=it`
  ul {
    margin-block-start: 0;
    margin-block-end: 0;
  }
  @keyframes chatmessageanimation {
    0% {
      opacity: 0.5;
      top: 150px;
    }
    100% {
      opacity: 1;
      top: 0;
    }
  }
  .chat__header--button {
    display: flex;
    align-items: center;
  }
  .chat__header {
    display: flex;
    align-items: top;
    justify-content: flex-end;
    padding: var(--d-base);
  }
  .chat__header--button {
    margin-right: var(--d-base);
  }
  .chat__list {
    color: var(--text-color);
    display: flex;
    flex-direction: column;
    list-style-position: inside;
    padding-inline-start: 0;
  }
  .chat__footer {
    width: 100%;
    height: calc(var(--d-large) + var(--d-base));
  }
  .chat__listItem {
    max-width: var(--width-wide);
    min-width: var(--width-base);
    display: flex;
    flex-direction: column;
    height: auto;

    @media (min-width: 768px) {
      max-width: 55%;
      min-width: var(--width-narrow);
    }
  }
  .chat__txt {
    animation: chatmessageanimation 0.5s ease-in-out;
    background-color: var(--c-secondary);
    color: var(--text-color);
    border-radius: var(--radius-base);
    margin-top: 8px;
    word-wrap: break-word;
    margin-block-end: 0;
    position: relative;
    box-shadow: var(--shadow);
    border: var(--border-thin) solid var(--c-light-gray);
  }
  .chat__txt.error {
    border: var(--border-base) solid var(--error-color);
    color: var(--error-color);
    padding: var(--d-base);
    background: var(--c-error-background);
  }
  .chat__txt.user-message {
    background: linear-gradient(to left, var(--c-accent-dark), var(--c-accent-high));
    color: var(--c-white);
    border: var(--border-thin) solid var(--c-accent-light);
  }
  .chat__listItem.user-message {
    align-self: flex-end;
  }
  .chat__txt--entry {
    padding: 0 var(--d-base);
  }
  .chat__txt--info {
    font-size: smaller;
    font-style: italic;
    margin: 0;
    margin-top: var(--border-thin);
  }
  .user-message .chat__txt--info {
    text-align: right;
  }
  .items__listWrapper {
    border-top: var(--border-thin) solid var(--c-light-gray);
    display: grid;
    padding: 0 var(--d-base);
    grid-template-columns: 1fr 18fr;
  }
  .items__listWrapper svg {
    fill: var(--c-accent-high);
    width: var(--d-large);
    margin: var(--d-large) auto;
  }
  svg {
    height: auto;
    fill: var(--text-color);
  }
  .items__list.followup {
    display: flex;
    flex-direction: row;
    padding: var(--d-base);
    list-style-type: none;
    flex-wrap: wrap;
  }
  .items__list.steps {
    padding: 0 var(--d-base) 0 var(--d-xlarge);
    list-style-type: disc;
  }
  .chat__citations {
    border-top: var(--border-thin) solid var(--c-light-gray);
  }
  .items__list {
    margin: var(--d-small) 0;
    display: block;
    padding: 0 var(--d-base);
  }
  .items__listItem--followup {
    cursor: pointer;
    padding: 0 var(--d-xsmall);
    border-radius: var(--radius-base);
    border: var(--border-thin) solid var(--c-accent-high);
    margin: var(--d-xsmall);
    transition: background-color 0.3s ease-in-out;
  }
  .items__listItem--followup:hover,
  .items__listItem--followup:focus {
    background-color: var(--c-accent-light);
    cursor: pointer;
  }
  .items__link {
    text-decoration: none;
    color: var(--text-color);
  }
  .steps .items__listItem--step {
    padding: var(--d-xsmall) 0;
    font-size: var(--font-base);
    line-height: 1;
  }
  .followup .items__link {
    color: var(--c-accent-high);
    display: block;
    padding: var(--d-xsmall) 0;
    border-bottom: var(--border-thin) solid var(--c-light-gray);
    font-size: var(--font-small);
  }
  .citation {
    background-color: var(--c-accent-light);
    border-radius: 3px;
    padding: calc(var(--d-small) / 5);
    margin-left: 3px;
  }
`,W={BOT_TYPING_EFFECT_INTERVAL:50,DISPLAY_DEFAULT_PROMPTS_BUTTON:"Not sure what to ask? Try our suggestions!",CHAT_BUTTON_LABEL_TEXT:"Ask Coach",CHAT_CANCEL_BUTTON_LABEL_TEXT:"Cancel Generation",CHAT_VOICE_BUTTON_LABEL_TEXT:"Voice input",CHAT_VOICE_REC_BUTTON_LABEL_TEXT:"Listening to voice input",CHAT_INPUT_PLACEHOLDER:"Share what's on your mind...",USER_IS_BOT:"Apex Coach",RESET_BUTTON_LABEL_TEXT:"X",RESET_BUTTON_TITLE_TEXT:"Reset current question",RESET_CHAT_BUTTON_TITLE:"Start new conversation",COPY_RESPONSE_BUTTON_LABEL_TEXT:"Copy Response",COPIED_SUCCESSFULLY_MESSAGE:"Response copied!",SHOW_THOUGH_PROCESS_BUTTON_LABEL_TEXT:"Show thought process",HIDE_THOUGH_PROCESS_BUTTON_LABEL_TEXT:"Hide thought process",LOADING_INDICATOR_TEXT:"Thinking and preparing your personalized guidance...",LOADING_TEXT:"Loading...",API_ERROR_MESSAGE:"Sorry, we encountered an issue. Please try again.",INVALID_REQUEST_ERROR:"Unable to generate a response for this. Please try rephrasing your question.",THOUGHT_PROCESS_LABEL:"Thought Process",SUPPORT_CONTEXT_LABEL:"Coaching Context",CITATIONS_LABEL:"Learn More:",CITATIONS_TAB_LABEL:"Citations",IS_CUSTOM_BRANDING:!0,BRANDING_URL:"#",BRANDING_HEADLINE:"Welcome to Your Personal Coaching Assistant",SHOW_CHAT_HISTORY_LABEL:"Show Chat History",HIDE_CHAT_HISTORY_LABEL:"Hide Chat History",CHAT_MAX_COUNT_TAG:"{MAX_CHAT_HISTORY}",CHAT_HISTORY_FOOTER_TEXT:"Showing past {MAX_CHAT_HISTORY} conversations"},Zn={TEASER_CTA_LABEL:"Start a conversation",HEADING_CHAT:"Talk with your coach",HEADING_ASK:"What would you like to explore?",DEFAULT_PROMPTS:[{description:"Help me work through a challenge I'm facing"},{description:"I want to improve my communication skills"},{description:"Guide me through the Inside Out Method"}]},Us={approach:"rrr",overrides:{retrieval_mode:"hybrid",semantic_ranker:!0,semantic_captions:!1,suggest_followup_questions:!0}},or={url:"http://localhost:3000",method:"POST",stream:!0},_i=5,zs=Symbol.for("@inversifyjs/common/islazyServiceIdentifier");var wi,Xn,Ci;let Il=(wi=zs,Ci=class{constructor(n){_(this,wi),yt(this,Xn),mt(this,Xn,n),this[zs]=!0}static is(n){return typeof n=="object"&&n!==null&&n[zs]===!0}unwrap(){return ae(this,Xn).call(this)}},Xn=new WeakMap,Ci);function xt(n,e){return Reflect.getMetadata(e,n)}function ki(n,e,t,s){const r=s(xt(n,e)??t);Reflect.defineMetadata(e,r,n)}const Ts="named",Or="name",Pr="unmanaged",Lr="optional",Dr="inject",Mr="multi_inject",_a="post_construct",wa="pre_destroy",$l=[Dr,Mr,Or,Pr,Ts,Lr],Fs=Symbol.for("@inversifyjs/core/InversifyCoreError");var Si,Ai;let Jt=class Ca extends(Ai=Error,Si=Fs,Ai){constructor(e,t,s){super(t,s),_(this,Si),_(this,"kind"),this[Fs]=!0,this.kind=e}static is(e){return typeof e=="object"&&e!==null&&e[Fs]===!0}static isErrorOfKind(e,t){return Ca.is(e)&&e.kind===t}};var _t,Re;function ka(n,e){const t=[];for(let s=0;s<e.length;++s)e[s]===void 0&&t.push(s);if(t.length>0)throw new Jt(_t.missingInjectionDecorator,`Found unexpected missing metadata on type "${n.name}" at constructor indexes "${t.join('", "')}".

Are you using @inject, @multiInject or @unmanaged decorators at those indexes?

If you're using typescript and want to rely on auto injection, set "emitDecoratorMetadata" compiler option to true`)}function Sa(n){return{kind:Re.singleInjection,name:void 0,optional:!1,tags:new Map,targetName:void 0,value:n}}function Ns(n){const e=n.find((a=>a.key===Dr)),t=n.find((a=>a.key===Mr));if(n.find((a=>a.key===Pr))!==void 0)return(function(a,l){if(l!==void 0||a!==void 0)throw new Jt(_t.missingInjectionDecorator,"Expected a single @inject, @multiInject or @unmanaged metadata");return{kind:Re.unmanaged}})(e,t);if(t===void 0&&e===void 0)throw new Jt(_t.missingInjectionDecorator,"Expected @inject, @multiInject or @unmanaged metadata");const s=n.find((a=>a.key===Ts)),r=n.find((a=>a.key===Lr)),i=n.find((a=>a.key===Or));return{kind:e===void 0?Re.multipleInjection:Re.singleInjection,name:s==null?void 0:s.value,optional:r!==void 0,tags:new Map(n.filter((a=>$l.every((l=>a.key!==l)))).map((a=>[a.key,a.value]))),targetName:i==null?void 0:i.value,value:e===void 0?t==null?void 0:t.value:e.value}}function Aa(n,e,t){try{return Ns(t)}catch(s){throw Jt.isErrorOfKind(s,_t.missingInjectionDecorator)?new Jt(_t.missingInjectionDecorator,`Expected a single @inject, @multiInject or @unmanaged decorator at type "${n.name}" at constructor arguments at index "${e.toString()}"`,{cause:s}):s}}function Rl(n){const e=xt(n,"design:paramtypes"),t=xt(n,"inversify:tagged"),s=[];if(t!==void 0)for(const[r,i]of Object.entries(t)){const a=parseInt(r);s[a]=Aa(n,a,i)}if(e!==void 0){for(let r=0;r<e.length;++r)if(s[r]===void 0){const i=e[r];s[r]=Sa(i)}}return ka(n,s),s}function Ta(n,e,t){try{return Ns(t)}catch(s){throw Jt.isErrorOfKind(s,_t.missingInjectionDecorator)?new Jt(_t.missingInjectionDecorator,`Expected a single @inject, @multiInject or @unmanaged decorator at type "${n.name}" at property "${e.toString()}"`,{cause:s}):s}}function Na(n){const e=xt(n,"inversify:tagged_props"),t=new Map;if(e!==void 0)for(const s of Reflect.ownKeys(e)){const r=e[s];t.set(s,Ta(n,s,r))}return t}function Ol(n){const e=xt(n,_a),t=xt(n,wa);return{constructorArguments:Rl(n),lifecycle:{postConstructMethodName:e==null?void 0:e.value,preDestroyMethodName:t==null?void 0:t.value},properties:Na(n)}}function Pl(n,e){const t=e.getConstructorMetadata(n),s=[];for(const[r,i]of Object.entries(t.userGeneratedMetadata)){const a=parseInt(r);s[a]=Aa(n,a,i)}if(t.compilerGeneratedMetadata!==void 0){for(let r=0;r<t.compilerGeneratedMetadata.length;++r)if(s[r]===void 0){const i=t.compilerGeneratedMetadata[r];s[r]=Sa(i)}}return ka(n,s),s}function ja(n,e){const t=e.getPropertiesMetadata(n),s=new Map;for(const r of Reflect.ownKeys(t)){const i=t[r];s.set(r,Ta(n,r,i))}return s}function Ll(n,e){const t=xt(n,_a),s=xt(n,wa);return{constructorArguments:Pl(n,e),lifecycle:{postConstructMethodName:t==null?void 0:t.value,preDestroyMethodName:s==null?void 0:s.value},properties:ja(n,e)}}function Ti(n){const e=Object.getPrototypeOf(n.prototype);return e==null?void 0:e.constructor}function Dl(n){return n.kind===Re.unmanaged?[{key:Pr,value:!0}]:(function(e){const t=[Ml(e)];e.name!==void 0&&t.push({key:Ts,value:e.name}),e.optional&&t.push({key:Lr,value:!0});for(const[s,r]of e.tags)t.push({key:s,value:r});return e.targetName!==void 0&&t.push({key:Or,value:e.targetName}),t})(n)}function Ml(n){let e;switch(n.kind){case Re.multipleInjection:e={key:Mr,value:n.value};break;case Re.singleInjection:e={key:Dr,value:n.value}}return e}(function(n){n[n.injectionDecoratorConflict=0]="injectionDecoratorConflict",n[n.missingInjectionDecorator=1]="missingInjectionDecorator",n[n.planning=2]="planning",n[n.unknown=3]="unknown"})(_t||(_t={})),(function(n){n[n.multipleInjection=0]="multipleInjection",n[n.singleInjection=1]="singleInjection",n[n.unmanaged=2]="unmanaged"})(Re||(Re={}));var Tt,Ni;let Bl=(Ni=class{constructor(n){yt(this,Tt),mt(this,Tt,n)}startsWith(n){return ae(this,Tt).startsWith(n)}endsWith(n){return ae(this,Tt).endsWith(n)}contains(n){return ae(this,Tt).includes(n)}equals(n){return ae(this,Tt)===n}value(){return ae(this,Tt)}},Tt=new WeakMap,Ni);const qs="@inversifyjs/core/targetId";var Ae,ss,rs,on,is,as;class fs{constructor(e,t,s){yt(this,Ae),yt(this,ss),yt(this,rs),yt(this,on),yt(this,is),yt(this,as),mt(this,ss,(function(){const r=xt(Object,qs)??0;return r===Number.MAX_SAFE_INTEGER?ki(Object,qs,r,(()=>Number.MIN_SAFE_INTEGER)):ki(Object,qs,r,(i=>i+1)),r})()),mt(this,rs,e),mt(this,on,void 0),mt(this,Ae,t),mt(this,is,new Bl(typeof e=="string"?e:e.toString().slice(7,-1))),mt(this,as,s)}get id(){return ae(this,ss)}get identifier(){return ae(this,rs)}get metadata(){return ae(this,on)===void 0&&mt(this,on,Dl(ae(this,Ae))),ae(this,on)}get name(){return ae(this,is)}get type(){return ae(this,as)}get serviceIdentifier(){return Il.is(ae(this,Ae).value)?ae(this,Ae).value.unwrap():ae(this,Ae).value}getCustomTags(){return[...ae(this,Ae).tags.entries()].map((([e,t])=>({key:e,value:t})))}getNamedTag(){return ae(this,Ae).name===void 0?null:{key:Ts,value:ae(this,Ae).name}}hasTag(e){return this.metadata.some((t=>t.key===e))}isArray(){return ae(this,Ae).kind===Re.multipleInjection}isNamed(){return ae(this,Ae).name!==void 0}isOptional(){return ae(this,Ae).optional}isTagged(){return ae(this,Ae).tags.size>0}matchesArray(e){return this.isArray()&&ae(this,Ae).value===e}matchesNamedTag(e){return ae(this,Ae).name===e}matchesTag(e){return t=>this.metadata.some((s=>s.key===e&&s.value===t))}}Ae=new WeakMap,ss=new WeakMap,rs=new WeakMap,on=new WeakMap,is=new WeakMap,as=new WeakMap;const Ea=n=>(function(e,t){return function(s){const r=e(s);let i=Ti(s);for(;i!==void 0&&i!==Object;){const l=t(i);for(const[c,h]of l)r.properties.has(c)||r.properties.set(c,h);i=Ti(i)}const a=[];for(const l of r.constructorArguments)if(l.kind!==Re.unmanaged){const c=l.targetName??"";a.push(new fs(c,l,"ConstructorArgument"))}for(const[l,c]of r.properties)if(c.kind!==Re.unmanaged){const h=c.targetName??l;a.push(new fs(h,c,"ClassProperty"))}return a}})(n===void 0?Ol:e=>Ll(e,n),n===void 0?Na:e=>ja(e,n)),Xe="named",Hl="unmanaged",Ul="optional",zl="inject",Fl="multi_inject",ql="inversify:tagged",Vl="inversify:tagged_props",ji="inversify:paramtypes",Ia="design:paramtypes",Ei="post_construct",lr="pre_destroy",fe={Request:"Request",Singleton:"Singleton",Transient:"Transient"},te={ConstantValue:"ConstantValue",Constructor:"Constructor",DynamicValue:"DynamicValue",Factory:"Factory",Function:"Function",Instance:"Instance",Invalid:"Invalid",Provider:"Provider"},$a={ConstructorArgument:"ConstructorArgument",Variable:"Variable"};let Wl=0;function js(){return Wl++}class Br{constructor(e,t){_(this,"id"),_(this,"moduleId"),_(this,"activated"),_(this,"serviceIdentifier"),_(this,"implementationType"),_(this,"cache"),_(this,"dynamicValue"),_(this,"scope"),_(this,"type"),_(this,"factory"),_(this,"provider"),_(this,"constraint"),_(this,"onActivation"),_(this,"onDeactivation"),this.id=js(),this.activated=!1,this.serviceIdentifier=e,this.scope=t,this.type=te.Invalid,this.constraint=s=>!0,this.implementationType=null,this.cache=null,this.factory=null,this.provider=null,this.onActivation=null,this.onDeactivation=null,this.dynamicValue=null}clone(){const e=new Br(this.serviceIdentifier,this.scope);return e.activated=e.scope===fe.Singleton&&this.activated,e.implementationType=this.implementationType,e.dynamicValue=this.dynamicValue,e.scope=this.scope,e.type=this.type,e.factory=this.factory,e.provider=this.provider,e.constraint=this.constraint,e.onActivation=this.onActivation,e.onDeactivation=this.onDeactivation,e.cache=this.cache,e}}const Ii="NULL argument",$i="Key Not Found",Gl="Ambiguous match found for serviceIdentifier:",Yl="No matching bindings found for serviceIdentifier:",cr=(n,e)=>`onDeactivation() error in class ${n}: ${e}`;class Zl{getConstructorMetadata(e){return{compilerGeneratedMetadata:Reflect.getMetadata(Ia,e)??[],userGeneratedMetadata:Reflect.getMetadata(ql,e)??{}}}getPropertiesMetadata(e){return Reflect.getMetadata(Vl,e)??{}}}var ln;function Ra(n){return n instanceof RangeError||n.message==="Maximum call stack size exceeded"}(function(n){n[n.MultipleBindingsAvailable=2]="MultipleBindingsAvailable",n[n.NoBindingsAvailable=0]="NoBindingsAvailable",n[n.OnlyOneBindingAvailable=1]="OnlyOneBindingAvailable"})(ln||(ln={}));function Et(n){return typeof n=="function"?n.name:typeof n=="symbol"?n.toString():n}function Ri(n,e,t){let s="";const r=t(n,e);return r.length!==0&&(s=`
Registered bindings:`,r.forEach((i=>{let a="Object";i.implementationType!==null&&(a=La(i.implementationType)),s=`${s}
 ${a}`,i.constraint.metaData&&(s=`${s} - ${i.constraint.metaData}`)}))),s}function Oa(n,e){return n.parentRequest!==null&&(n.parentRequest.serviceIdentifier===e||Oa(n.parentRequest,e))}function Pa(n){n.childRequests.forEach((e=>{if(Oa(n,e.serviceIdentifier)){const t=(function(s){return(function r(i,a=[]){const l=Et(i.serviceIdentifier);return a.push(l),i.parentRequest!==null?r(i.parentRequest,a):a})(s).reverse().join(" --> ")})(e);throw new Error(`Circular dependency found: ${t}`)}Pa(e)}))}function La(n){if(n.name!=null&&n.name!=="")return n.name;{const e=n.toString(),t=e.match(/^function\s*([^\s(]+)/);return t===null?`Anonymous function: ${e}`:t[1]}}function Oi(n){return`{"key":"${n.key.toString()}","value":"${n.value.toString()}"}`}class Da{constructor(e){_(this,"id"),_(this,"container"),_(this,"plan"),_(this,"currentRequest"),this.id=js(),this.container=e}addPlan(e){this.plan=e}setCurrentRequest(e){this.currentRequest=e}}class os{constructor(e,t){_(this,"key"),_(this,"value"),this.key=e,this.value=t}toString(){return this.key===Xe?`named: ${String(this.value).toString()} `:`tagged: { key:${this.key.toString()}, value: ${String(this.value)} }`}}class Xl{constructor(e,t){_(this,"parentContext"),_(this,"rootRequest"),this.parentContext=e,this.rootRequest=t}}function Ma(n,e){const t=(function(l){const c=Object.getPrototypeOf(l.prototype);return c==null?void 0:c.constructor})(e);if(t===void 0||t===Object)return 0;const s=Ea(n)(t),r=s.map((l=>l.metadata.filter((c=>c.key===Hl)))),i=[].concat.apply([],r).length,a=s.length-i;return a>0?a:Ma(n,t)}class Hn{constructor(e,t,s,r,i){_(this,"id"),_(this,"serviceIdentifier"),_(this,"parentContext"),_(this,"parentRequest"),_(this,"bindings"),_(this,"childRequests"),_(this,"target"),_(this,"requestScope"),this.id=js(),this.serviceIdentifier=e,this.parentContext=t,this.parentRequest=s,this.target=i,this.childRequests=[],this.bindings=Array.isArray(r)?r:[r],this.requestScope=s===null?new Map:null}addChildRequest(e,t,s){const r=new Hn(e,this.parentContext,this,t,s);return this.childRequests.push(r),r}}function ms(n){return n._bindingDictionary}function Pi(n,e,t,s,r){let i=Nn(t.container,r.serviceIdentifier),a=[];return i.length===ln.NoBindingsAvailable&&t.container.options.autoBindInjectable===!0&&typeof r.serviceIdentifier=="function"&&n.getConstructorMetadata(r.serviceIdentifier).compilerGeneratedMetadata&&(t.container.bind(r.serviceIdentifier).toSelf(),i=Nn(t.container,r.serviceIdentifier)),a=e?i:i.filter((l=>{const c=new Hn(l.serviceIdentifier,t,s,l,r);return l.constraint(c)})),(function(l,c,h,u,g){switch(c.length){case ln.NoBindingsAvailable:if(u.isOptional())return c;{const p=Et(l);let v=Yl;throw v+=(function(w,L){if(L.isTagged()||L.isNamed()){let U="";const Q=L.getNamedTag(),B=L.getCustomTags();return Q!==null&&(U+=Oi(Q)+`
`),B!==null&&B.forEach((R=>{U+=Oi(R)+`
`})),` ${w}
 ${w} - ${U}`}return` ${w}`})(p,u),v+=Ri(g,p,Nn),h!==null&&(v+=`
Trying to resolve bindings for "${Et(h.serviceIdentifier)}"`),new Error(v)}case ln.OnlyOneBindingAvailable:return c;case ln.MultipleBindingsAvailable:default:if(u.isArray())return c;{const p=Et(l);let v=`${Gl} ${p}`;throw v+=Ri(g,p,Nn),new Error(v)}}})(r.serviceIdentifier,a,s,r,t.container),a}function Ba(n,e){const t=e.isMultiInject?Fl:zl,s=[new os(t,n)];return e.customTag!==void 0&&s.push(new os(e.customTag.key,e.customTag.value)),e.isOptional===!0&&s.push(new os(Ul,!0)),s}function Ha(n,e,t,s,r,i){let a,l;if(r===null){a=Pi(n,e,s,null,i),l=new Hn(t,s,null,a,i);const c=new Xl(s,l);s.addPlan(c)}else a=Pi(n,e,s,r,i),l=r.addChildRequest(i.serviceIdentifier,a,i);a.forEach((c=>{let h=null;if(i.isArray())h=l.addChildRequest(c.serviceIdentifier,c,i);else{if(c.cache!==null)return;h=l}if(c.type===te.Instance&&c.implementationType!==null){const u=(function(g,p){return Ea(g)(p)})(n,c.implementationType);if(s.container.options.skipBaseClassChecks!==!0){const g=Ma(n,c.implementationType);if(u.length<g){const p=`The number of constructor arguments in the derived class ${La(c.implementationType)} must be >= than the number of constructor arguments of its base class.`;throw new Error(p)}}u.forEach((g=>{Ha(n,!1,g.serviceIdentifier,s,h,g)}))}}))}function Nn(n,e){let t=[];const s=ms(n);return s.hasKey(e)?t=s.get(e):n.parent!==null&&(t=Nn(n.parent,e)),t}function Ql(n,e,t,s,r,i=!1){const a=new Da(e),l=(function(c,h,u){const g=Ba(h,u),p=Ns(g);if(p.kind===Re.unmanaged)throw new Error("Unexpected metadata when creating target");return new fs("",p,c)})(t,s,r);try{return Ha(n,i,s,a,null,l),a}catch(c){throw Ra(c)&&Pa(a.plan.rootRequest),c}}function $e(n){return(typeof n=="object"&&n!==null||typeof n=="function")&&typeof n.then=="function"}function Ua(n){return!!$e(n)||Array.isArray(n)&&n.some($e)}const Kl=(n,e,t)=>{n.has(e.id)||n.set(e.id,t)},Jl=(n,e)=>{n.cache=e,n.activated=!0,$e(e)&&ec(n,e)},ec=async(n,e)=>{try{const t=await e;n.cache=t}catch(t){throw n.cache=null,n.activated=!1,t}};var En;(function(n){n.DynamicValue="toDynamicValue",n.Factory="toFactory",n.Provider="toProvider"})(En||(En={}));function tc(n,e,t){let s;if(e.length>0){const r=(function(a,l){return a.reduce(((c,h)=>{const u=l(h);return h.target.type===$a.ConstructorArgument?c.constructorInjections.push(u):(c.propertyRequests.push(h),c.propertyInjections.push(u)),c.isAsync||(c.isAsync=Ua(u)),c}),{constructorInjections:[],isAsync:!1,propertyInjections:[],propertyRequests:[]})})(e,t),i={...r,constr:n};s=r.isAsync?(async function(a){const l=await Di(a.constructorInjections),c=await Di(a.propertyInjections);return Li({...a,constructorInjections:l,propertyInjections:c})})(i):Li(i)}else s=new n;return s}function Li(n){const e=new n.constr(...n.constructorInjections);return n.propertyRequests.forEach(((t,s)=>{const r=t.target.identifier,i=n.propertyInjections[s];t.target.isOptional()&&i===void 0||(e[r]=i)})),e}async function Di(n){const e=[];for(const t of n)Array.isArray(t)?e.push(Promise.all(t)):e.push(t);return Promise.all(e)}function Mi(n,e){const t=(function(s,r){var i;if(Reflect.hasMetadata(Ei,s)){const c=Reflect.getMetadata(Ei,s);try{return(i=r[c.value])==null?void 0:i.call(r)}catch(h){if(h instanceof Error)throw new Error((a=s.name,l=h.message,`@postConstruct error in class ${a}: ${l}`))}}var a,l})(n,e);return $e(t)?t.then((()=>e)):e}function nc(n,e){n.scope!==fe.Singleton&&(function(t,s){const r=`Class cannot be instantiated in ${t.scope===fe.Request?"request":"transient"} scope.`;if(typeof t.onDeactivation=="function")throw new Error(cr(s.name,r));if(Reflect.hasMetadata(lr,s))throw new Error(`@preDestroy error in class ${s.name}: ${r}`)})(n,e)}const Hr=n=>e=>{e.parentContext.setCurrentRequest(e);const t=e.bindings,s=e.childRequests,r=e.target&&e.target.isArray(),i=!(e.parentRequest&&e.parentRequest.target&&e.target&&e.parentRequest.target.matchesArray(e.target.serviceIdentifier));if(r&&i)return s.map((a=>Hr(n)(a)));{if(e.target.isOptional()&&t.length===0)return;const a=t[0];return ac(n,e,a)}},sc=(n,e)=>{const t=(s=>{switch(s.type){case te.Factory:return{factory:s.factory,factoryType:En.Factory};case te.Provider:return{factory:s.provider,factoryType:En.Provider};case te.DynamicValue:return{factory:s.dynamicValue,factoryType:En.DynamicValue};default:throw new Error(`Unexpected factory type ${s.type}`)}})(n);return((s,r)=>{try{return s()}catch(i){throw Ra(i)?r():i}})((()=>t.factory.bind(n)(e)),(()=>{return new Error((s=t.factoryType,r=e.currentRequest.serviceIdentifier.toString(),`It looks like there is a circular dependency in one of the '${s}' bindings. Please investigate bindings with service identifier '${r}'.`));var s,r}))},rc=(n,e,t)=>{let s;const r=e.childRequests;switch((i=>{let a=null;switch(i.type){case te.ConstantValue:case te.Function:a=i.cache;break;case te.Constructor:case te.Instance:a=i.implementationType;break;case te.DynamicValue:a=i.dynamicValue;break;case te.Provider:a=i.provider;break;case te.Factory:a=i.factory}if(a===null){const l=Et(i.serviceIdentifier);throw new Error(`Invalid binding type: ${l}`)}})(t),t.type){case te.ConstantValue:case te.Function:s=t.cache;break;case te.Constructor:s=t.implementationType;break;case te.Instance:s=(function(i,a,l,c){nc(i,a);const h=tc(a,l,c);return $e(h)?h.then((u=>Mi(a,u))):Mi(a,h)})(t,t.implementationType,r,Hr(n));break;default:s=sc(t,e.parentContext)}return s},ic=(n,e,t)=>{let s=((r,i)=>i.scope===fe.Singleton&&i.activated?i.cache:i.scope===fe.Request&&r.has(i.id)?r.get(i.id):null)(n,e);return s!==null||(s=t(),((r,i,a)=>{i.scope===fe.Singleton&&Jl(i,a),i.scope===fe.Request&&Kl(r,i,a)})(n,e,s)),s},ac=(n,e,t)=>ic(n,t,(()=>{let s=rc(n,e,t);return s=$e(s)?s.then((r=>Bi(e,t,r))):Bi(e,t,s),s}));function Bi(n,e,t){let s=oc(n.parentContext,e,t);const r=dc(n.parentContext.container);let i,a=r.next();do{i=a.value;const l=n.parentContext,c=n.serviceIdentifier,h=cc(i,c);s=$e(s)?za(h,l,s):lc(h,l,s),a=r.next()}while(a.done!==!0&&!ms(i).hasKey(n.serviceIdentifier));return s}const oc=(n,e,t)=>{let s;return s=typeof e.onActivation=="function"?e.onActivation(n,t):t,s},lc=(n,e,t)=>{let s=n.next();for(;s.done!==!0;){if($e(t=s.value(e,t)))return za(n,e,t);s=n.next()}return t},za=async(n,e,t)=>{let s=await t,r=n.next();for(;r.done!==!0;)s=await r.value(e,s),r=n.next();return s},cc=(n,e)=>{const t=n._activations;return t.hasKey(e)?t.get(e).values():[].values()},dc=n=>{const e=[n];let t=n.parent;for(;t!==null;)e.push(t),t=t.parent;return{next:()=>{const s=e.pop();return s!==void 0?{done:!1,value:s}:{done:!0,value:void 0}}}},gt=(n,e)=>{const t=n.parentRequest;return t!==null&&(!!e(t)||gt(t,e))},jn=n=>e=>{const t=s=>s!==null&&s.target!==null&&s.target.matchesTag(n)(e);return t.metaData=new os(n,e),t},Qn=jn(Xe),Vs=n=>e=>{let t=null;if(e!==null){if(t=e.bindings[0],typeof n=="string")return t.serviceIdentifier===n;{const s=e.bindings[0].implementationType;return n===s}}return!1};class ys{constructor(e){_(this,"_binding"),this._binding=e}when(e){return this._binding.constraint=e,new Ce(this._binding)}whenTargetNamed(e){return this._binding.constraint=Qn(e),new Ce(this._binding)}whenTargetIsDefault(){return this._binding.constraint=e=>e===null?!1:e.target!==null&&!e.target.isNamed()&&!e.target.isTagged(),new Ce(this._binding)}whenTargetTagged(e,t){return this._binding.constraint=jn(e)(t),new Ce(this._binding)}whenInjectedInto(e){return this._binding.constraint=t=>t!==null&&Vs(e)(t.parentRequest),new Ce(this._binding)}whenParentNamed(e){return this._binding.constraint=t=>t!==null&&Qn(e)(t.parentRequest),new Ce(this._binding)}whenParentTagged(e,t){return this._binding.constraint=s=>s!==null&&jn(e)(t)(s.parentRequest),new Ce(this._binding)}whenAnyAncestorIs(e){return this._binding.constraint=t=>t!==null&&gt(t,Vs(e)),new Ce(this._binding)}whenNoAncestorIs(e){return this._binding.constraint=t=>t!==null&&!gt(t,Vs(e)),new Ce(this._binding)}whenAnyAncestorNamed(e){return this._binding.constraint=t=>t!==null&&gt(t,Qn(e)),new Ce(this._binding)}whenNoAncestorNamed(e){return this._binding.constraint=t=>t!==null&&!gt(t,Qn(e)),new Ce(this._binding)}whenAnyAncestorTagged(e,t){return this._binding.constraint=s=>s!==null&&gt(s,jn(e)(t)),new Ce(this._binding)}whenNoAncestorTagged(e,t){return this._binding.constraint=s=>s!==null&&!gt(s,jn(e)(t)),new Ce(this._binding)}whenAnyAncestorMatches(e){return this._binding.constraint=t=>t!==null&&gt(t,e),new Ce(this._binding)}whenNoAncestorMatches(e){return this._binding.constraint=t=>t!==null&&!gt(t,e),new Ce(this._binding)}}class Ce{constructor(e){_(this,"_binding"),this._binding=e}onActivation(e){return this._binding.onActivation=e,new ys(this._binding)}onDeactivation(e){return this._binding.onDeactivation=e,new ys(this._binding)}}class vt{constructor(e){_(this,"_bindingWhenSyntax"),_(this,"_bindingOnSyntax"),_(this,"_binding"),this._binding=e,this._bindingWhenSyntax=new ys(this._binding),this._bindingOnSyntax=new Ce(this._binding)}when(e){return this._bindingWhenSyntax.when(e)}whenTargetNamed(e){return this._bindingWhenSyntax.whenTargetNamed(e)}whenTargetIsDefault(){return this._bindingWhenSyntax.whenTargetIsDefault()}whenTargetTagged(e,t){return this._bindingWhenSyntax.whenTargetTagged(e,t)}whenInjectedInto(e){return this._bindingWhenSyntax.whenInjectedInto(e)}whenParentNamed(e){return this._bindingWhenSyntax.whenParentNamed(e)}whenParentTagged(e,t){return this._bindingWhenSyntax.whenParentTagged(e,t)}whenAnyAncestorIs(e){return this._bindingWhenSyntax.whenAnyAncestorIs(e)}whenNoAncestorIs(e){return this._bindingWhenSyntax.whenNoAncestorIs(e)}whenAnyAncestorNamed(e){return this._bindingWhenSyntax.whenAnyAncestorNamed(e)}whenAnyAncestorTagged(e,t){return this._bindingWhenSyntax.whenAnyAncestorTagged(e,t)}whenNoAncestorNamed(e){return this._bindingWhenSyntax.whenNoAncestorNamed(e)}whenNoAncestorTagged(e,t){return this._bindingWhenSyntax.whenNoAncestorTagged(e,t)}whenAnyAncestorMatches(e){return this._bindingWhenSyntax.whenAnyAncestorMatches(e)}whenNoAncestorMatches(e){return this._bindingWhenSyntax.whenNoAncestorMatches(e)}onActivation(e){return this._bindingOnSyntax.onActivation(e)}onDeactivation(e){return this._bindingOnSyntax.onDeactivation(e)}}class hc{constructor(e){_(this,"_binding"),this._binding=e}inRequestScope(){return this._binding.scope=fe.Request,new vt(this._binding)}inSingletonScope(){return this._binding.scope=fe.Singleton,new vt(this._binding)}inTransientScope(){return this._binding.scope=fe.Transient,new vt(this._binding)}}class Hi{constructor(e){_(this,"_bindingInSyntax"),_(this,"_bindingWhenSyntax"),_(this,"_bindingOnSyntax"),_(this,"_binding"),this._binding=e,this._bindingWhenSyntax=new ys(this._binding),this._bindingOnSyntax=new Ce(this._binding),this._bindingInSyntax=new hc(e)}inRequestScope(){return this._bindingInSyntax.inRequestScope()}inSingletonScope(){return this._bindingInSyntax.inSingletonScope()}inTransientScope(){return this._bindingInSyntax.inTransientScope()}when(e){return this._bindingWhenSyntax.when(e)}whenTargetNamed(e){return this._bindingWhenSyntax.whenTargetNamed(e)}whenTargetIsDefault(){return this._bindingWhenSyntax.whenTargetIsDefault()}whenTargetTagged(e,t){return this._bindingWhenSyntax.whenTargetTagged(e,t)}whenInjectedInto(e){return this._bindingWhenSyntax.whenInjectedInto(e)}whenParentNamed(e){return this._bindingWhenSyntax.whenParentNamed(e)}whenParentTagged(e,t){return this._bindingWhenSyntax.whenParentTagged(e,t)}whenAnyAncestorIs(e){return this._bindingWhenSyntax.whenAnyAncestorIs(e)}whenNoAncestorIs(e){return this._bindingWhenSyntax.whenNoAncestorIs(e)}whenAnyAncestorNamed(e){return this._bindingWhenSyntax.whenAnyAncestorNamed(e)}whenAnyAncestorTagged(e,t){return this._bindingWhenSyntax.whenAnyAncestorTagged(e,t)}whenNoAncestorNamed(e){return this._bindingWhenSyntax.whenNoAncestorNamed(e)}whenNoAncestorTagged(e,t){return this._bindingWhenSyntax.whenNoAncestorTagged(e,t)}whenAnyAncestorMatches(e){return this._bindingWhenSyntax.whenAnyAncestorMatches(e)}whenNoAncestorMatches(e){return this._bindingWhenSyntax.whenNoAncestorMatches(e)}onActivation(e){return this._bindingOnSyntax.onActivation(e)}onDeactivation(e){return this._bindingOnSyntax.onDeactivation(e)}}class uc{constructor(e){_(this,"_binding"),this._binding=e}to(e){return this._binding.type=te.Instance,this._binding.implementationType=e,new Hi(this._binding)}toSelf(){if(typeof this._binding.serviceIdentifier!="function")throw new Error("The toSelf function can only be applied when a constructor is used as service identifier");const e=this._binding.serviceIdentifier;return this.to(e)}toConstantValue(e){return this._binding.type=te.ConstantValue,this._binding.cache=e,this._binding.dynamicValue=null,this._binding.implementationType=null,this._binding.scope=fe.Singleton,new vt(this._binding)}toDynamicValue(e){return this._binding.type=te.DynamicValue,this._binding.cache=null,this._binding.dynamicValue=e,this._binding.implementationType=null,new Hi(this._binding)}toConstructor(e){return this._binding.type=te.Constructor,this._binding.implementationType=e,this._binding.scope=fe.Singleton,new vt(this._binding)}toFactory(e){return this._binding.type=te.Factory,this._binding.factory=e,this._binding.scope=fe.Singleton,new vt(this._binding)}toFunction(e){if(typeof e!="function")throw new Error("Value provided to function binding must be a function!");const t=this.toConstantValue(e);return this._binding.type=te.Function,this._binding.scope=fe.Singleton,t}toAutoFactory(e){return this._binding.type=te.Factory,this._binding.factory=t=>()=>t.container.get(e),this._binding.scope=fe.Singleton,new vt(this._binding)}toAutoNamedFactory(e){return this._binding.type=te.Factory,this._binding.factory=t=>s=>t.container.getNamed(e,s),new vt(this._binding)}toProvider(e){return this._binding.type=te.Provider,this._binding.provider=e,this._binding.scope=fe.Singleton,new vt(this._binding)}toService(e){this._binding.type=te.DynamicValue,Object.defineProperty(this._binding,"cache",{configurable:!0,enumerable:!0,get:()=>null,set(t){}}),this._binding.dynamicValue=t=>{try{return t.container.get(e)}catch{return t.container.getAsync(e)}},this._binding.implementationType=null}}class Ur{constructor(){_(this,"bindings"),_(this,"activations"),_(this,"deactivations"),_(this,"middleware"),_(this,"moduleActivationStore")}static of(e,t,s,r,i){const a=new Ur;return a.bindings=e,a.middleware=t,a.deactivations=r,a.activations=s,a.moduleActivationStore=i,a}}class bt{constructor(){_(this,"_map"),this._map=new Map}getMap(){return this._map}add(e,t){if(this._checkNonNulish(e),t==null)throw new Error(Ii);const s=this._map.get(e);s!==void 0?s.push(t):this._map.set(e,[t])}get(e){this._checkNonNulish(e);const t=this._map.get(e);if(t!==void 0)return t;throw new Error($i)}remove(e){if(this._checkNonNulish(e),!this._map.delete(e))throw new Error($i)}removeIntersection(e){this.traverse(((t,s)=>{const r=e.hasKey(t)?e.get(t):void 0;if(r!==void 0){const i=s.filter((a=>!r.some((l=>a===l))));this._setValue(t,i)}}))}removeByCondition(e){const t=[];return this._map.forEach(((s,r)=>{const i=[];for(const a of s)e(a)?t.push(a):i.push(a);this._setValue(r,i)})),t}hasKey(e){return this._checkNonNulish(e),this._map.has(e)}clone(){const e=new bt;return this._map.forEach(((t,s)=>{t.forEach((r=>{var i;e.add(s,typeof(i=r)=="object"&&i!==null&&"clone"in i&&typeof i.clone=="function"?r.clone():r)}))})),e}traverse(e){this._map.forEach(((t,s)=>{e(s,t)}))}_checkNonNulish(e){if(e==null)throw new Error(Ii)}_setValue(e,t){t.length>0?this._map.set(e,t):this._map.delete(e)}}class zr{constructor(){_(this,"_map",new Map)}remove(e){const t=this._map.get(e);return t===void 0?this._getEmptyHandlersStore():(this._map.delete(e),t)}addDeactivation(e,t,s){this._getModuleActivationHandlers(e).onDeactivations.add(t,s)}addActivation(e,t,s){this._getModuleActivationHandlers(e).onActivations.add(t,s)}clone(){const e=new zr;return this._map.forEach(((t,s)=>{e._map.set(s,{onActivations:t.onActivations.clone(),onDeactivations:t.onDeactivations.clone()})})),e}_getModuleActivationHandlers(e){let t=this._map.get(e);return t===void 0&&(t=this._getEmptyHandlersStore(),this._map.set(e,t)),t}_getEmptyHandlersStore(){return{onActivations:new bt,onDeactivations:new bt}}}class vs{constructor(e){_(this,"id"),_(this,"parent"),_(this,"options"),_(this,"_middleware"),_(this,"_bindingDictionary"),_(this,"_activations"),_(this,"_deactivations"),_(this,"_snapshots"),_(this,"_metadataReader"),_(this,"_moduleActivationStore");const t=e||{};if(typeof t!="object")throw new Error("Invalid Container constructor argument. Container options must be an object.");if(t.defaultScope===void 0)t.defaultScope=fe.Transient;else if(t.defaultScope!==fe.Singleton&&t.defaultScope!==fe.Transient&&t.defaultScope!==fe.Request)throw new Error('Invalid Container option. Default scope must be a string ("singleton" or "transient").');if(t.autoBindInjectable===void 0)t.autoBindInjectable=!1;else if(typeof t.autoBindInjectable!="boolean")throw new Error("Invalid Container option. Auto bind injectable must be a boolean");if(t.skipBaseClassChecks===void 0)t.skipBaseClassChecks=!1;else if(typeof t.skipBaseClassChecks!="boolean")throw new Error("Invalid Container option. Skip base check must be a boolean");this.options={autoBindInjectable:t.autoBindInjectable,defaultScope:t.defaultScope,skipBaseClassChecks:t.skipBaseClassChecks},this.id=js(),this._bindingDictionary=new bt,this._snapshots=[],this._middleware=null,this._activations=new bt,this._deactivations=new bt,this.parent=null,this._metadataReader=new Zl,this._moduleActivationStore=new zr}static merge(e,t,...s){const r=new vs,i=[e,t,...s].map((l=>ms(l))),a=ms(r);return i.forEach((l=>{var c;c=a,l.traverse(((h,u)=>{u.forEach((g=>{c.add(g.serviceIdentifier,g.clone())}))}))})),r}load(...e){const t=this._getContainerModuleHelpersFactory();for(const s of e){const r=t(s.id);s.registry(r.bindFunction,r.unbindFunction,r.isboundFunction,r.rebindFunction,r.unbindAsyncFunction,r.onActivationFunction,r.onDeactivationFunction)}}async loadAsync(...e){const t=this._getContainerModuleHelpersFactory();for(const s of e){const r=t(s.id);await s.registry(r.bindFunction,r.unbindFunction,r.isboundFunction,r.rebindFunction,r.unbindAsyncFunction,r.onActivationFunction,r.onDeactivationFunction)}}unload(...e){e.forEach((t=>{const s=this._removeModuleBindings(t.id);this._deactivateSingletons(s),this._removeModuleHandlers(t.id)}))}async unloadAsync(...e){for(const t of e){const s=this._removeModuleBindings(t.id);await this._deactivateSingletonsAsync(s),this._removeModuleHandlers(t.id)}}bind(e){return this._bind(this._buildBinding(e))}rebind(e){return this.unbind(e),this.bind(e)}async rebindAsync(e){return await this.unbindAsync(e),this.bind(e)}unbind(e){if(this._bindingDictionary.hasKey(e)){const t=this._bindingDictionary.get(e);this._deactivateSingletons(t)}this._removeServiceFromDictionary(e)}async unbindAsync(e){if(this._bindingDictionary.hasKey(e)){const t=this._bindingDictionary.get(e);await this._deactivateSingletonsAsync(t)}this._removeServiceFromDictionary(e)}unbindAll(){this._bindingDictionary.traverse(((e,t)=>{this._deactivateSingletons(t)})),this._bindingDictionary=new bt}async unbindAllAsync(){const e=[];this._bindingDictionary.traverse(((t,s)=>{e.push(this._deactivateSingletonsAsync(s))})),await Promise.all(e),this._bindingDictionary=new bt}onActivation(e,t){this._activations.add(e,t)}onDeactivation(e,t){this._deactivations.add(e,t)}isBound(e){let t=this._bindingDictionary.hasKey(e);return!t&&this.parent&&(t=this.parent.isBound(e)),t}isCurrentBound(e){return this._bindingDictionary.hasKey(e)}isBoundNamed(e,t){return this.isBoundTagged(e,Xe,t)}isBoundTagged(e,t,s){let r=!1;if(this._bindingDictionary.hasKey(e)){const i=this._bindingDictionary.get(e),a=(function(l,c,h){const u=Ba(c,h),g=Ns(u);if(g.kind===Re.unmanaged)throw new Error("Unexpected metadata when creating target");const p=new fs("",g,"Variable"),v=new Da(l);return new Hn(c,v,null,[],p)})(this,e,{customTag:{key:t,value:s},isMultiInject:!1});r=i.some((l=>l.constraint(a)))}return!r&&this.parent&&(r=this.parent.isBoundTagged(e,t,s)),r}snapshot(){this._snapshots.push(Ur.of(this._bindingDictionary.clone(),this._middleware,this._activations.clone(),this._deactivations.clone(),this._moduleActivationStore.clone()))}restore(){const e=this._snapshots.pop();if(e===void 0)throw new Error("No snapshot available to restore.");this._bindingDictionary=e.bindings,this._activations=e.activations,this._deactivations=e.deactivations,this._middleware=e.middleware,this._moduleActivationStore=e.moduleActivationStore}createChild(e){const t=new vs(e||this.options);return t.parent=this,t}applyMiddleware(...e){const t=this._middleware?this._middleware:this._planAndResolve();this._middleware=e.reduce(((s,r)=>r(s)),t)}applyCustomMetadataReader(e){this._metadataReader=e}get(e){const t=this._getNotAllArgs(e,!1,!1);return this._getButThrowIfAsync(t)}async getAsync(e){const t=this._getNotAllArgs(e,!1,!1);return this._get(t)}getTagged(e,t,s){const r=this._getNotAllArgs(e,!1,!1,t,s);return this._getButThrowIfAsync(r)}async getTaggedAsync(e,t,s){const r=this._getNotAllArgs(e,!1,!1,t,s);return this._get(r)}getNamed(e,t){return this.getTagged(e,Xe,t)}async getNamedAsync(e,t){return this.getTaggedAsync(e,Xe,t)}getAll(e,t){const s=this._getAllArgs(e,t,!1);return this._getButThrowIfAsync(s)}async getAllAsync(e,t){const s=this._getAllArgs(e,t,!1);return this._getAll(s)}getAllTagged(e,t,s){const r=this._getNotAllArgs(e,!0,!1,t,s);return this._getButThrowIfAsync(r)}async getAllTaggedAsync(e,t,s){const r=this._getNotAllArgs(e,!0,!1,t,s);return this._getAll(r)}getAllNamed(e,t){return this.getAllTagged(e,Xe,t)}async getAllNamedAsync(e,t){return this.getAllTaggedAsync(e,Xe,t)}resolve(e){const t=this.isBound(e);t||this.bind(e).toSelf();const s=this.get(e);return t||this.unbind(e),s}tryGet(e){const t=this._getNotAllArgs(e,!1,!0);return this._getButThrowIfAsync(t)}async tryGetAsync(e){const t=this._getNotAllArgs(e,!1,!0);return this._get(t)}tryGetTagged(e,t,s){const r=this._getNotAllArgs(e,!1,!0,t,s);return this._getButThrowIfAsync(r)}async tryGetTaggedAsync(e,t,s){const r=this._getNotAllArgs(e,!1,!0,t,s);return this._get(r)}tryGetNamed(e,t){return this.tryGetTagged(e,Xe,t)}async tryGetNamedAsync(e,t){return this.tryGetTaggedAsync(e,Xe,t)}tryGetAll(e,t){const s=this._getAllArgs(e,t,!0);return this._getButThrowIfAsync(s)}async tryGetAllAsync(e,t){const s=this._getAllArgs(e,t,!0);return this._getAll(s)}tryGetAllTagged(e,t,s){const r=this._getNotAllArgs(e,!0,!0,t,s);return this._getButThrowIfAsync(r)}async tryGetAllTaggedAsync(e,t,s){const r=this._getNotAllArgs(e,!0,!0,t,s);return this._getAll(r)}tryGetAllNamed(e,t){return this.tryGetAllTagged(e,Xe,t)}async tryGetAllNamedAsync(e,t){return this.tryGetAllTaggedAsync(e,Xe,t)}_preDestroy(e,t){var s;if(e!==void 0&&Reflect.hasMetadata(lr,e)){const r=Reflect.getMetadata(lr,e);return(s=t[r.value])==null?void 0:s.call(t)}}_removeModuleHandlers(e){const t=this._moduleActivationStore.remove(e);this._activations.removeIntersection(t.onActivations),this._deactivations.removeIntersection(t.onDeactivations)}_removeModuleBindings(e){return this._bindingDictionary.removeByCondition((t=>t.moduleId===e))}_deactivate(e,t){const s=t==null?void 0:Object.getPrototypeOf(t).constructor;try{if(this._deactivations.hasKey(e.serviceIdentifier)){const i=this._deactivateContainer(t,this._deactivations.get(e.serviceIdentifier).values());if($e(i))return this._handleDeactivationError(i.then((async()=>this._propagateContainerDeactivationThenBindingAndPreDestroyAsync(e,t,s))),e.serviceIdentifier)}const r=this._propagateContainerDeactivationThenBindingAndPreDestroy(e,t,s);if($e(r))return this._handleDeactivationError(r,e.serviceIdentifier)}catch(r){if(r instanceof Error)throw new Error(cr(Et(e.serviceIdentifier),r.message))}}async _handleDeactivationError(e,t){try{await e}catch(s){if(s instanceof Error)throw new Error(cr(Et(t),s.message))}}_deactivateContainer(e,t){let s=t.next();for(;typeof s.value=="function";){const r=s.value(e);if($e(r))return r.then((async()=>this._deactivateContainerAsync(e,t)));s=t.next()}}async _deactivateContainerAsync(e,t){let s=t.next();for(;typeof s.value=="function";)await s.value(e),s=t.next()}_getContainerModuleHelpersFactory(){const e=c=>h=>{const u=this._buildBinding(h);return u.moduleId=c,this._bind(u)},t=()=>c=>{this.unbind(c)},s=()=>async c=>this.unbindAsync(c),r=()=>c=>this.isBound(c),i=c=>{const h=e(c);return u=>(this.unbind(u),h(u))},a=c=>(h,u)=>{this._moduleActivationStore.addActivation(c,h,u),this.onActivation(h,u)},l=c=>(h,u)=>{this._moduleActivationStore.addDeactivation(c,h,u),this.onDeactivation(h,u)};return c=>({bindFunction:e(c),isboundFunction:r(),onActivationFunction:a(c),onDeactivationFunction:l(c),rebindFunction:i(c),unbindAsyncFunction:s(),unbindFunction:t()})}_bind(e){return this._bindingDictionary.add(e.serviceIdentifier,e),new uc(e)}_buildBinding(e){const t=this.options.defaultScope||fe.Transient;return new Br(e,t)}async _getAll(e){return Promise.all(this._get(e))}_get(e){const t={...e,contextInterceptor:s=>s,targetType:$a.Variable};if(this._middleware){const s=this._middleware(t);if(s==null)throw new Error("Invalid return type in middleware. Middleware must return!");return s}return this._planAndResolve()(t)}_getButThrowIfAsync(e){const t=this._get(e);if(Ua(t))throw new Error(`You are attempting to construct ${(function(s){return typeof s=="function"?`[function/class ${s.name||"<anonymous>"}]`:typeof s=="symbol"?s.toString():`'${s}'`})(e.serviceIdentifier)} in a synchronous way but it has asynchronous dependencies.`);return t}_getAllArgs(e,t,s){return{avoidConstraints:!(t!=null&&t.enforceBindingConstraints),isMultiInject:!0,isOptional:s,serviceIdentifier:e}}_getNotAllArgs(e,t,s,r,i){return{avoidConstraints:!1,isMultiInject:t,isOptional:s,key:r,serviceIdentifier:e,value:i}}_getPlanMetadataFromNextArgs(e){const t={isMultiInject:e.isMultiInject};return e.key!==void 0&&(t.customTag={key:e.key,value:e.value}),e.isOptional===!0&&(t.isOptional=!0),t}_planAndResolve(){return e=>{let t=Ql(this._metadataReader,this,e.targetType,e.serviceIdentifier,this._getPlanMetadataFromNextArgs(e),e.avoidConstraints);return t=e.contextInterceptor(t),(function(s){return Hr(s.plan.rootRequest.requestScope)(s.plan.rootRequest)})(t)}}_deactivateIfSingleton(e){if(e.activated)return $e(e.cache)?e.cache.then((t=>this._deactivate(e,t))):this._deactivate(e,e.cache)}_deactivateSingletons(e){for(const t of e)if($e(this._deactivateIfSingleton(t)))throw new Error("Attempting to unbind dependency with asynchronous destruction (@preDestroy or onDeactivation)")}async _deactivateSingletonsAsync(e){await Promise.all(e.map((async t=>this._deactivateIfSingleton(t))))}_propagateContainerDeactivationThenBindingAndPreDestroy(e,t,s){return this.parent?this._deactivate.bind(this.parent)(e,t):this._bindingDeactivationAndPreDestroy(e,t,s)}async _propagateContainerDeactivationThenBindingAndPreDestroyAsync(e,t,s){this.parent?await this._deactivate.bind(this.parent)(e,t):await this._bindingDeactivationAndPreDestroyAsync(e,t,s)}_removeServiceFromDictionary(e){try{this._bindingDictionary.remove(e)}catch{throw new Error(`Could not unbind serviceIdentifier: ${Et(e)}`)}}_bindingDeactivationAndPreDestroy(e,t,s){if(typeof e.onDeactivation=="function"){const r=e.onDeactivation(t);if($e(r))return r.then((()=>this._preDestroy(s,t)))}return this._preDestroy(s,t)}async _bindingDeactivationAndPreDestroyAsync(e,t,s){typeof e.onDeactivation=="function"&&await e.onDeactivation(t),await this._preDestroy(s,t)}}function Ie(){return function(n){if(Reflect.hasOwnMetadata(ji,n))throw new Error("Cannot apply @injectable decorator multiple times.");const e=Reflect.getMetadata(Ia,n)||[];return Reflect.defineMetadata(ji,e,n),n}}var wn=Symbol.for("INJECTION");function Es(n,e,t,s){function r(){return s&&!Reflect.hasMetadata(wn,this,e)&&Reflect.defineMetadata(wn,t(),this,e),Reflect.hasMetadata(wn,this,e)?Reflect.getMetadata(wn,this,e):t()}function i(a){Reflect.defineMetadata(wn,a,this,e)}Object.defineProperty(n,e,{configurable:!0,enumerable:!0,get:r,set:i})}function pc(n,e){return function(t){return function(s,r){var i=function(){return n.get(t)};Es(s,r,i,e)}}}function gc(n,e){return function(t,s){return function(r,i){var a=function(){return n.getNamed(t,s)};Es(r,i,a,e)}}}function fc(n,e){return function(t,s,r){return function(i,a){var l=function(){return n.getTagged(t,s,r)};Es(i,a,l,e)}}}function mc(n,e){return function(t){return function(s,r){var i=function(){return n.getAll(t)};Es(s,r,i,e)}}}function yc(n,e){e===void 0&&(e=!0);var t=pc(n,e),s=gc(n,e),r=fc(n,e),i=mc(n,e);return{lazyInject:t,lazyInjectNamed:s,lazyInjectTagged:r,lazyMultiInject:i}}var Un=(n,e,t,s)=>{for(var r=e,i=n.length-1,a;i>=0;i--)(a=n[i])&&(r=a(r)||r);return r};const be=new vs,{lazyMultiInject:Rt}=yc(be),ne={ChatInput:Symbol.for("ChatInputController"),ChatInputFooter:Symbol.for("ChatInputFooterController"),ChatSection:Symbol.for("ChatSectionController"),ChatEntryAction:Symbol.for("ChatEntryActionController"),Citation:Symbol.for("CitationController"),ChatEntryInlineInput:Symbol.for("ChatEntryInlineInputController"),ChatAction:Symbol.for("ChatActionController"),ChatThread:Symbol.for("ChatThreadController")};let Oe=class{attach(n,e){(this.host=n).addController(this),this.context=e}hostConnected(){}hostDisconnected(){}};Oe=Un([Ie()],Oe);let wt=class extends Oe{render(){return $``}};wt=Un([Ie()],wt);let dr=class extends wt{constructor(){super(...arguments),this.position="left"}};dr=Un([Ie()],dr);let hr=class extends wt{constructor(){super(...arguments),this.isEnabled=!1}close(){}};hr=Un([Ie()],hr);let ur=class extends Oe{save(){}reset(){}merge(n){return n}render(){return $``}};ur=Un([Ie()],ur);be.bind(ne.ChatInput).to(dr);be.bind(ne.ChatInputFooter).to(wt);be.bind(ne.ChatSection).to(hr);be.bind(ne.ChatEntryAction).to(wt);be.bind(ne.Citation).to(wt);be.bind(ne.ChatEntryInlineInput).to(wt);be.bind(ne.ChatAction).to(wt);be.bind(ne.ChatThread).to(ur);var vc=Object.defineProperty,bc=Object.getOwnPropertyDescriptor,at=(n,e,t,s)=>{for(var r=s>1?void 0:s?bc(e,t):e,i=n.length-1,a;i>=0;i--)(a=n[i])&&(r=(s?a(e,t,r):a(r))||r);return s&&r&&vc(e,t,r),r};let ze=class extends Ne{constructor(){super(),this.chatThread=[],this.isDisabled=!1,this.isProcessingResponse=!1,this.isResponseCopied=!1,this.selectedCitation=void 0,this.context=void 0,this.handleInput=this.handleInput.bind(this)}connectedCallback(){if(super.connectedCallback(),this.actionCompontents)for(const n of this.actionCompontents)n.attach(this,this.context);if(this.inlineInputComponents)for(const n of this.inlineInputComponents)n.attach(this,this.context)}actionButtonClicked(n,e,t){t.preventDefault();const s=new CustomEvent("on-action-button-click",{detail:{id:n.id,chatThreadEntry:e},bubbles:!0,composed:!0});this.dispatchEvent(s)}debounceScrollIntoView(){let n=0;clearTimeout(n),n=setTimeout(()=>{this.chatFooter&&this.chatFooter.scrollIntoView({behavior:"smooth",block:"center"})},500)}handleInput(n){const e=new CustomEvent("on-input",{detail:{value:n},bubbles:!0,composed:!0});this.dispatchEvent(e)}handleCitationClick(n,e,t){t.preventDefault(),this.selectedCitation=n;const s=new CustomEvent("on-citation-click",{detail:{citation:n,chatThreadEntry:e},bubbles:!0,composed:!0});this.dispatchEvent(s)}renderResponseActions(n){var e;return $`
      <header class="chat__header">
        <div class="chat__header--button">
          ${(e=this.actionCompontents)==null?void 0:e.map(t=>t.render(n,this.isDisabled))}
        </div>
      </header>
    `}renderTextEntry(n){const e=[$`<p class="chat__txt--entry">${ps(n.value)}</p>`];return n.followingSteps&&n.followingSteps.length>0&&e.push($`
        <ol class="items__list steps">
          ${n.followingSteps.map(t=>$` <li class="items__listItem--step">${ps(t)}</li> `)}
        </ol>
      `),this.isProcessingResponse&&this.debounceScrollIntoView(),$`<div class="chat_txt--entry-container">${e}</div>`}renderCitation(n){const e=n.citations;return e&&e.length>0?$`
        <div class="chat__citations">
          <citation-list
            .citations="${e}"
            .label="${W.CITATIONS_LABEL}"
            .selectedCitation=${this.selectedCitation}
            @on-citation-click="${t=>this.handleCitationClick(t.detail.citation,n,t)}"
          ></citation-list>
        </div>
      `:""}renderError(n){return $`<p class="chat__txt error">${n.message}</p>`}render(){return $`
      <ul class="chat__list" aria-live="assertive">
        ${this.chatThread.map(n=>{var e;return $`
            <li class="chat__listItem ${n.isUserMessage?"user-message":""}">
              <div class="chat__txt ${n.isUserMessage?"user-message":""}">
                ${n.isUserMessage?"":this.renderResponseActions(n)}
                ${n.text.map(t=>this.renderTextEntry(t))} ${this.renderCitation(n)}
                ${(e=this.inlineInputComponents)==null?void 0:e.map(t=>t.render(n,this.handleInput))}
                ${n.error?this.renderError(n.error):""}
              </div>
              <p class="chat__txt--info">
                <span class="timestamp">${n.timestamp}</span>,
                <span class="user">${n.isUserMessage?"You":W.USER_IS_BOT}</span>
              </p>
            </li>
          `})}
      </ul>
      <div class="chat__footer" id="chat-list-footer">
        <!-- Do not delete this element. It is used for auto-scrolling -->
      </div>
    `}};ze.styles=[El];at([H({type:Array})],ze.prototype,"chatThread",2);at([H({type:Boolean})],ze.prototype,"isDisabled",2);at([H({type:Boolean})],ze.prototype,"isProcessingResponse",2);at([tn()],ze.prototype,"isResponseCopied",2);at([va("#chat-list-footer")],ze.prototype,"chatFooter",2);at([H({type:Object})],ze.prototype,"selectedCitation",2);at([H({type:Object})],ze.prototype,"context",2);at([Rt(ne.ChatEntryAction)],ze.prototype,"actionCompontents",2);at([Rt(ne.ChatEntryInlineInput)],ze.prototype,"inlineInputComponents",2);ze=at([Ke("chat-thread-component")],ze);const xc=it`
  button {
    color: var(--text-color);
    text-decoration: underline;
    border: var(--border-thin) solid var(--c-accent-dark);
    text-decoration: none;
    border-radius: var(--radius-small);
    background: var(--c-white);
    display: flex;
    align-items: center;
    margin-left: 5px;
    opacity: 1;
    padding: var(--d-xsmall);
    transition: all 0.3s ease-in-out;
    position: relative;
    cursor: pointer;
  }
  button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
  span {
    font-size: smaller;
    transition: all 0.3s ease-out 0s;
    position: absolute;
    text-align: right;
    top: -80%;
    background: var(--c-accent-dark);
    color: var(--c-white);
    opacity: 0;
    right: 0;
    padding: var(--d-xsmall) var(--d-small);
    border-radius: var(--radius-small);
    font-weight: bold;
    word-wrap: nowrap;
  }
  span::after {
    content: '';
    position: absolute;
    width: 0;
    height: 0;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-top: var(--border-thick) solid var(--c-accent-dark);
    bottom: -8px;
    right: 5px;
  }
  svg {
    fill: currentColor;
    padding: var(--d-xsmall);
    width: var(--d-base);
    height: var(--d-base);
  }
  button:hover > span,
  button:focus > span {
    display: inline-block;
    opacity: 1;
  }
  button:hover,
  button:focus,
  button:hover > svg,
  button:focus > svg {
    background-color: var(--c-light-gray);
    border-radius: var(--radius-small);
    transition: background 0.3s ease-in-out;
  }
`;var _c=Object.defineProperty,wc=Object.getOwnPropertyDescriptor,mn=(n,e,t,s)=>{for(var r=s>1?void 0:s?wc(e,t):e,i=n.length-1,a;i>=0;i--)(a=n[i])&&(r=(s?a(e,t,r):a(r))||r);return s&&r&&_c(e,t,r),r};let It=class extends Ne{constructor(){super(...arguments),this.label="",this.svgIcon="",this.isDisabled=!1,this.actionId="",this.tooltip=void 0}render(){return $`
      <button title="${this.label}" data-testid="${this.actionId}" ?disabled="${this.isDisabled}">
        <span>${this.tooltip??this.label}</span>
        ${rt(this.svgIcon)}
      </button>
    `}};It.styles=[xc];mn([H({type:String})],It.prototype,"label",2);mn([H({type:String})],It.prototype,"svgIcon",2);mn([H({type:Boolean})],It.prototype,"isDisabled",2);mn([H({type:String})],It.prototype,"actionId",2);mn([H({type:String})],It.prototype,"tooltip",2);It=mn([Ke("chat-action-button")],It);class Cc{constructor(e){this._state={},this._selectedChatEntry=void 0,this._apiUrl=or.url,this._interactionModel="chat",this._isChatStarted=!1,this._selectedCitation=void 0,(this.host=e).addController(this)}hostConnected(){}hostDisconnected(){}set selectedCitation(e){this._selectedCitation=e,this.host.requestUpdate()}get selectedCitation(){return this._selectedCitation}set isChatStarted(e){this._isChatStarted=e,this.host.requestUpdate()}get isChatStarted(){return this._isChatStarted}setState(e,t){this._state[e]=t,this.host.requestUpdate()}getState(e){return this._state[e]}set selectedChatEntry(e){this._selectedChatEntry=e,this.host.requestUpdate()}get selectedChatEntry(){return this._selectedChatEntry}set apiUrl(e){this._apiUrl=e,this.host.requestUpdate()}get apiUrl(){return this._apiUrl}set interactionModel(e){this._interactionModel=e,this.host.requestUpdate()}get interactionModel(){return this._interactionModel}}const kc=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2048 2048">\r
  <path d="M2048 290l-734 734 734 734-290 290-734-734-734 734L0 1758l734-734L0 290 290 0l734 734L1758 0l290 290z" />\r
</svg>`;var Sc=Object.defineProperty,Ac=Object.getOwnPropertyDescriptor,Fa=(n,e,t,s)=>{for(var r=s>1?void 0:s?Ac(e,t):e,i=n.length-1,a;i>=0;i--)(a=n[i])&&(r=(s?a(e,t,r):a(r))||r);return s&&r&&Sc(e,t,r),r};let bs=class extends Oe{constructor(){super(),this.close=this.close.bind(this)}hostConnected(){if(this.citationControllers)for(const n of this.citationControllers)n.attach(this.host,this.context)}handleCitationClick(n){var e;n==null||n.preventDefault(),this.context.selectedCitation=(e=n==null?void 0:n.detail)==null?void 0:e.citation,this.context.setState("showCitations",!0)}renderChatEntryTabContent(n){var e;return $`
      <tab-component
        .tabs="${[{id:"tab-thought-process",label:W.THOUGHT_PROCESS_LABEL},{id:"tab-support-context",label:W.SUPPORT_CONTEXT_LABEL},{id:"tab-citations",label:W.CITATIONS_TAB_LABEL}]}"
        .selectedTabId="${this.selectedAsideTab}"
      >
        <div slot="tab-thought-process" class="tab-component__content">
          ${n&&n.thoughts?$` <p class="tab-component__paragraph">${ps(n.thoughts)}</p> `:""}
        </div>
        <div slot="tab-support-context" class="tab-component__content">
          ${n&&n.dataPoints?$`
                <teaser-list-component
                  .alwaysRow="${!0}"
                  .teasers="${n.dataPoints.map(t=>({description:t}))}"
                ></teaser-list-component>
              `:""}
        </div>
        ${n&&n.citations?$`
              <div slot="tab-citations" class="tab-component__content">
                <citation-list
                  .citations="${n.citations}"
                  .label="${W.CITATIONS_LABEL}"
                  .selectedCitation="${this.context.selectedCitation}"
                  @on-citation-click="${this.handleCitationClick}"
                ></citation-list>
                ${this.context.selectedCitation?(e=this.citationControllers)==null?void 0:e.map(t=>t.render(this.context.selectedCitation,`${this.context.apiUrl}/content/${this.context.selectedCitation.text}`)):""}
              </div>
            `:""}
      </tab-component>
    `}get isEnabled(){return this.isShowingThoughtProcess}close(){this.isShowingThoughtProcess=!1,this.context.setState("showCitations",!1),this.context.selectedChatEntry=void 0}get isShowingThoughtProcess(){return this.context.getState("showThoughtProcess")||this.context.getState("showCitations")}set isShowingThoughtProcess(n){this.context.setState("showThoughtProcess",n)}get selectedAsideTab(){return this.context.getState("showCitations")?"tab-citations":"tab-thought-process"}render(){return $`
      <aside class="aside" data-testid="aside-thought-process">
        <div class="aside__header">
          <chat-action-button
            .label="${W.HIDE_THOUGH_PROCESS_BUTTON_LABEL_TEXT}"
            actionId="chat-hide-thought-process"
            @click="${this.close}"
            .svgIcon="${kc}"
          >
          </chat-action-button>
        </div>
        ${this.renderChatEntryTabContent(this.context.selectedChatEntry)}
      </aside>
    `}};Fa([Rt(ne.Citation)],bs.prototype,"citationControllers",2);bs=Fa([Ie()],bs);be.bind(ne.ChatSection).to(bs);const Tc=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2048 2048">\r
  <path d="M960 0q97 0 187 25t168 71 143 110 110 142 71 169 25 187q0 145-55 269t-157 225q-83 82-127 183t-45 219v256q0 40-15 75t-41 61-61 41-75 15H832q-40 0-75-15t-61-41-41-61-15-75v-256q0-118-44-219t-128-183q-102-101-157-225t-55-269q0-97 25-187t71-168 110-143T604 96t169-71T960 0zm128 1920q26 0 45-19t19-45v-192H768v192q0 26 19 45t45 19h256zm67-384q12-128 65-233t144-197q83-83 127-183t45-219q0-119-45-224t-124-183-183-123-224-46q-119 0-224 45T553 297 430 480t-46 224q0 118 44 218t128 184q90 91 143 196t66 234h131v-512q0-26 19-45t45-19q26 0 45 19t19 45v512h131zM640 576q26 0 45 19l128 128q19 19 19 45t-19 45-45 19q-26 0-45-19L595 685q-19-19-19-45t19-45 45-19zm448 192q0-26 19-45l128-128q19-19 45-19t45 19 19 45q0 26-19 45l-128 128q-19 19-45 19t-45-19-19-45zM960 384q26 0 45 19t19 45v192q0 26-19 45t-45 19q-26 0-45-19t-19-45V448q0-26 19-45t45-19z" />\r
</svg>`;var Nc=(n,e,t,s)=>{for(var r=e,i=n.length-1,a;i>=0;i--)(a=n[i])&&(r=a(r)||r);return r};let pr=class extends Oe{handleClick(n,e){n.preventDefault(),this.context.setState("showThoughtProcess",!0),this.context.selectedChatEntry=e}render(n,e){const t=this.context.getState("showThoughtProcess");return $`
      <chat-action-button
        .label="${W.SHOW_THOUGH_PROCESS_BUTTON_LABEL_TEXT}"
        .svgIcon="${Tc}"
        actionId="chat-show-thought-process"
        .isDisabled="${e||t}"
        @click="${s=>this.handleClick(s,n)}"
      ></chat-action-button>
    `}};pr=Nc([Ie()],pr);be.bind(ne.ChatEntryAction).to(pr);const jc=it`
  .tab-component__list {
    list-style-type: none;
    display: flex;
    box-shadow: var(--shadow);
    border-radius: var(--radius-base);
    padding: var(--d-xsmall);
    width: 450px;
    margin: 0 auto;
    justify-content: space-evenly;
  }
  .tab-component__listItem {
    width: 33%;
    text-align: center;
  }
  .tab-component__link.active {
    background: linear-gradient(to left, var(--c-accent-light), var(--c-accent-high));
    color: var(--c-white);
  }
  .tab-component__link:not(.active):hover {
    background: var(--c-light-gray);
    cursor: pointer;
  }
  .tab-component__link {
    border-bottom: 4px solid transparent;
    border-radius: var(--radius-small);
    text-decoration: none;
    color: var(--text-color);
    font-weight: bold;
    font-size: var(--font-small);
    cursor: pointer;
    display: block;
    padding: var(--d-small);
  }
  .tab-component__content {
    position: relative;
  }
  .tab-component__tab {
    position: absolute;
    top: 0;
    left: 30px;
    display: none;
    width: 100%;
    @media (max-width: 1024px) {
      position: relative;
      left: 0;
    }
  }
  .tab-component__tab.active {
    display: block;
  }
`;var Ec=Object.defineProperty,Ic=Object.getOwnPropertyDescriptor,Fr=(n,e,t,s)=>{for(var r=s>1?void 0:s?Ic(e,t):e,i=n.length-1,a;i>=0;i--)(a=n[i])&&(r=(s?a(e,t,r):a(r))||r);return s&&r&&Ec(e,t,r),r};let Ln=class extends Ne{constructor(){super(...arguments),this.tabs=[],this.selectedTabId=void 0}activateTab(n){n.preventDefault();const e=n.target.id;this.selectedTabId=e}renderTabListItem(n,e){return $`
      <li class="tab-component__listItem">
        <a
          id="${n.id}"
          class="tab-component__link ${e?"active":""}"
          role="tab"
          href="#"
          aria-selected="${e}"
          aria-hidden="${!e}"
          aria-controls="tabpanel-${n.id}"
          @click="${t=>this.activateTab(t)}"
          title="${n.label}"
        >
          ${n.label}
        </a>
      </li>
    `}renderTabContent(n,e){return $`
      <div
        id="tabpanel-${n.id}"
        class="tab-component__tab ${e?"active":""}"
        role="tabpanel"
        tabindex="${e?"0":"-1"}"
        aria-labelledby="${n.id}"
      >
        <slot name="${n.id}"></slot>
      </div>
    `}render(){return $`
      <div class="tab-component">
        <nav>
          <ul class="tab-component__list" role="tablist">
            ${this.tabs.map(n=>this.renderTabListItem(n,n.id===this.selectedTabId))}
          </ul>
        </nav>
        <div class="tab-component__content">
          ${this.tabs.map(n=>this.renderTabContent(n,n.id===this.selectedTabId))}
        </div>
      </div>
    `}};Ln.styles=[jc];Fr([H({type:Array})],Ln.prototype,"tabs",2);Fr([H({type:String})],Ln.prototype,"selectedTabId",2);Ln=Fr([Ke("tab-component")],Ln);var $c=(n,e,t,s)=>{for(var r=e,i=n.length-1,a;i>=0;i--)(a=n[i])&&(r=a(r)||r);return r};let gr=class extends Oe{constructor(){super(...arguments),this.position="right"}render(n){return $`<voice-input-button @on-voice-input="${e=>{var t;return n((t=e==null?void 0:e.detail)==null?void 0:t.value)}}" />`}};gr=$c([Ie()],gr);be.bind(ne.ChatInput).to(gr);const Rc=it`
  button {
    color: var(--text-color);
    font-weight: bold;
    margin-left: 8px;
    background: transparent;
    transition: background 0.3s ease-in-out;
    box-shadow: none;
    border: none;
    cursor: pointer;
    width: var(--d-xlarge);
    height: 100%;
  }
  button:hover,
  button:focus {
    background: var(--c-secondary);
  }
  button:hover svg,
  button:focus svg {
    opacity: 0.8;
  }
  .not-recording svg {
    fill: var(--c-black);
  }
  .recording svg {
    fill: var(--red);
  }
`,Oc=`<svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">\r
  <path d="M18.25 11C18.6297 11 18.9435 11.2822 18.9932 11.6482L19 11.75V12.25C19 15.8094 16.245 18.7254 12.751 18.9817L12.75 21.25C12.75 21.6642 12.4142 22 12 22C11.6203 22 11.3065 21.7178 11.2568 21.3518L11.25 21.25L11.25 18.9818C7.83323 18.7316 5.12283 15.938 5.00406 12.4863L5 12.25V11.75C5 11.3358 5.33579 11 5.75 11C6.1297 11 6.44349 11.2822 6.49315 11.6482L6.5 11.75V12.25C6.5 15.077 8.73445 17.3821 11.5336 17.4956L11.75 17.5H12.25C15.077 17.5 17.3821 15.2656 17.4956 12.4664L17.5 12.25V11.75C17.5 11.3358 17.8358 11 18.25 11ZM12 2C14.2091 2 16 3.79086 16 6V12C16 14.2091 14.2091 16 12 16C9.79086 16 8 14.2091 8 12V6C8 3.79086 9.79086 2 12 2Z"  />\r
</svg>`,Pc=`<svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">\r
  <path d="M11 17.5C11 18.596 11.2713 19.6287 11.7503 20.5345L11.75 21.25C11.75 21.6642 11.4142 22 11 22C10.6203 22 10.3065 21.7178 10.2568 21.3518L10.25 21.25L10.25 18.9818C6.83323 18.7316 4.12283 15.938 4.00406 12.4863L4 12.25V11.75C4 11.3358 4.33579 11 4.75 11C5.1297 11 5.44349 11.2822 5.49315 11.6482L5.5 11.75V12.25C5.5 15.077 7.73445 17.3821 10.5336 17.4956L10.75 17.5H11ZM11.1748 15.9962C11.6577 13.9575 13.1007 12.2902 15 11.4982V6C15 3.79086 13.2091 2 11 2C8.79086 2 7 3.79086 7 6V12C7 14.2091 8.79086 16 11 16C11.0586 16 11.1169 15.9987 11.1748 15.9962ZM20 17.5C20 18.8807 18.8807 20 17.5 20C16.1193 20 15 18.8807 15 17.5C15 16.1193 16.1193 15 17.5 15C18.8807 15 20 16.1193 20 17.5ZM23 17.5C23 20.5376 20.5376 23 17.5 23C14.4624 23 12 20.5376 12 17.5C12 14.4624 14.4624 12 17.5 12C20.5376 12 23 14.4624 23 17.5ZM13.5 17.5C13.5 19.7091 15.2909 21.5 17.5 21.5C19.7091 21.5 21.5 19.7091 21.5 17.5C21.5 15.2909 19.7091 13.5 17.5 13.5C15.2909 13.5 13.5 15.2909 13.5 17.5Z" />\r
</svg>`;var Lc=Object.defineProperty,Dc=Object.getOwnPropertyDescriptor,qr=(n,e,t,s)=>{for(var r=s>1?void 0:s?Dc(e,t):e,i=n.length-1,a;i>=0;i--)(a=n[i])&&(r=(s?a(e,t,r):a(r))||r);return s&&r&&Lc(e,t,r),r};let Dn=class extends Ne{constructor(){super(...arguments),this.recognitionSvc=window.SpeechRecognition||window.webkitSpeechRecognition,this.showVoiceInput=this.recognitionSvc!==void 0,this.enableVoiceListening=!1,this.speechRecognition=void 0}initializeSpeechRecognition(){if(this.showVoiceInput&&this.recognitionSvc){if(this.speechRecognition=new this.recognitionSvc,!this.speechRecognition)return;this.speechRecognition.continuous=!0,this.speechRecognition.lang="en-US",this.speechRecognition.onresult=n=>{let e="";for(const s of n.results)e+=`${s[0].transcript}`;const t=new CustomEvent("on-voice-input",{detail:{value:e},bubbles:!0,composed:!0});this.dispatchEvent(t)},this.speechRecognition.addEventListener("error",n=>{this.speechRecognition&&(this.speechRecognition.stop(),console.log(`Speech recognition error detected: ${n.error} - ${n.message}`))})}}handleVoiceInput(n){n.preventDefault(),this.speechRecognition||this.initializeSpeechRecognition(),this.speechRecognition&&(this.enableVoiceListening=!this.enableVoiceListening,this.enableVoiceListening?this.speechRecognition.start():this.speechRecognition.stop())}renderVoiceButton(){return $`
      <button
        title="${this.enableVoiceListening?W.CHAT_VOICE_REC_BUTTON_LABEL_TEXT:W.CHAT_VOICE_BUTTON_LABEL_TEXT}"
        class="${this.enableVoiceListening?"recording":"not-recording"}"
        @click="${this.handleVoiceInput}"
      >
        ${this.enableVoiceListening?rt(Pc):rt(Oc)}
      </button>
    `}render(){return this.showVoiceInput?this.renderVoiceButton():$``}};Dn.styles=[Rc];qr([tn()],Dn.prototype,"showVoiceInput",2);qr([tn()],Dn.prototype,"enableVoiceListening",2);Dn=qr([Ke("voice-input-button")],Dn);var qa=(n,e,t,s)=>{for(var r=e,i=n.length-1,a;i>=0;i--)(a=n[i])&&(r=a(r)||r);return r};let fr=class extends Oe{constructor(){super(...arguments),this.position="top"}render(n){return $`
      <teaser-list-component
        .heading="${this.context.interactionModel==="chat"?Zn.HEADING_CHAT:Zn.HEADING_ASK}"
        .clickable="${!0}"
        .actionLabel="${Zn.TEASER_CTA_LABEL}"
        @teaser-click="${e=>{var t;return n((t=e==null?void 0:e.detail)==null?void 0:t.value)}}"
        .teasers="${Zn.DEFAULT_PROMPTS}"
      ></teaser-list-component>
    `,""}};fr=qa([Ie()],fr);let mr=class extends Oe{render(n){return $`
      <div class="chat__containerFooter">
        <button
          type="button"
          @click="${n}"
          class="defaults__span button"
        >
          ${W.DISPLAY_DEFAULT_PROMPTS_BUTTON}
        </button>
      </div>
    `,""}};mr=qa([Ie()],mr);be.bind(ne.ChatInput).to(fr);be.bind(ne.ChatInputFooter).to(mr);const Mc=it`
  .headline {
    color: var(--text-color);
    font-size: var(--font-r-large);
    padding: 0;
    margin: var(--d-small) 0 var(--d-large);

    @media (min-width: 1024px) {
      font-size: var(--font-r-base);
      text-align: center;
    }
  }
  [role='button'] {
    text-decoration: none;
    color: var(--text-color);
    display: block;
    font-size: var(--font-rel-base);
  }
  .teaser-list {
    list-style-type: none;
    padding: 0;
    text-align: center;
    display: flex;
    flex-direction: column;
    justify-content: center;
  }
  .teaser-list.always-row {
    text-align: left;
  }
  .teaser-list:not(.always-row) {
    @media (min-width: 1024px) {
      flex-direction: row;
    }
  }
  .teaser-list-item {
    padding: var(--d-small);
    border-radius: var(--radius-base);
    background: var(--c-white);
    margin: var(--d-xsmall);
    color: var(--text-color);
    justify-content: space-evenly;
    box-shadow: var(--shadow);
    border: var(--border-base) solid transparent;

    @media (min-width: 768px) {
      min-height: 100px;
    }
  }
  .teaser-list-item:hover,
  .teaser-list-item:focus {
    color: var(--c-accent-dark);
    background: var(--c-secondary);
    transition: all 0.3s ease-in-out;
    border-color: var(--c-accent-high);
  }
  .teaser-list-item .teaser-click-label {
    color: var(--c-accent-high);
    font-weight: bold;
    display: block;
    margin-top: 20px;
    text-decoration: underline;
  }
`;var Bc=Object.defineProperty,Hc=Object.getOwnPropertyDescriptor,yn=(n,e,t,s)=>{for(var r=s>1?void 0:s?Hc(e,t):e,i=n.length-1,a;i>=0;i--)(a=n[i])&&(r=(s?a(e,t,r):a(r))||r);return s&&r&&Bc(e,t,r),r};let $t=class extends Ne{constructor(){super(...arguments),this.teasers=[],this.heading=void 0,this.actionLabel=void 0,this.alwaysRow=!1,this.clickable=!1}handleTeaserClick(n,e){e==null||e.preventDefault();const t=new CustomEvent("teaser-click",{detail:{value:n.description},bubbles:!0,composed:!0});this.dispatchEvent(t)}renderClickableTeaser(n){return $`
      <a
        role="button"
        href="#"
        data-testid="default-question"
        @click="${e=>this.handleTeaserClick(n,e)}"
      >
        ${n.description}
        <span class="teaser-click-label">${this.actionLabel}</span>
      </a>
    `}render(){return $`
      <div class="teaser-list-container">
        ${this.heading?$`<h1 class="headline">${this.heading}</h1>`:""}
        <ul class="teaser-list ${this.alwaysRow?"always-row":""}">
          ${this.teasers.map(n=>$`
              <li class="teaser-list-item">
                ${this.clickable?this.renderClickableTeaser(n):n.description}
              </li>
            `)}
        </ul>
      </div>
    `}};$t.styles=[Mc];yn([H({type:Array})],$t.prototype,"teasers",2);yn([H({type:String})],$t.prototype,"heading",2);yn([H({type:String})],$t.prototype,"actionLabel",2);yn([H({type:Boolean})],$t.prototype,"alwaysRow",2);yn([H({type:Boolean})],$t.prototype,"clickable",2);$t=yn([Ke("teaser-list-component")],$t);function Vr(){return{async:!1,breaks:!1,extensions:null,gfm:!0,hooks:null,pedantic:!1,renderer:null,silent:!1,tokenizer:null,walkTokens:null}}let nn=Vr();function Va(n){nn=n}const Wa=/[&<>"']/,Uc=new RegExp(Wa.source,"g"),Ga=/[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/,zc=new RegExp(Ga.source,"g"),Fc={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"},Ui=n=>Fc[n];function Me(n,e){if(e){if(Wa.test(n))return n.replace(Uc,Ui)}else if(Ga.test(n))return n.replace(zc,Ui);return n}const qc=/&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;function Vc(n){return n.replace(qc,(e,t)=>(t=t.toLowerCase(),t==="colon"?":":t.charAt(0)==="#"?t.charAt(1)==="x"?String.fromCharCode(parseInt(t.substring(2),16)):String.fromCharCode(+t.substring(1)):""))}const Wc=/(^|[^\[])\^/g;function G(n,e){n=typeof n=="string"?n:n.source,e=e||"";const t={replace:(s,r)=>(r=typeof r=="object"&&"source"in r?r.source:r,r=r.replace(Wc,"$1"),n=n.replace(s,r),t),getRegex:()=>new RegExp(n,e)};return t}function zi(n){try{n=encodeURI(n).replace(/%25/g,"%")}catch{return null}return n}const xs={exec:()=>null};function Fi(n,e){const t=n.replace(/\|/g,(i,a,l)=>{let c=!1,h=a;for(;--h>=0&&l[h]==="\\";)c=!c;return c?"|":" |"}),s=t.split(/ \|/);let r=0;if(s[0].trim()||s.shift(),s.length>0&&!s[s.length-1].trim()&&s.pop(),e)if(s.length>e)s.splice(e);else for(;s.length<e;)s.push("");for(;r<s.length;r++)s[r]=s[r].trim().replace(/\\\|/g,"|");return s}function Kn(n,e,t){const s=n.length;if(s===0)return"";let r=0;for(;r<s&&n.charAt(s-r-1)===e;)r++;return n.slice(0,s-r)}function Gc(n,e){if(n.indexOf(e[1])===-1)return-1;let t=0;for(let s=0;s<n.length;s++)if(n[s]==="\\")s++;else if(n[s]===e[0])t++;else if(n[s]===e[1]&&(t--,t<0))return s;return-1}function qi(n,e,t,s){const r=e.href,i=e.title?Me(e.title):null,a=n[1].replace(/\\([\[\]])/g,"$1");if(n[0].charAt(0)!=="!"){s.state.inLink=!0;const l={type:"link",raw:t,href:r,title:i,text:a,tokens:s.inlineTokens(a)};return s.state.inLink=!1,l}return{type:"image",raw:t,href:r,title:i,text:Me(a)}}function Yc(n,e){const t=n.match(/^(\s+)(?:```)/);if(t===null)return e;const s=t[1];return e.split(`
`).map(r=>{const i=r.match(/^\s+/);if(i===null)return r;const[a]=i;return a.length>=s.length?r.slice(s.length):r}).join(`
`)}class _s{constructor(e){_(this,"options"),_(this,"rules"),_(this,"lexer"),this.options=e||nn}space(e){const t=this.rules.block.newline.exec(e);if(t&&t[0].length>0)return{type:"space",raw:t[0]}}code(e){const t=this.rules.block.code.exec(e);if(t){const s=t[0].replace(/^ {1,4}/gm,"");return{type:"code",raw:t[0],codeBlockStyle:"indented",text:this.options.pedantic?s:Kn(s,`
`)}}}fences(e){const t=this.rules.block.fences.exec(e);if(t){const s=t[0],r=Yc(s,t[3]||"");return{type:"code",raw:s,lang:t[2]?t[2].trim().replace(this.rules.inline._escapes,"$1"):t[2],text:r}}}heading(e){const t=this.rules.block.heading.exec(e);if(t){let s=t[2].trim();if(/#$/.test(s)){const r=Kn(s,"#");(this.options.pedantic||!r||/ $/.test(r))&&(s=r.trim())}return{type:"heading",raw:t[0],depth:t[1].length,text:s,tokens:this.lexer.inline(s)}}}hr(e){const t=this.rules.block.hr.exec(e);if(t)return{type:"hr",raw:t[0]}}blockquote(e){const t=this.rules.block.blockquote.exec(e);if(t){const s=Kn(t[0].replace(/^ *>[ \t]?/gm,""),`
`),r=this.lexer.state.top;this.lexer.state.top=!0;const i=this.lexer.blockTokens(s);return this.lexer.state.top=r,{type:"blockquote",raw:t[0],tokens:i,text:s}}}list(e){let t=this.rules.block.list.exec(e);if(t){let s=t[1].trim();const r=s.length>1,i={type:"list",raw:"",ordered:r,start:r?+s.slice(0,-1):"",loose:!1,items:[]};s=r?`\\d{1,9}\\${s.slice(-1)}`:`\\${s}`,this.options.pedantic&&(s=r?s:"[*+-]");const a=new RegExp(`^( {0,3}${s})((?:[	 ][^\\n]*)?(?:\\n|$))`);let l="",c="",h=!1;for(;e;){let u=!1;if(!(t=a.exec(e))||this.rules.block.hr.test(e))break;l=t[0],e=e.substring(l.length);let g=t[2].split(`
`,1)[0].replace(/^\t+/,Q=>" ".repeat(3*Q.length)),p=e.split(`
`,1)[0],v=0;this.options.pedantic?(v=2,c=g.trimStart()):(v=t[2].search(/[^ ]/),v=v>4?1:v,c=g.slice(v),v+=t[1].length);let w=!1;if(!g&&/^ *$/.test(p)&&(l+=p+`
`,e=e.substring(p.length+1),u=!0),!u){const Q=new RegExp(`^ {0,${Math.min(3,v-1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`),B=new RegExp(`^ {0,${Math.min(3,v-1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`),R=new RegExp(`^ {0,${Math.min(3,v-1)}}(?:\`\`\`|~~~)`),D=new RegExp(`^ {0,${Math.min(3,v-1)}}#`);for(;e;){const se=e.split(`
`,1)[0];if(p=se,this.options.pedantic&&(p=p.replace(/^ {1,4}(?=( {4})*[^ ])/g,"  ")),R.test(p)||D.test(p)||Q.test(p)||B.test(e))break;if(p.search(/[^ ]/)>=v||!p.trim())c+=`
`+p.slice(v);else{if(w||g.search(/[^ ]/)>=4||R.test(g)||D.test(g)||B.test(g))break;c+=`
`+p}!w&&!p.trim()&&(w=!0),l+=se+`
`,e=e.substring(se.length+1),g=p.slice(v)}}i.loose||(h?i.loose=!0:/\n *\n *$/.test(l)&&(h=!0));let L=null,U;this.options.gfm&&(L=/^\[[ xX]\] /.exec(c),L&&(U=L[0]!=="[ ] ",c=c.replace(/^\[[ xX]\] +/,""))),i.items.push({type:"list_item",raw:l,task:!!L,checked:U,loose:!1,text:c,tokens:[]}),i.raw+=l}i.items[i.items.length-1].raw=l.trimEnd(),i.items[i.items.length-1].text=c.trimEnd(),i.raw=i.raw.trimEnd();for(let u=0;u<i.items.length;u++)if(this.lexer.state.top=!1,i.items[u].tokens=this.lexer.blockTokens(i.items[u].text,[]),!i.loose){const g=i.items[u].tokens.filter(v=>v.type==="space"),p=g.length>0&&g.some(v=>/\n.*\n/.test(v.raw));i.loose=p}if(i.loose)for(let u=0;u<i.items.length;u++)i.items[u].loose=!0;return i}}html(e){const t=this.rules.block.html.exec(e);if(t)return{type:"html",block:!0,raw:t[0],pre:t[1]==="pre"||t[1]==="script"||t[1]==="style",text:t[0]}}def(e){const t=this.rules.block.def.exec(e);if(t){const s=t[1].toLowerCase().replace(/\s+/g," "),r=t[2]?t[2].replace(/^<(.*)>$/,"$1").replace(this.rules.inline._escapes,"$1"):"",i=t[3]?t[3].substring(1,t[3].length-1).replace(this.rules.inline._escapes,"$1"):t[3];return{type:"def",tag:s,raw:t[0],href:r,title:i}}}table(e){const t=this.rules.block.table.exec(e);if(t){if(!/[:|]/.test(t[2]))return;const s={type:"table",raw:t[0],header:Fi(t[1]).map(r=>({text:r,tokens:[]})),align:t[2].replace(/^\||\| *$/g,"").split("|"),rows:t[3]&&t[3].trim()?t[3].replace(/\n[ \t]*$/,"").split(`
`):[]};if(s.header.length===s.align.length){let r=s.align.length,i,a,l,c;for(i=0;i<r;i++){const h=s.align[i];h&&(/^ *-+: *$/.test(h)?s.align[i]="right":/^ *:-+: *$/.test(h)?s.align[i]="center":/^ *:-+ *$/.test(h)?s.align[i]="left":s.align[i]=null)}for(r=s.rows.length,i=0;i<r;i++)s.rows[i]=Fi(s.rows[i],s.header.length).map(h=>({text:h,tokens:[]}));for(r=s.header.length,a=0;a<r;a++)s.header[a].tokens=this.lexer.inline(s.header[a].text);for(r=s.rows.length,a=0;a<r;a++)for(c=s.rows[a],l=0;l<c.length;l++)c[l].tokens=this.lexer.inline(c[l].text);return s}}}lheading(e){const t=this.rules.block.lheading.exec(e);if(t)return{type:"heading",raw:t[0],depth:t[2].charAt(0)==="="?1:2,text:t[1],tokens:this.lexer.inline(t[1])}}paragraph(e){const t=this.rules.block.paragraph.exec(e);if(t){const s=t[1].charAt(t[1].length-1)===`
`?t[1].slice(0,-1):t[1];return{type:"paragraph",raw:t[0],text:s,tokens:this.lexer.inline(s)}}}text(e){const t=this.rules.block.text.exec(e);if(t)return{type:"text",raw:t[0],text:t[0],tokens:this.lexer.inline(t[0])}}escape(e){const t=this.rules.inline.escape.exec(e);if(t)return{type:"escape",raw:t[0],text:Me(t[1])}}tag(e){const t=this.rules.inline.tag.exec(e);if(t)return!this.lexer.state.inLink&&/^<a /i.test(t[0])?this.lexer.state.inLink=!0:this.lexer.state.inLink&&/^<\/a>/i.test(t[0])&&(this.lexer.state.inLink=!1),!this.lexer.state.inRawBlock&&/^<(pre|code|kbd|script)(\s|>)/i.test(t[0])?this.lexer.state.inRawBlock=!0:this.lexer.state.inRawBlock&&/^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0])&&(this.lexer.state.inRawBlock=!1),{type:"html",raw:t[0],inLink:this.lexer.state.inLink,inRawBlock:this.lexer.state.inRawBlock,block:!1,text:t[0]}}link(e){const t=this.rules.inline.link.exec(e);if(t){const s=t[2].trim();if(!this.options.pedantic&&/^</.test(s)){if(!/>$/.test(s))return;const a=Kn(s.slice(0,-1),"\\");if((s.length-a.length)%2===0)return}else{const a=Gc(t[2],"()");if(a>-1){const l=(t[0].indexOf("!")===0?5:4)+t[1].length+a;t[2]=t[2].substring(0,a),t[0]=t[0].substring(0,l).trim(),t[3]=""}}let r=t[2],i="";if(this.options.pedantic){const a=/^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(r);a&&(r=a[1],i=a[3])}else i=t[3]?t[3].slice(1,-1):"";return r=r.trim(),/^</.test(r)&&(this.options.pedantic&&!/>$/.test(s)?r=r.slice(1):r=r.slice(1,-1)),qi(t,{href:r&&r.replace(this.rules.inline._escapes,"$1"),title:i&&i.replace(this.rules.inline._escapes,"$1")},t[0],this.lexer)}}reflink(e,t){let s;if((s=this.rules.inline.reflink.exec(e))||(s=this.rules.inline.nolink.exec(e))){let r=(s[2]||s[1]).replace(/\s+/g," ");if(r=t[r.toLowerCase()],!r){const i=s[0].charAt(0);return{type:"text",raw:i,text:i}}return qi(s,r,s[0],this.lexer)}}emStrong(e,t,s=""){let r=this.rules.inline.emStrong.lDelim.exec(e);if(!(!r||r[3]&&s.match(/[\p{L}\p{N}]/u))&&(!(r[1]||r[2])||!s||this.rules.inline.punctuation.exec(s))){const i=[...r[0]].length-1;let a,l,c=i,h=0;const u=r[0][0]==="*"?this.rules.inline.emStrong.rDelimAst:this.rules.inline.emStrong.rDelimUnd;for(u.lastIndex=0,t=t.slice(-1*e.length+i);(r=u.exec(t))!=null;){if(a=r[1]||r[2]||r[3]||r[4]||r[5]||r[6],!a)continue;if(l=[...a].length,r[3]||r[4]){c+=l;continue}else if((r[5]||r[6])&&i%3&&!((i+l)%3)){h+=l;continue}if(c-=l,c>0)continue;l=Math.min(l,l+c+h);const g=[...r[0]][0].length,p=e.slice(0,i+r.index+g+l);if(Math.min(i,l)%2){const w=p.slice(1,-1);return{type:"em",raw:p,text:w,tokens:this.lexer.inlineTokens(w)}}const v=p.slice(2,-2);return{type:"strong",raw:p,text:v,tokens:this.lexer.inlineTokens(v)}}}}codespan(e){const t=this.rules.inline.code.exec(e);if(t){let s=t[2].replace(/\n/g," ");const r=/[^ ]/.test(s),i=/^ /.test(s)&&/ $/.test(s);return r&&i&&(s=s.substring(1,s.length-1)),s=Me(s,!0),{type:"codespan",raw:t[0],text:s}}}br(e){const t=this.rules.inline.br.exec(e);if(t)return{type:"br",raw:t[0]}}del(e){const t=this.rules.inline.del.exec(e);if(t)return{type:"del",raw:t[0],text:t[2],tokens:this.lexer.inlineTokens(t[2])}}autolink(e){const t=this.rules.inline.autolink.exec(e);if(t){let s,r;return t[2]==="@"?(s=Me(t[1]),r="mailto:"+s):(s=Me(t[1]),r=s),{type:"link",raw:t[0],text:s,href:r,tokens:[{type:"text",raw:s,text:s}]}}}url(e){let t;if(t=this.rules.inline.url.exec(e)){let s,r;if(t[2]==="@")s=Me(t[0]),r="mailto:"+s;else{let i;do i=t[0],t[0]=this.rules.inline._backpedal.exec(t[0])[0];while(i!==t[0]);s=Me(t[0]),t[1]==="www."?r="http://"+t[0]:r=t[0]}return{type:"link",raw:t[0],text:s,href:r,tokens:[{type:"text",raw:s,text:s}]}}}inlineText(e){const t=this.rules.inline.text.exec(e);if(t){let s;return this.lexer.state.inRawBlock?s=t[0]:s=Me(t[0]),{type:"text",raw:t[0],text:s}}}}const O={newline:/^(?: *(?:\n|$))+/,code:/^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/,fences:/^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/,hr:/^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/,heading:/^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/,blockquote:/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/,list:/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/,html:"^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))",def:/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/,table:xs,lheading:/^(?!bull )((?:.|\n(?!\s*?\n|bull ))+?)\n {0,3}(=+|-+) *(?:\n+|$)/,_paragraph:/^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/,text:/^[^\n]+/};O._label=/(?!\s*\])(?:\\.|[^\[\]\\])+/;O._title=/(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/;O.def=G(O.def).replace("label",O._label).replace("title",O._title).getRegex();O.bullet=/(?:[*+-]|\d{1,9}[.)])/;O.listItemStart=G(/^( *)(bull) */).replace("bull",O.bullet).getRegex();O.list=G(O.list).replace(/bull/g,O.bullet).replace("hr","\\n+(?=\\1?(?:(?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$))").replace("def","\\n+(?="+O.def.source+")").getRegex();O._tag="address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|section|source|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul";O._comment=/<!--(?!-?>)[\s\S]*?(?:-->|$)/;O.html=G(O.html,"i").replace("comment",O._comment).replace("tag",O._tag).replace("attribute",/ +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex();O.lheading=G(O.lheading).replace(/bull/g,O.bullet).getRegex();O.paragraph=G(O._paragraph).replace("hr",O.hr).replace("heading"," {0,3}#{1,6}(?:\\s|$)").replace("|lheading","").replace("|table","").replace("blockquote"," {0,3}>").replace("fences"," {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list"," {0,3}(?:[*+-]|1[.)]) ").replace("html","</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag",O._tag).getRegex();O.blockquote=G(O.blockquote).replace("paragraph",O.paragraph).getRegex();O.normal={...O};O.gfm={...O.normal,table:"^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)"};O.gfm.table=G(O.gfm.table).replace("hr",O.hr).replace("heading"," {0,3}#{1,6}(?:\\s|$)").replace("blockquote"," {0,3}>").replace("code"," {4}[^\\n]").replace("fences"," {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list"," {0,3}(?:[*+-]|1[.)]) ").replace("html","</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag",O._tag).getRegex();O.gfm.paragraph=G(O._paragraph).replace("hr",O.hr).replace("heading"," {0,3}#{1,6}(?:\\s|$)").replace("|lheading","").replace("table",O.gfm.table).replace("blockquote"," {0,3}>").replace("fences"," {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list"," {0,3}(?:[*+-]|1[.)]) ").replace("html","</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag",O._tag).getRegex();O.pedantic={...O.normal,html:G(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment",O._comment).replace(/tag/g,"(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),def:/^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,heading:/^(#{1,6})(.*)(?:\n+|$)/,fences:xs,lheading:/^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,paragraph:G(O.normal._paragraph).replace("hr",O.hr).replace("heading",` *#{1,6} *[^
]`).replace("lheading",O.lheading).replace("blockquote"," {0,3}>").replace("|fences","").replace("|list","").replace("|html","").getRegex()};const S={escape:/^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/,autolink:/^<(scheme:[^\s\x00-\x1f<>]*|email)>/,url:xs,tag:"^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>",link:/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/,reflink:/^!?\[(label)\]\[(ref)\]/,nolink:/^!?\[(ref)\](?:\[\])?/,reflinkSearch:"reflink|nolink(?!\\()",emStrong:{lDelim:/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/,rDelimAst:/^[^_*]*?__[^_*]*?\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\*)[punct](\*+)(?=[\s]|$)|[^punct\s](\*+)(?!\*)(?=[punct\s]|$)|(?!\*)[punct\s](\*+)(?=[^punct\s])|[\s](\*+)(?!\*)(?=[punct])|(?!\*)[punct](\*+)(?!\*)(?=[punct])|[^punct\s](\*+)(?=[^punct\s])/,rDelimUnd:/^[^_*]*?\*\*[^_*]*?_[^_*]*?(?=\*\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\s]|$)|[^punct\s](_+)(?!_)(?=[punct\s]|$)|(?!_)[punct\s](_+)(?=[^punct\s])|[\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])/},code:/^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/,br:/^( {2,}|\\)\n(?!\s*$)/,del:xs,text:/^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/,punctuation:/^((?![*_])[\spunctuation])/};S._punctuation="\\p{P}$+<=>`^|~";S.punctuation=G(S.punctuation,"u").replace(/punctuation/g,S._punctuation).getRegex();S.blockSkip=/\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g;S.anyPunctuation=/\\[punct]/g;S._escapes=/\\([punct])/g;S._comment=G(O._comment).replace("(?:-->|$)","-->").getRegex();S.emStrong.lDelim=G(S.emStrong.lDelim,"u").replace(/punct/g,S._punctuation).getRegex();S.emStrong.rDelimAst=G(S.emStrong.rDelimAst,"gu").replace(/punct/g,S._punctuation).getRegex();S.emStrong.rDelimUnd=G(S.emStrong.rDelimUnd,"gu").replace(/punct/g,S._punctuation).getRegex();S.anyPunctuation=G(S.anyPunctuation,"gu").replace(/punct/g,S._punctuation).getRegex();S._escapes=G(S._escapes,"gu").replace(/punct/g,S._punctuation).getRegex();S._scheme=/[a-zA-Z][a-zA-Z0-9+.-]{1,31}/;S._email=/[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/;S.autolink=G(S.autolink).replace("scheme",S._scheme).replace("email",S._email).getRegex();S._attribute=/\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/;S.tag=G(S.tag).replace("comment",S._comment).replace("attribute",S._attribute).getRegex();S._label=/(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/;S._href=/<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/;S._title=/"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/;S.link=G(S.link).replace("label",S._label).replace("href",S._href).replace("title",S._title).getRegex();S.reflink=G(S.reflink).replace("label",S._label).replace("ref",O._label).getRegex();S.nolink=G(S.nolink).replace("ref",O._label).getRegex();S.reflinkSearch=G(S.reflinkSearch,"g").replace("reflink",S.reflink).replace("nolink",S.nolink).getRegex();S.normal={...S};S.pedantic={...S.normal,strong:{start:/^__|\*\*/,middle:/^__(?=\S)([\s\S]*?\S)__(?!_)|^\*\*(?=\S)([\s\S]*?\S)\*\*(?!\*)/,endAst:/\*\*(?!\*)/g,endUnd:/__(?!_)/g},em:{start:/^_|\*/,middle:/^()\*(?=\S)([\s\S]*?\S)\*(?!\*)|^_(?=\S)([\s\S]*?\S)_(?!_)/,endAst:/\*(?!\*)/g,endUnd:/_(?!_)/g},link:G(/^!?\[(label)\]\((.*?)\)/).replace("label",S._label).getRegex(),reflink:G(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label",S._label).getRegex()};S.gfm={...S.normal,escape:G(S.escape).replace("])","~|])").getRegex(),_extended_email:/[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/,url:/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/,_backpedal:/(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,del:/^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,text:/^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/};S.gfm.url=G(S.gfm.url,"i").replace("email",S.gfm._extended_email).getRegex();S.breaks={...S.gfm,br:G(S.br).replace("{2,}","*").getRegex(),text:G(S.gfm.text).replace("\\b_","\\b_| {2,}\\n").replace(/\{2,\}/g,"*").getRegex()};class nt{constructor(e){_(this,"tokens"),_(this,"options"),_(this,"state"),_(this,"tokenizer"),_(this,"inlineQueue"),this.tokens=[],this.tokens.links=Object.create(null),this.options=e||nn,this.options.tokenizer=this.options.tokenizer||new _s,this.tokenizer=this.options.tokenizer,this.tokenizer.options=this.options,this.tokenizer.lexer=this,this.inlineQueue=[],this.state={inLink:!1,inRawBlock:!1,top:!0};const t={block:O.normal,inline:S.normal};this.options.pedantic?(t.block=O.pedantic,t.inline=S.pedantic):this.options.gfm&&(t.block=O.gfm,this.options.breaks?t.inline=S.breaks:t.inline=S.gfm),this.tokenizer.rules=t}static get rules(){return{block:O,inline:S}}static lex(e,t){return new nt(t).lex(e)}static lexInline(e,t){return new nt(t).inlineTokens(e)}lex(e){e=e.replace(/\r\n|\r/g,`
`),this.blockTokens(e,this.tokens);let t;for(;t=this.inlineQueue.shift();)this.inlineTokens(t.src,t.tokens);return this.tokens}blockTokens(e,t=[]){this.options.pedantic?e=e.replace(/\t/g,"    ").replace(/^ +$/gm,""):e=e.replace(/^( *)(\t+)/gm,(l,c,h)=>c+"    ".repeat(h.length));let s,r,i,a;for(;e;)if(!(this.options.extensions&&this.options.extensions.block&&this.options.extensions.block.some(l=>(s=l.call({lexer:this},e,t))?(e=e.substring(s.raw.length),t.push(s),!0):!1))){if(s=this.tokenizer.space(e)){e=e.substring(s.raw.length),s.raw.length===1&&t.length>0?t[t.length-1].raw+=`
`:t.push(s);continue}if(s=this.tokenizer.code(e)){e=e.substring(s.raw.length),r=t[t.length-1],r&&(r.type==="paragraph"||r.type==="text")?(r.raw+=`
`+s.raw,r.text+=`
`+s.text,this.inlineQueue[this.inlineQueue.length-1].src=r.text):t.push(s);continue}if(s=this.tokenizer.fences(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.heading(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.hr(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.blockquote(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.list(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.html(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.def(e)){e=e.substring(s.raw.length),r=t[t.length-1],r&&(r.type==="paragraph"||r.type==="text")?(r.raw+=`
`+s.raw,r.text+=`
`+s.raw,this.inlineQueue[this.inlineQueue.length-1].src=r.text):this.tokens.links[s.tag]||(this.tokens.links[s.tag]={href:s.href,title:s.title});continue}if(s=this.tokenizer.table(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.lheading(e)){e=e.substring(s.raw.length),t.push(s);continue}if(i=e,this.options.extensions&&this.options.extensions.startBlock){let l=1/0;const c=e.slice(1);let h;this.options.extensions.startBlock.forEach(u=>{h=u.call({lexer:this},c),typeof h=="number"&&h>=0&&(l=Math.min(l,h))}),l<1/0&&l>=0&&(i=e.substring(0,l+1))}if(this.state.top&&(s=this.tokenizer.paragraph(i))){r=t[t.length-1],a&&r.type==="paragraph"?(r.raw+=`
`+s.raw,r.text+=`
`+s.text,this.inlineQueue.pop(),this.inlineQueue[this.inlineQueue.length-1].src=r.text):t.push(s),a=i.length!==e.length,e=e.substring(s.raw.length);continue}if(s=this.tokenizer.text(e)){e=e.substring(s.raw.length),r=t[t.length-1],r&&r.type==="text"?(r.raw+=`
`+s.raw,r.text+=`
`+s.text,this.inlineQueue.pop(),this.inlineQueue[this.inlineQueue.length-1].src=r.text):t.push(s);continue}if(e){const l="Infinite loop on byte: "+e.charCodeAt(0);if(this.options.silent){console.error(l);break}else throw new Error(l)}}return this.state.top=!0,t}inline(e,t=[]){return this.inlineQueue.push({src:e,tokens:t}),t}inlineTokens(e,t=[]){let s,r,i,a=e,l,c,h;if(this.tokens.links){const u=Object.keys(this.tokens.links);if(u.length>0)for(;(l=this.tokenizer.rules.inline.reflinkSearch.exec(a))!=null;)u.includes(l[0].slice(l[0].lastIndexOf("[")+1,-1))&&(a=a.slice(0,l.index)+"["+"a".repeat(l[0].length-2)+"]"+a.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex))}for(;(l=this.tokenizer.rules.inline.blockSkip.exec(a))!=null;)a=a.slice(0,l.index)+"["+"a".repeat(l[0].length-2)+"]"+a.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);for(;(l=this.tokenizer.rules.inline.anyPunctuation.exec(a))!=null;)a=a.slice(0,l.index)+"++"+a.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);for(;e;)if(c||(h=""),c=!1,!(this.options.extensions&&this.options.extensions.inline&&this.options.extensions.inline.some(u=>(s=u.call({lexer:this},e,t))?(e=e.substring(s.raw.length),t.push(s),!0):!1))){if(s=this.tokenizer.escape(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.tag(e)){e=e.substring(s.raw.length),r=t[t.length-1],r&&s.type==="text"&&r.type==="text"?(r.raw+=s.raw,r.text+=s.text):t.push(s);continue}if(s=this.tokenizer.link(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.reflink(e,this.tokens.links)){e=e.substring(s.raw.length),r=t[t.length-1],r&&s.type==="text"&&r.type==="text"?(r.raw+=s.raw,r.text+=s.text):t.push(s);continue}if(s=this.tokenizer.emStrong(e,a,h)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.codespan(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.br(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.del(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.autolink(e)){e=e.substring(s.raw.length),t.push(s);continue}if(!this.state.inLink&&(s=this.tokenizer.url(e))){e=e.substring(s.raw.length),t.push(s);continue}if(i=e,this.options.extensions&&this.options.extensions.startInline){let u=1/0;const g=e.slice(1);let p;this.options.extensions.startInline.forEach(v=>{p=v.call({lexer:this},g),typeof p=="number"&&p>=0&&(u=Math.min(u,p))}),u<1/0&&u>=0&&(i=e.substring(0,u+1))}if(s=this.tokenizer.inlineText(i)){e=e.substring(s.raw.length),s.raw.slice(-1)!=="_"&&(h=s.raw.slice(-1)),c=!0,r=t[t.length-1],r&&r.type==="text"?(r.raw+=s.raw,r.text+=s.text):t.push(s);continue}if(e){const u="Infinite loop on byte: "+e.charCodeAt(0);if(this.options.silent){console.error(u);break}else throw new Error(u)}}return t}}class ws{constructor(e){_(this,"options"),this.options=e||nn}code(e,t,s){var r;const i=(r=(t||"").match(/^\S*/))==null?void 0:r[0];return e=e.replace(/\n$/,"")+`
`,i?'<pre><code class="language-'+Me(i)+'">'+(s?e:Me(e,!0))+`</code></pre>
`:"<pre><code>"+(s?e:Me(e,!0))+`</code></pre>
`}blockquote(e){return`<blockquote>
${e}</blockquote>
`}html(e,t){return e}heading(e,t,s){return`<h${t}>${e}</h${t}>
`}hr(){return`<hr>
`}list(e,t,s){const r=t?"ol":"ul",i=t&&s!==1?' start="'+s+'"':"";return"<"+r+i+`>
`+e+"</"+r+`>
`}listitem(e,t,s){return`<li>${e}</li>
`}checkbox(e){return"<input "+(e?'checked="" ':"")+'disabled="" type="checkbox">'}paragraph(e){return`<p>${e}</p>
`}table(e,t){return t&&(t=`<tbody>${t}</tbody>`),`<table>
<thead>
`+e+`</thead>
`+t+`</table>
`}tablerow(e){return`<tr>
${e}</tr>
`}tablecell(e,t){const s=t.header?"th":"td";return(t.align?`<${s} align="${t.align}">`:`<${s}>`)+e+`</${s}>
`}strong(e){return`<strong>${e}</strong>`}em(e){return`<em>${e}</em>`}codespan(e){return`<code>${e}</code>`}br(){return"<br>"}del(e){return`<del>${e}</del>`}link(e,t,s){const r=zi(e);if(r===null)return s;e=r;let i='<a href="'+e+'"';return t&&(i+=' title="'+t+'"'),i+=">"+s+"</a>",i}image(e,t,s){const r=zi(e);if(r===null)return s;e=r;let i=`<img src="${e}" alt="${s}"`;return t&&(i+=` title="${t}"`),i+=">",i}text(e){return e}}class Wr{strong(e){return e}em(e){return e}codespan(e){return e}del(e){return e}html(e){return e}text(e){return e}link(e,t,s){return""+s}image(e,t,s){return""+s}br(){return""}}class st{constructor(e){_(this,"options"),_(this,"renderer"),_(this,"textRenderer"),this.options=e||nn,this.options.renderer=this.options.renderer||new ws,this.renderer=this.options.renderer,this.renderer.options=this.options,this.textRenderer=new Wr}static parse(e,t){return new st(t).parse(e)}static parseInline(e,t){return new st(t).parseInline(e)}parse(e,t=!0){let s="";for(let r=0;r<e.length;r++){const i=e[r];if(this.options.extensions&&this.options.extensions.renderers&&this.options.extensions.renderers[i.type]){const a=i,l=this.options.extensions.renderers[a.type].call({parser:this},a);if(l!==!1||!["space","hr","heading","code","table","blockquote","list","html","paragraph","text"].includes(a.type)){s+=l||"";continue}}switch(i.type){case"space":continue;case"hr":{s+=this.renderer.hr();continue}case"heading":{const a=i;s+=this.renderer.heading(this.parseInline(a.tokens),a.depth,Vc(this.parseInline(a.tokens,this.textRenderer)));continue}case"code":{const a=i;s+=this.renderer.code(a.text,a.lang,!!a.escaped);continue}case"table":{const a=i;let l="",c="";for(let u=0;u<a.header.length;u++)c+=this.renderer.tablecell(this.parseInline(a.header[u].tokens),{header:!0,align:a.align[u]});l+=this.renderer.tablerow(c);let h="";for(let u=0;u<a.rows.length;u++){const g=a.rows[u];c="";for(let p=0;p<g.length;p++)c+=this.renderer.tablecell(this.parseInline(g[p].tokens),{header:!1,align:a.align[p]});h+=this.renderer.tablerow(c)}s+=this.renderer.table(l,h);continue}case"blockquote":{const a=i,l=this.parse(a.tokens);s+=this.renderer.blockquote(l);continue}case"list":{const a=i,l=a.ordered,c=a.start,h=a.loose;let u="";for(let g=0;g<a.items.length;g++){const p=a.items[g],v=p.checked,w=p.task;let L="";if(p.task){const U=this.renderer.checkbox(!!v);h?p.tokens.length>0&&p.tokens[0].type==="paragraph"?(p.tokens[0].text=U+" "+p.tokens[0].text,p.tokens[0].tokens&&p.tokens[0].tokens.length>0&&p.tokens[0].tokens[0].type==="text"&&(p.tokens[0].tokens[0].text=U+" "+p.tokens[0].tokens[0].text)):p.tokens.unshift({type:"text",text:U+" "}):L+=U+" "}L+=this.parse(p.tokens,h),u+=this.renderer.listitem(L,w,!!v)}s+=this.renderer.list(u,l,c);continue}case"html":{const a=i;s+=this.renderer.html(a.text,a.block);continue}case"paragraph":{const a=i;s+=this.renderer.paragraph(this.parseInline(a.tokens));continue}case"text":{let a=i,l=a.tokens?this.parseInline(a.tokens):a.text;for(;r+1<e.length&&e[r+1].type==="text";)a=e[++r],l+=`
`+(a.tokens?this.parseInline(a.tokens):a.text);s+=t?this.renderer.paragraph(l):l;continue}default:{const a='Token with "'+i.type+'" type was not found.';if(this.options.silent)return console.error(a),"";throw new Error(a)}}}return s}parseInline(e,t){t=t||this.renderer;let s="";for(let r=0;r<e.length;r++){const i=e[r];if(this.options.extensions&&this.options.extensions.renderers&&this.options.extensions.renderers[i.type]){const a=this.options.extensions.renderers[i.type].call({parser:this},i);if(a!==!1||!["escape","html","link","image","strong","em","codespan","br","del","text"].includes(i.type)){s+=a||"";continue}}switch(i.type){case"escape":{const a=i;s+=t.text(a.text);break}case"html":{const a=i;s+=t.html(a.text);break}case"link":{const a=i;s+=t.link(a.href,a.title,this.parseInline(a.tokens,t));break}case"image":{const a=i;s+=t.image(a.href,a.title,a.text);break}case"strong":{const a=i;s+=t.strong(this.parseInline(a.tokens,t));break}case"em":{const a=i;s+=t.em(this.parseInline(a.tokens,t));break}case"codespan":{const a=i;s+=t.codespan(a.text);break}case"br":{s+=t.br();break}case"del":{const a=i;s+=t.del(this.parseInline(a.tokens,t));break}case"text":{const a=i;s+=t.text(a.text);break}default:{const a='Token with "'+i.type+'" type was not found.';if(this.options.silent)return console.error(a),"";throw new Error(a)}}}return s}}class In{constructor(e){_(this,"options"),this.options=e||nn}preprocess(e){return e}postprocess(e){return e}}_(In,"passThroughHooks",new Set(["preprocess","postprocess"]));var $n,yr,Vi;class Zc{constructor(...e){yt(this,$n),_(this,"defaults",Vr()),_(this,"options",this.setOptions),_(this,"parse",tr(this,$n,yr).call(this,nt.lex,st.parse)),_(this,"parseInline",tr(this,$n,yr).call(this,nt.lexInline,st.parseInline)),_(this,"Parser",st),_(this,"Renderer",ws),_(this,"TextRenderer",Wr),_(this,"Lexer",nt),_(this,"Tokenizer",_s),_(this,"Hooks",In),this.use(...e)}walkTokens(e,t){var s,r;let i=[];for(const a of e)switch(i=i.concat(t.call(this,a)),a.type){case"table":{const l=a;for(const c of l.header)i=i.concat(this.walkTokens(c.tokens,t));for(const c of l.rows)for(const h of c)i=i.concat(this.walkTokens(h.tokens,t));break}case"list":{const l=a;i=i.concat(this.walkTokens(l.items,t));break}default:{const l=a;(r=(s=this.defaults.extensions)==null?void 0:s.childTokens)!=null&&r[l.type]?this.defaults.extensions.childTokens[l.type].forEach(c=>{i=i.concat(this.walkTokens(l[c],t))}):l.tokens&&(i=i.concat(this.walkTokens(l.tokens,t)))}}return i}use(...e){const t=this.defaults.extensions||{renderers:{},childTokens:{}};return e.forEach(s=>{const r={...s};if(r.async=this.defaults.async||r.async||!1,s.extensions&&(s.extensions.forEach(i=>{if(!i.name)throw new Error("extension name required");if("renderer"in i){const a=t.renderers[i.name];a?t.renderers[i.name]=function(...l){let c=i.renderer.apply(this,l);return c===!1&&(c=a.apply(this,l)),c}:t.renderers[i.name]=i.renderer}if("tokenizer"in i){if(!i.level||i.level!=="block"&&i.level!=="inline")throw new Error("extension level must be 'block' or 'inline'");const a=t[i.level];a?a.unshift(i.tokenizer):t[i.level]=[i.tokenizer],i.start&&(i.level==="block"?t.startBlock?t.startBlock.push(i.start):t.startBlock=[i.start]:i.level==="inline"&&(t.startInline?t.startInline.push(i.start):t.startInline=[i.start]))}"childTokens"in i&&i.childTokens&&(t.childTokens[i.name]=i.childTokens)}),r.extensions=t),s.renderer){const i=this.defaults.renderer||new ws(this.defaults);for(const a in s.renderer){const l=s.renderer[a],c=a,h=i[c];i[c]=(...u)=>{let g=l.apply(i,u);return g===!1&&(g=h.apply(i,u)),g||""}}r.renderer=i}if(s.tokenizer){const i=this.defaults.tokenizer||new _s(this.defaults);for(const a in s.tokenizer){const l=s.tokenizer[a],c=a,h=i[c];i[c]=(...u)=>{let g=l.apply(i,u);return g===!1&&(g=h.apply(i,u)),g}}r.tokenizer=i}if(s.hooks){const i=this.defaults.hooks||new In;for(const a in s.hooks){const l=s.hooks[a],c=a,h=i[c];In.passThroughHooks.has(a)?i[c]=u=>{if(this.defaults.async)return Promise.resolve(l.call(i,u)).then(p=>h.call(i,p));const g=l.call(i,u);return h.call(i,g)}:i[c]=(...u)=>{let g=l.apply(i,u);return g===!1&&(g=h.apply(i,u)),g}}r.hooks=i}if(s.walkTokens){const i=this.defaults.walkTokens,a=s.walkTokens;r.walkTokens=function(l){let c=[];return c.push(a.call(this,l)),i&&(c=c.concat(i.call(this,l))),c}}this.defaults={...this.defaults,...r}}),this}setOptions(e){return this.defaults={...this.defaults,...e},this}lexer(e,t){return nt.lex(e,t??this.defaults)}parser(e,t){return st.parse(e,t??this.defaults)}}$n=new WeakSet,yr=function(n,e){return(t,s)=>{const r={...s},i={...this.defaults,...r};this.defaults.async===!0&&r.async===!1&&(i.silent||console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."),i.async=!0);const a=tr(this,$n,Vi).call(this,!!i.silent,!!i.async);if(typeof t>"u"||t===null)return a(new Error("marked(): input parameter is undefined or null"));if(typeof t!="string")return a(new Error("marked(): input parameter is of type "+Object.prototype.toString.call(t)+", string expected"));if(i.hooks&&(i.hooks.options=i),i.async)return Promise.resolve(i.hooks?i.hooks.preprocess(t):t).then(l=>n(l,i)).then(l=>i.walkTokens?Promise.all(this.walkTokens(l,i.walkTokens)).then(()=>l):l).then(l=>e(l,i)).then(l=>i.hooks?i.hooks.postprocess(l):l).catch(a);try{i.hooks&&(t=i.hooks.preprocess(t));const l=n(t,i);i.walkTokens&&this.walkTokens(l,i.walkTokens);let c=e(l,i);return i.hooks&&(c=i.hooks.postprocess(c)),c}catch(l){return a(l)}}},Vi=function(n,e){return t=>{if(t.message+=`
Please report this to https://github.com/markedjs/marked.`,n){const s="<p>An error occurred:</p><pre>"+Me(t.message+"",!0)+"</pre>";return e?Promise.resolve(s):s}if(e)return Promise.reject(t);throw t}};const en=new Zc;function X(n,e){return en.parse(n,e)}X.options=X.setOptions=function(n){return en.setOptions(n),X.defaults=en.defaults,Va(X.defaults),X};X.getDefaults=Vr;X.defaults=nn;X.use=function(...n){return en.use(...n),X.defaults=en.defaults,Va(X.defaults),X};X.walkTokens=function(n,e){return en.walkTokens(n,e)};X.parseInline=en.parseInline;X.Parser=st;X.parser=st.parse;X.Renderer=ws;X.TextRenderer=Wr;X.Lexer=nt;X.lexer=nt.lex;X.Tokenizer=_s;X.Hooks=In;X.parse=X;X.options;X.setOptions;X.use;X.walkTokens;X.parseInline;st.parse;nt.lex;var Xc=Object.defineProperty,Qc=Object.getOwnPropertyDescriptor,Is=(n,e,t,s)=>{for(var r=s>1?void 0:s?Qc(e,t):e,i=n.length-1,a;i>=0;i--)(a=n[i])&&(r=(s?a(e,t,r):a(r))||r);return s&&r&&Xc(e,t,r),r};let Mn=class extends Ne{constructor(){super(...arguments),this.url=void 0,this.previewContent=void 0,this.loading=!1}retrieveMarkdown(){this.url&&fetch(this.url).then(n=>n.text()).then(n=>{this.previewContent=X.parse(n)}).finally(()=>{this.loading=!1})}willUpdate(n){this.url&&n.has("url")&&n.get("url")!==this.url&&this.url.endsWith(".md")&&(this.loading=!0,this.retrieveMarkdown())}renderContent(){return this.url?$`
        ${this.previewContent?$` ${ps(this.previewContent)}`:$` <iframe title="Preview" src="${this.url}" width="100%" height="850px" sandbox />`}
      `:$``}render(){return $`
      ${this.loading?$`<loading-indicator label="${W.LOADING_TEXT}"></loading-indicator>`:this.renderContent()}
    `}};Is([H({type:String})],Mn.prototype,"url",2);Is([tn()],Mn.prototype,"previewContent",2);Is([tn()],Mn.prototype,"loading",2);Mn=Is([Ke("document-previewer")],Mn);var Kc=(n,e,t,s)=>{for(var r=e,i=n.length-1,a;i>=0;i--)(a=n[i])&&(r=a(r)||r);return r};let vr=class extends Oe{render(n,e){return $`<document-previewer url="${e}"></document-previewer>`}};vr=Kc([Ie()],vr);be.bind(ne.Citation).to(vr);const Jc=`<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">\r
  <path d="M12.5001 3C6.70106 3 2.00005 7.70101 2.00005 13.5C2.00005 14.7989 2.23632 16.044 2.66849 17.1938C2.79635 17.534 2.94135 17.8658 3.10245 18.1881L2.0527 22.1058C1.75384 23.2212 2.77447 24.2418 3.88982 23.943L7.80465 22.894C9.2185 23.6019 10.8141 24 12.5001 24C18.299 24 23.0001 19.299 23.0001 13.5C23.0001 7.70101 18.299 3 12.5001 3ZM5.04572 17.5882C4.37944 16.3761 4.00005 14.9839 4.00005 13.5C4.00005 8.80558 7.80563 5 12.5001 5C17.1945 5 21.0001 8.80558 21.0001 13.5C21.0001 18.1944 17.1945 22 12.5001 22C11.0137 22 9.61924 21.6193 8.4058 20.951C8.1796 20.8264 7.91397 20.7941 7.66452 20.861L4.2087 21.787L5.13533 18.3287C5.2021 18.0796 5.16999 17.8142 5.04572 17.5882ZM14.4549 25.3417C13.8187 25.446 13.1657 25.5002 12.5 25.5002C12.2132 25.5002 11.9287 25.4901 11.647 25.4703C13.5704 27.6358 16.3758 29.0002 19.5 29.0002C21.186 29.0002 22.7815 28.6021 24.1954 27.8941L28.1102 28.9431C29.2255 29.242 30.2462 28.2214 29.9473 27.106L28.8976 23.1883C29.0587 22.8659 29.2037 22.5341 29.3315 22.194C29.7637 21.0442 30 19.799 30 18.5002C30 14.1361 27.3376 10.3939 23.5485 8.80908C23.9114 9.6628 24.1783 10.5672 24.3355 11.5087C26.5498 13.0431 28 15.6023 28 18.5002C28 19.984 27.6206 21.3763 26.9543 22.5883C26.83 22.8144 26.7979 23.0797 26.8647 23.3289L27.7913 26.7871L24.3355 25.8611C24.086 25.7943 23.8204 25.8266 23.5942 25.9511C22.3808 26.6195 20.9863 27.0002 19.5 27.0002C17.611 27.0002 15.866 26.384 14.4549 25.3417ZM11.5 15C11.5 15.55 11.95 16 12.5 16C13.05 16 13.5 15.55 13.5 15C13.5 14.0992 14.0096 13.5217 14.6019 12.8505L14.62 12.83C15.27 12.09 16 11.21 16 10C16 8.79 15.07 7 12.5 7C9.93 7 9 8.79 9 10C9 10.55 9.45 11 10 11C10.55 11 11 10.55 11 10C11 9.83 11.07 9 12.5 9C13.82 9 13.99 9.71 14 10C14 10.48 13.68 10.86 13.12 11.5L13.1009 11.5217C12.3842 12.3378 11.5 13.3447 11.5 15ZM13.75 18.75C13.75 19.4404 13.1904 20 12.5 20C11.8096 20 11.25 19.4404 11.25 18.75C11.25 18.0596 11.8096 17.5 12.5 17.5C13.1904 17.5 13.75 18.0596 13.75 18.75Z" />\r
</svg>`;var ed=(n,e,t,s)=>{for(var r=e,i=n.length-1,a;i>=0;i--)(a=n[i])&&(r=a(r)||r);return r};let br=class extends Oe{render(n,e){const t=n.followupQuestions;return t&&t.length>0?$`
        <div class="items__listWrapper">
          ${rt(Jc)}
          <ul class="items__list followup">
            ${t.map(s=>$`
                <li class="items__listItem--followup">
                  <a
                    class="items__link"
                    href="#"
                    data-testid="followUpQuestion"
                    @click="${()=>e(s)}"
                    >${s}</a
                  >
                </li>
              `)}
          </ul>
        </div>
      `:""}};br=ed([Ie()],br);be.bind(ne.ChatEntryInlineInput).to(br);const td=`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">\r
  <path d="M15.4,4.9a8.3,8.3,0,0,1,0,6.2,9.009,9.009,0,0,1-1.7,2.6,9.009,9.009,0,0,1-2.6,1.7A8.112,8.112,0,0,1,8,16a7.509,7.509,0,0,1-2.6-.4,7.609,7.609,0,0,1-2.3-1.3,7.31,7.31,0,0,1-1.7-1.8L.7,11.4c-.1-.4-.3-.8-.4-1.3l1-.2a7.207,7.207,0,0,0,.9,2,8.716,8.716,0,0,0,1.6,1.7,6.9,6.9,0,0,0,1.9,1A6.184,6.184,0,0,0,8,15l1.9-.2,1.6-.8a4.9,4.9,0,0,0,1.4-1.1A4.9,4.9,0,0,0,14,11.5a7.976,7.976,0,0,0,.8-1.6A12.233,12.233,0,0,0,15,8a12.233,12.233,0,0,0-.2-1.9A7.976,7.976,0,0,0,14,4.5a4.9,4.9,0,0,0-1.1-1.4A4.9,4.9,0,0,0,11.5,2a4.61,4.61,0,0,0-1.6-.7A6.283,6.283,0,0,0,8,1a6.879,6.879,0,0,0-2,.3,5.292,5.292,0,0,0-1.7.8A4.708,4.708,0,0,0,2.8,3.4,4.6,4.6,0,0,0,1.7,5H4V6H0V2H1V4.1l.3-.4.3-.5A9.122,9.122,0,0,1,3.3,1.5,7.6,7.6,0,0,1,5.5.4,7.308,7.308,0,0,1,8,0a8.112,8.112,0,0,1,3.1.6,9.009,9.009,0,0,1,2.6,1.7A9.009,9.009,0,0,1,15.4,4.9Z" />\r
  <polygon points="8 3 8 7.3 10.9 10.1 10.1 10.9 7 7.7 7 3 8 3" />\r
</svg>`,nd=`<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">\r
  <path d="M4.75 12C4.75 15.743 7.58642 18.8235 11.2271 19.2093C11.4284 19.9498 11.7573 20.6378 12.1888 21.2481C12.126 21.2494 12.0631 21.25 12 21.25C6.89137 21.25 2.75 17.1086 2.75 12C2.75 11.6174 2.77322 11.2403 2.81834 10.8699C2.88069 10.3581 3.33398 10 3.8496 10C4.44068 10 4.86674 10.5685 4.79864 11.1556C4.76652 11.4326 4.75 11.7144 4.75 12ZM12.8096 13C13.5854 12.1915 14.5683 11.5832 15.6729 11.2603C15.4953 11.0986 15.2592 11 15 11H13V8C13 7.44772 12.5523 7 12 7C11.4477 7 11 7.44772 11 8V12C11 12.5523 11.4477 13 12 13H12.8096ZM21.2481 12.1888C20.6378 11.7573 19.9498 11.4284 19.2093 11.2271C18.8235 7.58642 15.743 4.75 12 4.75C10.3379 4.75 8.80642 5.30932 7.58352 6.25H8.25C8.80228 6.25 9.25 6.69772 9.25 7.25C9.25 7.80228 8.80228 8.25 8.25 8.25H5.25C4.69772 8.25 4.25 7.80228 4.25 7.25V7H4.21647L4.25 6.94829V4.25C4.25 3.69772 4.69772 3.25 5.25 3.25C5.80228 3.25 6.25 3.69772 6.25 4.25V4.75385C7.82875 3.49939 9.82686 2.75 12 2.75C17.1086 2.75 21.25 6.89137 21.25 12C21.25 12.0631 21.2494 12.126 21.2481 12.1888ZM23 17.5C23 20.5376 20.5376 23 17.5 23C14.4624 23 12 20.5376 12 17.5C12 14.4624 14.4624 12 17.5 12C20.5376 12 23 14.4624 23 17.5ZM15.8536 15.1464C15.6583 14.9512 15.3417 14.9512 15.1464 15.1464C14.9512 15.3417 14.9512 15.6583 15.1464 15.8536L16.7929 17.5L15.1464 19.1464C14.9512 19.3417 14.9512 19.6583 15.1464 19.8536C15.3417 20.0488 15.6583 20.0488 15.8536 19.8536L17.5 18.2071L19.1464 19.8536C19.3417 20.0488 19.6583 20.0488 19.8536 19.8536C20.0488 19.6583 20.0488 19.3417 19.8536 19.1464L18.2071 17.5L19.8536 15.8536C20.0488 15.6583 20.0488 15.3417 19.8536 15.1464C19.6583 14.9512 19.3417 14.9512 19.1464 15.1464L17.5 16.7929L15.8536 15.1464Z" />\r
</svg>`,Wi=`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">\r
  <polygon points="14.65 12.05 8.05 5.35 1.35 12.05 0.65 11.35 8.05 3.95 15.35 11.35 14.65 12.05" />\r
</svg>`;var Ya=(n,e,t,s)=>{for(var r=e,i=n.length-1,a;i>=0;i--)(a=n[i])&&(r=a(r)||r);return r};const xr="showChatHistory";let _r=class extends Oe{constructor(){super(),this.getShowChatHistory=this.getShowChatHistory.bind(this),this.setShowChatHistory=this.setShowChatHistory.bind(this)}getShowChatHistory(){return this.context.getState(xr)}setShowChatHistory(n){this.context.setState(xr,n)}render(n){if(this.context.interactionModel==="ask")return $``;const e=this.getShowChatHistory();return $`
      <chat-action-button
        .label="${e?W.HIDE_CHAT_HISTORY_LABEL:W.SHOW_CHAT_HISTORY_LABEL}"
        actionId="chat-history-button"
        @click="${()=>this.setShowChatHistory(!e)}"
        .isDisabled="${n}"
        .svgIcon="${e?nd:td}"
      >
      </chat-action-button>
    `}};_r=Ya([Ie()],_r);let gn=class extends Oe{constructor(){super(),this._chatHistory=[],this.getShowChatHistory=this.getShowChatHistory.bind(this)}getShowChatHistory(){return this.context.getState(xr)}hostConnected(){const n=localStorage.getItem(gn.CHATHISTORY_ID);if(n){const e=JSON.parse(decodeURIComponent(atob(n))),t=e.map((r,i)=>{if(r.isUserMessage)return i}).filter(r=>r!==void 0).slice(-_i),s=t.length===0?e:e.slice(t[0]);this._chatHistory=s}}save(n){const e=[...this._chatHistory,...n];localStorage.setItem(gn.CHATHISTORY_ID,btoa(encodeURIComponent(JSON.stringify(e))))}reset(){this._chatHistory=[]}merge(n){return[...this._chatHistory,...n]}render(n){return this.getShowChatHistory()?$`
      <div class="chat-history__container">
        ${n(this._chatHistory)}
        <div class="chat-history__footer">
          ${rt(Wi)}
          ${W.CHAT_HISTORY_FOOTER_TEXT.replace(W.CHAT_MAX_COUNT_TAG,_i)}
          ${rt(Wi)}
        </div>
      </div>
    `:$``}};gn.CHATHISTORY_ID="ms-azoaicc:history";gn=Ya([Ie()],gn);be.bind(ne.ChatAction).to(_r);be.bind(ne.ChatThread).to(gn);function sd(n,e){const t="Next questions:|<<([^>]+)>>",s=/\[(.*?)]/g,r=/:(.*?)(?:Follow-up questions:|Next questions:|<<|$)/s,i=/Next Questions:(.*?)$/s,a=/<<([^<>]+)>>/g,l=/^\d+\.\s/,c={};let h=[],u=1,g=n.replace(s,(R,D)=>{const se=D.trim();return c[se]||(c[se]=u++),`<sup class="citation">${c[se]}</sup>`});h=Object.keys(c).map((R,D)=>({ref:D+1,text:R})),e[0]=h;const p=g.includes(t),v=g.match(r),w=(v?v[1].trim():"").split(`
`).filter(Boolean).map(R=>R.replace(l,""));e[1]=w;const L=p?i:a,U=g.match(L)??[];let Q=[];Q=rd([...U]);const B=g.indexOf("s:");return g=B!==-1?n.substring(0,B+6):n,e[2]=Q,{replacedText:g,arrays:e}}function rd(n){return n&&n.length>0&&n[0].startsWith("<<")&&(n=n.map(e=>e.replace("<<","").replace(">>",""))),n}function id(){return new Date().toLocaleTimeString("en-US",{hour:"numeric",minute:"numeric",hour12:!0})}function Za(n){return n.text.map(e=>{var t;return e.value+`

`+((t=e.followingSteps)==null?void 0:t.map((s,r)=>`${r+1}.`+s).join(`
`))}).join(`

`).replaceAll(/<sup[^>]*>(.*?)<\/sup>/g,"")}class wr extends Error{constructor(e,t){super(e),this.code=t}}function Rn(n,e,t){return[...n.slice(0,e),t,...n.slice(e+1)]}const ad=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2048 2048">\r
  <path d="M1491 595l90 90-749 749-365-365 90-90 275 275 659-659zM1024 0q141 0 272 36t245 103 207 160 160 208 103 245 37 272q0 141-36 272t-103 245-160 207-208 160-245 103-272 37q-141 0-272-36t-245-103-207-160-160-208-103-244-37-273q0-141 36-272t103-245 160-207 208-160T751 37t273-37zm0 1920q123 0 237-32t214-90 182-141 140-181 91-214 32-238q0-123-32-237t-90-214-141-182-181-140-214-91-238-32q-123 0-237 32t-214 90-182 141-140 181-91 214-32 238q0 123 32 237t90 214 141 182 181 140 214 91 238 32z" />\r
</svg>`,od=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2048 2048">\r
  <path d="M1920 805v1243H640v-384H128V0h859l384 384h128l421 421zm-384-37h165l-165-165v165zM640 384h549L933 128H256v1408h384V384zm1152 512h-384V512H768v1408h1024V896z" />\r
</svg>`;var ld=(n,e,t,s)=>{for(var r=e,i=n.length-1,a;i>=0;i--)(a=n[i])&&(r=a(r)||r);return r};let Cr=class extends Oe{constructor(){super(...arguments),this._isResponseCopied=!1}set isResponseCopied(n){this._isResponseCopied=n,this.host.requestUpdate()}get isResponseCopied(){return this._isResponseCopied}copyResponseToClipboard(n){const e=Za(n);navigator.clipboard.writeText(e),this.isResponseCopied=!0}render(n,e){return $`
      <chat-action-button
        .label="${W.COPY_RESPONSE_BUTTON_LABEL_TEXT}"
        .svgIcon="${this.isResponseCopied?ad:od}"
        .isDisabled="${e}"
        actionId="copy-to-clipboard"
        .tooltip="${this.isResponseCopied?W.COPIED_SUCCESSFULLY_MESSAGE:W.COPY_RESPONSE_BUTTON_LABEL_TEXT}"
        @click="${()=>this.copyResponseToClipboard(n)}"
      ></chat-action-button>
    `}};Cr=ld([Ie()],Cr);be.bind(ne.ChatEntryAction).to(Cr);/*! @license DOMPurify 3.3.0 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.3.0/LICENSE */const{entries:Xa,setPrototypeOf:Gi,isFrozen:cd,getPrototypeOf:dd,getOwnPropertyDescriptor:hd}=Object;let{freeze:je,seal:Fe,create:kr}=Object,{apply:Sr,construct:Ar}=typeof Reflect<"u"&&Reflect;je||(je=function(n){return n});Fe||(Fe=function(n){return n});Sr||(Sr=function(n,e){for(var t=arguments.length,s=new Array(t>2?t-2:0),r=2;r<t;r++)s[r-2]=arguments[r];return n.apply(e,s)});Ar||(Ar=function(n){for(var e=arguments.length,t=new Array(e>1?e-1:0),s=1;s<e;s++)t[s-1]=arguments[s];return new n(...t)});const Jn=Ee(Array.prototype.forEach),ud=Ee(Array.prototype.lastIndexOf),Yi=Ee(Array.prototype.pop),Cn=Ee(Array.prototype.push),pd=Ee(Array.prototype.splice),ls=Ee(String.prototype.toLowerCase),Ws=Ee(String.prototype.toString),Gs=Ee(String.prototype.match),kn=Ee(String.prototype.replace),gd=Ee(String.prototype.indexOf),fd=Ee(String.prototype.trim),Qe=Ee(Object.prototype.hasOwnProperty),Te=Ee(RegExp.prototype.test),Sn=md(TypeError);function Ee(n){return function(e){e instanceof RegExp&&(e.lastIndex=0);for(var t=arguments.length,s=new Array(t>1?t-1:0),r=1;r<t;r++)s[r-1]=arguments[r];return Sr(n,e,s)}}function md(n){return function(){for(var e=arguments.length,t=new Array(e),s=0;s<e;s++)t[s]=arguments[s];return Ar(n,t)}}function V(n,e){let t=arguments.length>2&&arguments[2]!==void 0?arguments[2]:ls;Gi&&Gi(n,null);let s=e.length;for(;s--;){let r=e[s];if(typeof r=="string"){const i=t(r);i!==r&&(cd(e)||(e[s]=i),r=i)}n[r]=!0}return n}function yd(n){for(let e=0;e<n.length;e++)Qe(n,e)||(n[e]=null);return n}function ft(n){const e=kr(null);for(const[t,s]of Xa(n))Qe(n,t)&&(Array.isArray(s)?e[t]=yd(s):s&&typeof s=="object"&&s.constructor===Object?e[t]=ft(s):e[t]=s);return e}function An(n,e){for(;n!==null;){const s=hd(n,e);if(s){if(s.get)return Ee(s.get);if(typeof s.value=="function")return Ee(s.value)}n=dd(n)}function t(){return null}return t}const Zi=je(["a","abbr","acronym","address","area","article","aside","audio","b","bdi","bdo","big","blink","blockquote","body","br","button","canvas","caption","center","cite","code","col","colgroup","content","data","datalist","dd","decorator","del","details","dfn","dialog","dir","div","dl","dt","element","em","fieldset","figcaption","figure","font","footer","form","h1","h2","h3","h4","h5","h6","head","header","hgroup","hr","html","i","img","input","ins","kbd","label","legend","li","main","map","mark","marquee","menu","menuitem","meter","nav","nobr","ol","optgroup","option","output","p","picture","pre","progress","q","rp","rt","ruby","s","samp","search","section","select","shadow","slot","small","source","spacer","span","strike","strong","style","sub","summary","sup","table","tbody","td","template","textarea","tfoot","th","thead","time","tr","track","tt","u","ul","var","video","wbr"]),Ys=je(["svg","a","altglyph","altglyphdef","altglyphitem","animatecolor","animatemotion","animatetransform","circle","clippath","defs","desc","ellipse","enterkeyhint","exportparts","filter","font","g","glyph","glyphref","hkern","image","inputmode","line","lineargradient","marker","mask","metadata","mpath","part","path","pattern","polygon","polyline","radialgradient","rect","stop","style","switch","symbol","text","textpath","title","tref","tspan","view","vkern"]),Zs=je(["feBlend","feColorMatrix","feComponentTransfer","feComposite","feConvolveMatrix","feDiffuseLighting","feDisplacementMap","feDistantLight","feDropShadow","feFlood","feFuncA","feFuncB","feFuncG","feFuncR","feGaussianBlur","feImage","feMerge","feMergeNode","feMorphology","feOffset","fePointLight","feSpecularLighting","feSpotLight","feTile","feTurbulence"]),vd=je(["animate","color-profile","cursor","discard","font-face","font-face-format","font-face-name","font-face-src","font-face-uri","foreignobject","hatch","hatchpath","mesh","meshgradient","meshpatch","meshrow","missing-glyph","script","set","solidcolor","unknown","use"]),Xs=je(["math","menclose","merror","mfenced","mfrac","mglyph","mi","mlabeledtr","mmultiscripts","mn","mo","mover","mpadded","mphantom","mroot","mrow","ms","mspace","msqrt","mstyle","msub","msup","msubsup","mtable","mtd","mtext","mtr","munder","munderover","mprescripts"]),bd=je(["maction","maligngroup","malignmark","mlongdiv","mscarries","mscarry","msgroup","mstack","msline","msrow","semantics","annotation","annotation-xml","mprescripts","none"]),Xi=je(["#text"]),Qi=je(["accept","action","align","alt","autocapitalize","autocomplete","autopictureinpicture","autoplay","background","bgcolor","border","capture","cellpadding","cellspacing","checked","cite","class","clear","color","cols","colspan","controls","controlslist","coords","crossorigin","datetime","decoding","default","dir","disabled","disablepictureinpicture","disableremoteplayback","download","draggable","enctype","enterkeyhint","exportparts","face","for","headers","height","hidden","high","href","hreflang","id","inert","inputmode","integrity","ismap","kind","label","lang","list","loading","loop","low","max","maxlength","media","method","min","minlength","multiple","muted","name","nonce","noshade","novalidate","nowrap","open","optimum","part","pattern","placeholder","playsinline","popover","popovertarget","popovertargetaction","poster","preload","pubdate","radiogroup","readonly","rel","required","rev","reversed","role","rows","rowspan","spellcheck","scope","selected","shape","size","sizes","slot","span","srclang","start","src","srcset","step","style","summary","tabindex","title","translate","type","usemap","valign","value","width","wrap","xmlns","slot"]),Qs=je(["accent-height","accumulate","additive","alignment-baseline","amplitude","ascent","attributename","attributetype","azimuth","basefrequency","baseline-shift","begin","bias","by","class","clip","clippathunits","clip-path","clip-rule","color","color-interpolation","color-interpolation-filters","color-profile","color-rendering","cx","cy","d","dx","dy","diffuseconstant","direction","display","divisor","dur","edgemode","elevation","end","exponent","fill","fill-opacity","fill-rule","filter","filterunits","flood-color","flood-opacity","font-family","font-size","font-size-adjust","font-stretch","font-style","font-variant","font-weight","fx","fy","g1","g2","glyph-name","glyphref","gradientunits","gradienttransform","height","href","id","image-rendering","in","in2","intercept","k","k1","k2","k3","k4","kerning","keypoints","keysplines","keytimes","lang","lengthadjust","letter-spacing","kernelmatrix","kernelunitlength","lighting-color","local","marker-end","marker-mid","marker-start","markerheight","markerunits","markerwidth","maskcontentunits","maskunits","max","mask","mask-type","media","method","mode","min","name","numoctaves","offset","operator","opacity","order","orient","orientation","origin","overflow","paint-order","path","pathlength","patterncontentunits","patterntransform","patternunits","points","preservealpha","preserveaspectratio","primitiveunits","r","rx","ry","radius","refx","refy","repeatcount","repeatdur","restart","result","rotate","scale","seed","shape-rendering","slope","specularconstant","specularexponent","spreadmethod","startoffset","stddeviation","stitchtiles","stop-color","stop-opacity","stroke-dasharray","stroke-dashoffset","stroke-linecap","stroke-linejoin","stroke-miterlimit","stroke-opacity","stroke","stroke-width","style","surfacescale","systemlanguage","tabindex","tablevalues","targetx","targety","transform","transform-origin","text-anchor","text-decoration","text-rendering","textlength","type","u1","u2","unicode","values","viewbox","visibility","version","vert-adv-y","vert-origin-x","vert-origin-y","width","word-spacing","wrap","writing-mode","xchannelselector","ychannelselector","x","x1","x2","xmlns","y","y1","y2","z","zoomandpan"]),Ki=je(["accent","accentunder","align","bevelled","close","columnsalign","columnlines","columnspan","denomalign","depth","dir","display","displaystyle","encoding","fence","frame","height","href","id","largeop","length","linethickness","lspace","lquote","mathbackground","mathcolor","mathsize","mathvariant","maxsize","minsize","movablelimits","notation","numalign","open","rowalign","rowlines","rowspacing","rowspan","rspace","rquote","scriptlevel","scriptminsize","scriptsizemultiplier","selection","separator","separators","stretchy","subscriptshift","supscriptshift","symmetric","voffset","width","xmlns"]),es=je(["xlink:href","xml:id","xlink:title","xml:space","xmlns:xlink"]),xd=Fe(/\{\{[\w\W]*|[\w\W]*\}\}/gm),_d=Fe(/<%[\w\W]*|[\w\W]*%>/gm),wd=Fe(/\$\{[\w\W]*/gm),Cd=Fe(/^data-[\-\w.\u00B7-\uFFFF]+$/),kd=Fe(/^aria-[\-\w]+$/),Qa=Fe(/^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i),Sd=Fe(/^(?:\w+script|data):/i),Ad=Fe(/[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g),Ka=Fe(/^html$/i),Td=Fe(/^[a-z][.\w]*(-[.\w]+)+$/i);var Ji=Object.freeze({__proto__:null,ARIA_ATTR:kd,ATTR_WHITESPACE:Ad,CUSTOM_ELEMENT:Td,DATA_ATTR:Cd,DOCTYPE_NAME:Ka,ERB_EXPR:_d,IS_ALLOWED_URI:Qa,IS_SCRIPT_OR_DATA:Sd,MUSTACHE_EXPR:xd,TMPLIT_EXPR:wd});const Tn={element:1,text:3,progressingInstruction:7,comment:8,document:9},Nd=function(){return typeof window>"u"?null:window},jd=function(n,e){if(typeof n!="object"||typeof n.createPolicy!="function")return null;let t=null;const s="data-tt-policy-suffix";e&&e.hasAttribute(s)&&(t=e.getAttribute(s));const r="dompurify"+(t?"#"+t:"");try{return n.createPolicy(r,{createHTML(i){return i},createScriptURL(i){return i}})}catch{return console.warn("TrustedTypes policy "+r+" could not be created."),null}},ea=function(){return{afterSanitizeAttributes:[],afterSanitizeElements:[],afterSanitizeShadowDOM:[],beforeSanitizeAttributes:[],beforeSanitizeElements:[],beforeSanitizeShadowDOM:[],uponSanitizeAttribute:[],uponSanitizeElement:[],uponSanitizeShadowNode:[]}};function Ja(){let n=arguments.length>0&&arguments[0]!==void 0?arguments[0]:Nd();const e=d=>Ja(d);if(e.version="3.3.0",e.removed=[],!n||!n.document||n.document.nodeType!==Tn.document||!n.Element)return e.isSupported=!1,e;let{document:t}=n;const s=t,r=s.currentScript,{DocumentFragment:i,HTMLTemplateElement:a,Node:l,Element:c,NodeFilter:h,NamedNodeMap:u=n.NamedNodeMap||n.MozNamedAttrMap,HTMLFormElement:g,DOMParser:p,trustedTypes:v}=n,w=c.prototype,L=An(w,"cloneNode"),U=An(w,"remove"),Q=An(w,"nextSibling"),B=An(w,"childNodes"),R=An(w,"parentNode");if(typeof a=="function"){const d=t.createElement("template");d.content&&d.content.ownerDocument&&(t=d.content.ownerDocument)}let D,se="";const{implementation:re,createNodeIterator:ot,createDocumentFragment:Pe,getElementsByTagName:Ct}=t,{importNode:vn}=s;let me=ea();e.isSupported=typeof Xa=="function"&&typeof R=="function"&&re&&re.createHTMLDocument!==void 0;const{MUSTACHE_EXPR:Ot,ERB_EXPR:Pt,TMPLIT_EXPR:Lt,DATA_ATTR:Dt,ARIA_ATTR:Mt,IS_SCRIPT_OR_DATA:sn,ATTR_WHITESPACE:lt,CUSTOM_ELEMENT:rn}=Ji;let{IS_ALLOWED_URI:Bt}=Ji,ce=null;const Ht=V({},[...Zi,...Ys,...Zs,...Xs,...Xi]);let N=null;const qe=V({},[...Qi,...Qs,...Ki,...es]);let ie=Object.seal(kr(null,{tagNameCheck:{writable:!0,configurable:!1,enumerable:!0,value:null},attributeNameCheck:{writable:!0,configurable:!1,enumerable:!0,value:null},allowCustomizedBuiltInElements:{writable:!0,configurable:!1,enumerable:!0,value:!1}})),K=null,Ut=null;const Je=Object.seal(kr(null,{tagCheck:{writable:!0,configurable:!1,enumerable:!0,value:null},attributeCheck:{writable:!0,configurable:!1,enumerable:!0,value:null}}));let Be=!0,zt=!0,ke=!1,Ft=!0,Le=!1,ct=!0,De=!1,dt=!1,kt=!1,P=!1,M=!1,Se=!1,He=!0,St=!1;const et="user-content-";let bn=!0,qt=!1,At={},Ue=null;const zn=V({},["annotation-xml","audio","colgroup","desc","foreignobject","head","iframe","math","mi","mn","mo","ms","mtext","noembed","noframes","noscript","plaintext","script","style","svg","template","thead","title","video","xmp"]);let Fn=null;const qn=V({},["audio","video","img","source","image","track"]);let Vt=null;const f=V({},["alt","class","for","id","label","name","pattern","placeholder","role","summary","title","value","style","xmlns"]),m="http://www.w3.org/1998/Math/MathML",y="http://www.w3.org/2000/svg",x="http://www.w3.org/1999/xhtml";let I=x,ue=!1,de=null;const z=V({},[m,y,x],Ws);let k=V({},["mi","mo","mn","ms","mtext"]),A=V({},["annotation-xml"]);const E=V({},["title","style","font","a","script"]);let j=null;const q=["application/xhtml+xml","text/html"],J="text/html";let F=null,xe=null;const Vn=t.createElement("form"),Wn=function(d){return d instanceof RegExp||d instanceof Function},xn=function(){let d=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{};if(!(xe&&xe===d)){if((!d||typeof d!="object")&&(d={}),d=ft(d),j=q.indexOf(d.PARSER_MEDIA_TYPE)===-1?J:d.PARSER_MEDIA_TYPE,F=j==="application/xhtml+xml"?Ws:ls,ce=Qe(d,"ALLOWED_TAGS")?V({},d.ALLOWED_TAGS,F):Ht,N=Qe(d,"ALLOWED_ATTR")?V({},d.ALLOWED_ATTR,F):qe,de=Qe(d,"ALLOWED_NAMESPACES")?V({},d.ALLOWED_NAMESPACES,Ws):z,Vt=Qe(d,"ADD_URI_SAFE_ATTR")?V(ft(f),d.ADD_URI_SAFE_ATTR,F):f,Fn=Qe(d,"ADD_DATA_URI_TAGS")?V(ft(qn),d.ADD_DATA_URI_TAGS,F):qn,Ue=Qe(d,"FORBID_CONTENTS")?V({},d.FORBID_CONTENTS,F):zn,K=Qe(d,"FORBID_TAGS")?V({},d.FORBID_TAGS,F):ft({}),Ut=Qe(d,"FORBID_ATTR")?V({},d.FORBID_ATTR,F):ft({}),At=Qe(d,"USE_PROFILES")?d.USE_PROFILES:!1,Be=d.ALLOW_ARIA_ATTR!==!1,zt=d.ALLOW_DATA_ATTR!==!1,ke=d.ALLOW_UNKNOWN_PROTOCOLS||!1,Ft=d.ALLOW_SELF_CLOSE_IN_ATTR!==!1,Le=d.SAFE_FOR_TEMPLATES||!1,ct=d.SAFE_FOR_XML!==!1,De=d.WHOLE_DOCUMENT||!1,P=d.RETURN_DOM||!1,M=d.RETURN_DOM_FRAGMENT||!1,Se=d.RETURN_TRUSTED_TYPE||!1,kt=d.FORCE_BODY||!1,He=d.SANITIZE_DOM!==!1,St=d.SANITIZE_NAMED_PROPS||!1,bn=d.KEEP_CONTENT!==!1,qt=d.IN_PLACE||!1,Bt=d.ALLOWED_URI_REGEXP||Qa,I=d.NAMESPACE||x,k=d.MATHML_TEXT_INTEGRATION_POINTS||k,A=d.HTML_INTEGRATION_POINTS||A,ie=d.CUSTOM_ELEMENT_HANDLING||{},d.CUSTOM_ELEMENT_HANDLING&&Wn(d.CUSTOM_ELEMENT_HANDLING.tagNameCheck)&&(ie.tagNameCheck=d.CUSTOM_ELEMENT_HANDLING.tagNameCheck),d.CUSTOM_ELEMENT_HANDLING&&Wn(d.CUSTOM_ELEMENT_HANDLING.attributeNameCheck)&&(ie.attributeNameCheck=d.CUSTOM_ELEMENT_HANDLING.attributeNameCheck),d.CUSTOM_ELEMENT_HANDLING&&typeof d.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements=="boolean"&&(ie.allowCustomizedBuiltInElements=d.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements),Le&&(zt=!1),M&&(P=!0),At&&(ce=V({},Xi),N=[],At.html===!0&&(V(ce,Zi),V(N,Qi)),At.svg===!0&&(V(ce,Ys),V(N,Qs),V(N,es)),At.svgFilters===!0&&(V(ce,Zs),V(N,Qs),V(N,es)),At.mathMl===!0&&(V(ce,Xs),V(N,Ki),V(N,es))),d.ADD_TAGS&&(typeof d.ADD_TAGS=="function"?Je.tagCheck=d.ADD_TAGS:(ce===Ht&&(ce=ft(ce)),V(ce,d.ADD_TAGS,F))),d.ADD_ATTR&&(typeof d.ADD_ATTR=="function"?Je.attributeCheck=d.ADD_ATTR:(N===qe&&(N=ft(N)),V(N,d.ADD_ATTR,F))),d.ADD_URI_SAFE_ATTR&&V(Vt,d.ADD_URI_SAFE_ATTR,F),d.FORBID_CONTENTS&&(Ue===zn&&(Ue=ft(Ue)),V(Ue,d.FORBID_CONTENTS,F)),bn&&(ce["#text"]=!0),De&&V(ce,["html","head","body"]),ce.table&&(V(ce,["tbody"]),delete K.tbody),d.TRUSTED_TYPES_POLICY){if(typeof d.TRUSTED_TYPES_POLICY.createHTML!="function")throw Sn('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');if(typeof d.TRUSTED_TYPES_POLICY.createScriptURL!="function")throw Sn('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');D=d.TRUSTED_TYPES_POLICY,se=D.createHTML("")}else D===void 0&&(D=jd(v,r)),D!==null&&typeof se=="string"&&(se=D.createHTML(""));je&&je(d),xe=d}},Gr=V({},[...Ys,...Zs,...vd]),Yr=V({},[...Xs,...bd]),eo=function(d){let T=R(d);(!T||!T.tagName)&&(T={namespaceURI:I,tagName:"template"});const C=ls(d.tagName),Y=ls(T.tagName);return de[d.namespaceURI]?d.namespaceURI===y?T.namespaceURI===x?C==="svg":T.namespaceURI===m?C==="svg"&&(Y==="annotation-xml"||k[Y]):!!Gr[C]:d.namespaceURI===m?T.namespaceURI===x?C==="math":T.namespaceURI===y?C==="math"&&A[Y]:!!Yr[C]:d.namespaceURI===x?T.namespaceURI===y&&!A[Y]||T.namespaceURI===m&&!k[Y]?!1:!Yr[C]&&(E[C]||!Gr[C]):!!(j==="application/xhtml+xml"&&de[d.namespaceURI]):!1},Wt=function(d){Cn(e.removed,{element:d});try{R(d).removeChild(d)}catch{U(d)}},Gt=function(d,T){try{Cn(e.removed,{attribute:T.getAttributeNode(d),from:T})}catch{Cn(e.removed,{attribute:null,from:T})}if(T.removeAttribute(d),d==="is")if(P||M)try{Wt(T)}catch{}else try{T.setAttribute(d,"")}catch{}},Zr=function(d){let T=null,C=null;if(kt)d="<remove></remove>"+d;else{const he=Gs(d,/^[\r\n\t ]+/);C=he&&he[0]}j==="application/xhtml+xml"&&I===x&&(d='<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>'+d+"</body></html>");const Y=D?D.createHTML(d):d;if(I===x)try{T=new p().parseFromString(Y,j)}catch{}if(!T||!T.documentElement){T=re.createDocument(I,"template",null);try{T.documentElement.innerHTML=ue?se:Y}catch{}}const _e=T.body||T.documentElement;return d&&C&&_e.insertBefore(t.createTextNode(C),_e.childNodes[0]||null),I===x?Ct.call(T,De?"html":"body")[0]:De?T.documentElement:_e},Xr=function(d){return ot.call(d.ownerDocument||d,d,h.SHOW_ELEMENT|h.SHOW_COMMENT|h.SHOW_TEXT|h.SHOW_PROCESSING_INSTRUCTION|h.SHOW_CDATA_SECTION,null)},$s=function(d){return d instanceof g&&(typeof d.nodeName!="string"||typeof d.textContent!="string"||typeof d.removeChild!="function"||!(d.attributes instanceof u)||typeof d.removeAttribute!="function"||typeof d.setAttribute!="function"||typeof d.namespaceURI!="string"||typeof d.insertBefore!="function"||typeof d.hasChildNodes!="function")},Qr=function(d){return typeof l=="function"&&d instanceof l};function ht(d,T,C){Jn(d,Y=>{Y.call(e,T,C,xe)})}const Kr=function(d){let T=null;if(ht(me.beforeSanitizeElements,d,null),$s(d))return Wt(d),!0;const C=F(d.nodeName);if(ht(me.uponSanitizeElement,d,{tagName:C,allowedTags:ce}),ct&&d.hasChildNodes()&&!Qr(d.firstElementChild)&&Te(/<[/\w!]/g,d.innerHTML)&&Te(/<[/\w!]/g,d.textContent)||d.nodeType===Tn.progressingInstruction||ct&&d.nodeType===Tn.comment&&Te(/<[/\w]/g,d.data))return Wt(d),!0;if(!(Je.tagCheck instanceof Function&&Je.tagCheck(C))&&(!ce[C]||K[C])){if(!K[C]&&ei(C)&&(ie.tagNameCheck instanceof RegExp&&Te(ie.tagNameCheck,C)||ie.tagNameCheck instanceof Function&&ie.tagNameCheck(C)))return!1;if(bn&&!Ue[C]){const Y=R(d)||d.parentNode,_e=B(d)||d.childNodes;if(_e&&Y){const he=_e.length;for(let ut=he-1;ut>=0;--ut){const Ve=L(_e[ut],!0);Ve.__removalCount=(d.__removalCount||0)+1,Y.insertBefore(Ve,Q(d))}}}return Wt(d),!0}return d instanceof c&&!eo(d)||(C==="noscript"||C==="noembed"||C==="noframes")&&Te(/<\/no(script|embed|frames)/i,d.innerHTML)?(Wt(d),!0):(Le&&d.nodeType===Tn.text&&(T=d.textContent,Jn([Ot,Pt,Lt],Y=>{T=kn(T,Y," ")}),d.textContent!==T&&(Cn(e.removed,{element:d.cloneNode()}),d.textContent=T)),ht(me.afterSanitizeElements,d,null),!1)},Jr=function(d,T,C){if(He&&(T==="id"||T==="name")&&(C in t||C in Vn))return!1;if(!(zt&&!Ut[T]&&Te(Dt,T))&&!(Be&&Te(Mt,T))&&!(Je.attributeCheck instanceof Function&&Je.attributeCheck(T,d))){if(!N[T]||Ut[T]){if(!(ei(d)&&(ie.tagNameCheck instanceof RegExp&&Te(ie.tagNameCheck,d)||ie.tagNameCheck instanceof Function&&ie.tagNameCheck(d))&&(ie.attributeNameCheck instanceof RegExp&&Te(ie.attributeNameCheck,T)||ie.attributeNameCheck instanceof Function&&ie.attributeNameCheck(T,d))||T==="is"&&ie.allowCustomizedBuiltInElements&&(ie.tagNameCheck instanceof RegExp&&Te(ie.tagNameCheck,C)||ie.tagNameCheck instanceof Function&&ie.tagNameCheck(C))))return!1}else if(!Vt[T]&&!Te(Bt,kn(C,lt,""))&&!((T==="src"||T==="xlink:href"||T==="href")&&d!=="script"&&gd(C,"data:")===0&&Fn[d])&&!(ke&&!Te(sn,kn(C,lt,"")))&&C)return!1}return!0},ei=function(d){return d!=="annotation-xml"&&Gs(d,rn)},ti=function(d){ht(me.beforeSanitizeAttributes,d,null);const{attributes:T}=d;if(!T||$s(d))return;const C={attrName:"",attrValue:"",keepAttr:!0,allowedAttributes:N,forceKeepAttr:void 0};let Y=T.length;for(;Y--;){const _e=T[Y],{name:he,namespaceURI:ut,value:Ve}=_e,We=F(he),Rs=Ve;let we=he==="value"?Rs:fd(Rs);if(C.attrName=We,C.attrValue=we,C.keepAttr=!0,C.forceKeepAttr=void 0,ht(me.uponSanitizeAttribute,d,C),we=C.attrValue,St&&(We==="id"||We==="name")&&(Gt(he,d),we=et+we),ct&&Te(/((--!?|])>)|<\/(style|title|textarea)/i,we)){Gt(he,d);continue}if(We==="attributename"&&Gs(we,"href")){Gt(he,d);continue}if(C.forceKeepAttr)continue;if(!C.keepAttr){Gt(he,d);continue}if(!Ft&&Te(/\/>/i,we)){Gt(he,d);continue}Le&&Jn([Ot,Pt,Lt],no=>{we=kn(we,no," ")});const ni=F(d.nodeName);if(!Jr(ni,We,we)){Gt(he,d);continue}if(D&&typeof v=="object"&&typeof v.getAttributeType=="function"&&!ut)switch(v.getAttributeType(ni,We)){case"TrustedHTML":{we=D.createHTML(we);break}case"TrustedScriptURL":{we=D.createScriptURL(we);break}}if(we!==Rs)try{ut?d.setAttributeNS(ut,he,we):d.setAttribute(he,we),$s(d)?Wt(d):Yi(e.removed)}catch{Gt(he,d)}}ht(me.afterSanitizeAttributes,d,null)},to=function d(T){let C=null;const Y=Xr(T);for(ht(me.beforeSanitizeShadowDOM,T,null);C=Y.nextNode();)ht(me.uponSanitizeShadowNode,C,null),Kr(C),ti(C),C.content instanceof i&&d(C.content);ht(me.afterSanitizeShadowDOM,T,null)};return e.sanitize=function(d){let T=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},C=null,Y=null,_e=null,he=null;if(ue=!d,ue&&(d="<!-->"),typeof d!="string"&&!Qr(d))if(typeof d.toString=="function"){if(d=d.toString(),typeof d!="string")throw Sn("dirty is not a string, aborting")}else throw Sn("toString is not a function");if(!e.isSupported)return d;if(dt||xn(T),e.removed=[],typeof d=="string"&&(qt=!1),qt){if(d.nodeName){const We=F(d.nodeName);if(!ce[We]||K[We])throw Sn("root node is forbidden and cannot be sanitized in-place")}}else if(d instanceof l)C=Zr("<!---->"),Y=C.ownerDocument.importNode(d,!0),Y.nodeType===Tn.element&&Y.nodeName==="BODY"||Y.nodeName==="HTML"?C=Y:C.appendChild(Y);else{if(!P&&!Le&&!De&&d.indexOf("<")===-1)return D&&Se?D.createHTML(d):d;if(C=Zr(d),!C)return P?null:Se?se:""}C&&kt&&Wt(C.firstChild);const ut=Xr(qt?d:C);for(;_e=ut.nextNode();)Kr(_e),ti(_e),_e.content instanceof i&&to(_e.content);if(qt)return d;if(P){if(M)for(he=Pe.call(C.ownerDocument);C.firstChild;)he.appendChild(C.firstChild);else he=C;return(N.shadowroot||N.shadowrootmode)&&(he=vn.call(s,he,!0)),he}let Ve=De?C.outerHTML:C.innerHTML;return De&&ce["!doctype"]&&C.ownerDocument&&C.ownerDocument.doctype&&C.ownerDocument.doctype.name&&Te(Ka,C.ownerDocument.doctype.name)&&(Ve="<!DOCTYPE "+C.ownerDocument.doctype.name+`>
`+Ve),Le&&Jn([Ot,Pt,Lt],We=>{Ve=kn(Ve,We," ")}),D&&Se?D.createHTML(Ve):Ve},e.setConfig=function(){let d=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{};xn(d),dt=!0},e.clearConfig=function(){xe=null,dt=!1},e.isValidAttribute=function(d,T,C){xe||xn({});const Y=F(d),_e=F(T);return Jr(Y,_e,C)},e.addHook=function(d,T){typeof T=="function"&&Cn(me[d],T)},e.removeHook=function(d,T){if(T!==void 0){const C=ud(me[d],T);return C===-1?void 0:pd(me[d],C,1)[0]}return Yi(me[d])},e.removeHooks=function(d){me[d]=[]},e.removeAllHooks=function(){me=ea()},e}var ta=Ja();const Ed=it`
  :host {
    --c-primary: #123f58;
    --c-secondary: #f5f5f5;
    --c-text: var(--c-primary);
    --c-white: #fff;
    --c-black: #111111;
    --c-red: #ff0000;
    --c-light-gray: #e3e3e3;
    --c-base-gray: var(--c-secondary);
    --c-dark-gray: #4e5288;
    --c-accent-high: #692b61;
    --c-accent-dark: #5e3c7d;
    --c-accent-light: #f6d5f2;
    --c-error: #8a0000;
    --c-error-background: rgb(253, 231, 233);
    --c-success: #26b32b;
    --font-r-small: 1vw;
    --font-r-base: 3vw;
    --font-r-large: 5vw;
    --font-base: 14px;
    --font-rel-base: 1.2rem;
    --font-small: small;
    --font-large: large;
    --font-larger: x-large;
    --border-base: 3px;
    --border-thin: 1px;
    --border-thicker: 8px;
    --radius-small: 5px;
    --radius-base: 10px;
    --radius-large: 25px;
    --radius-none: 0;
    --width-wide: 90%;
    --width-base: 80%;
    --width-narrow: 50%;
    --d-base: 20px;
    --d-small: 10px;
    --d-xsmall: 5px;
    --d-large: 30px;
    --d-xlarge: 50px;
    --shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    width: 100vw;
    display: block;
    padding: var(--d-base);
    color: var(--c-text);
  }
  :host([data-theme='dark']) {
    --c-primary: #fdfeff;
    --c-secondary: #32343e;
    --c-text: var(--c-primary);
    --c-white: var(--c-secondary);
    --c-black: var(--c-primary);
    --c-red: #ff0000;
    --c-light-gray: #636d9c;
    --c-dark-gray: #e3e3e3;
    --c-base-gray: var(--c-secondary);
    --c-accent-high: #dcdef8;
    --c-accent-dark: var(--c-primary);
    --c-accent-light: #032219;
    --c-error: #8a0000;
    --c-error-background: rgb(253, 231, 233);
    --c-success: #26b32b;
  }
  html {
    scroll-behavior: smooth;
  }
  ul {
    margin-block-start: 0;
    margin-block-end: 0;
  }
  .button {
    color: var(--c-text);
    border: 0;
    background: none;
    cursor: pointer;
    text-decoration: underline;
  }
  .overlay {
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    display: flex;
    width: 100%;
    height: 0;
    background: var(--c-black);
    z-index: 2;
    opacity: 0.8;
    transition: all 0.3s ease-in-out;
  }
  .overlay.active {
    @media (max-width: 1024px) {
      height: 100%;
    }
  }
  .display-none {
    display: none;
    visibility: hidden;
  }
  .display-flex-grow {
    flex-grow: 1;
  }
  .container-col {
    display: flex;
    flex-direction: column;
    gap: var(--d-small);
  }
  .container-row {
    flex-direction: row;
  }
  .chat__header--thread {
    display: flex;
    align-items: center;
    justify-content: flex-end;
  }
  .chat__container {
    min-width: 100%;
    transition: width 0.3s ease-in-out;
    max-height: 100vh;
  }
  .chat__containerWrapper.aside-open {
    .chat__listItem {
      max-width: var(--width-wide);
    }
  }
  .chat__containerWrapper {
    display: grid;
    grid-template-columns: 1fr;
    gutter: var(--d-base);
  }
  .chat__containerWrapper.aside-open {
    display: grid;
    grid-template-columns: 1fr;
    grid-column-gap: var(--d-base);
    grid-row-gap: var(--d-base);

    @media (min-width: 1024px) {
      grid-template-columns: 1fr 1fr;
    }
  }
  .chat__containerWrapper.aside-open .aside {
    width: 100%;
    border-left: var(--border-thin) solid var(--c-light-gray);

    @media (max-width: 1024px) {
      width: var(--width-base);
    }
  }
  @media (max-width: 1024px) {
    .aside {
      top: var(-d-large);
      left: auto;
      z-index: 3;
      background: var(--c-white);
      display: block;
      padding: var(--d-base);
      position: absolute;
      width: var(--width-base);
      border-radius: var(--radius-base);
    }
  }
  .form__container {
    margin-top: var(--d-large);
    padding: var(--d-small);
  }
  .form__container-sticky {
    position: sticky;
    bottom: 0;
    z-index: 1;
    border-radius: var(--radius-base);
    background: linear-gradient(0deg, var(--c-base-gray) 0%, var(--c-base-gray) 75%, var(--c-base-gray) 100%);
    box-shadow: var(--shadow);
    padding: var(--d-small) var(--d-small) var(--d-large);
  }
  .form__label {
    display: block;
    padding: var(-d-xsmall) 0;
    font-size: var(--font-small);
  }
  .chatbox__button:disabled,
  .chatbox__input:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
  .chatbox__button svg {
    fill: var(--c-accent-high);
    width: calc(var(--d-base) + var(--d-xsmall));
  }
  .chatbox__container {
    position: relative;
    height: 50px;
  }
  .chatbox__button {
    background: var(--c-white);
    border: none;
    color: var(--text-color);
    font-weight: bold;
    cursor: pointer;
    border-radius: 4px;
    margin-left: 8px;
    width: calc(var(--d-large) + var(--d-xlarge));
    box-shadow: var(--shadow);
    transition: background 0.3s ease-in-out;
  }
  .chatbox__button:hover,
  .chatbox__button:focus {
    background: var(--c-secondary);
  }
  .chatbox__button:hover svg,
  .chatbox__button:focus svg {
    opacity: 0.8;
  }
  .chatbox__button--reset {
    position: absolute;
    right: 115px;
    top: 15px;
    background: transparent;
    border: none;
    color: gray;
    background: var(--c-accent-dark);
    border-radius: 50%;
    color: var(--c-white);
    font-weight: bold;
    height: 20px;
    width: var(--d-base);
    cursor: pointer;
  }
  .chatbox__input-container {
    display: flex;
    border: var(--border-thin) solid var(--c-black);
    background: var(--c-white);
    border-radius: 4px;
  }
  .chatbox__input-container:focus-within {
    outline: -webkit-focus-ring-color auto 1px;
  }
  .chatbox__input {
    background: transparent;
    color: var(--text-color);
    border: none;
    padding: var(--d-small);
    flex: 1 1 auto;
    font-size: 1rem;
  }
  .chatbox__input:focus-visible {
    outline: none;
  }
  .aside__header {
    display: flex;
    justify-content: end;
  }
  .tab-component__content {
    padding: var(--d-base) var(--d-base) var(--d-base) 0;
  }
  .tab-component__paragraph {
    font-family: monospace;
    font-size: var(--font-large);
    border: var(--border-thin) solid var(--c-light-gray);
    border-radius: var(--radius-large);
    padding: var(--d-base);
  }
  .chat-history__footer {
    display: flex;
    flex-direction: row;
    gap: 10px;
    justify-content: space-between;
    align-self: center;
    padding: 20px;
  }
  .chat-history__container {
    display: flex;
    flex-direction: column;
    border-bottom: 3px solid var(--light-gray);
    margin-bottom: 30px;
  }
`,Id=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2048 2048">\r
  <path d="M1792 384h-128v1472q0 40-15 75t-41 61-61 41-75 15H448q-40 0-75-15t-61-41-41-61-15-75V384H128V256h512V128q0-27 10-50t27-40 41-28 50-10h384q27 0 50 10t40 27 28 41 10 50v128h512v128zM768 256h384V128H768v128zm768 128H384v1472q0 26 19 45t45 19h1024q26 0 45-19t19-45V384zM768 1664H640V640h128v1024zm256 0H896V640h128v1024zm256 0h-128V640h128v1024z" />\r
</svg>`,$d=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2048 2048">\r
  <path d="M512 768h1024v128H512V768zm1024-256H512V384h1024v128zm-384 1408l127 128H256V0h1536v1348l-64 63-64-64V128H384v1792h768zm576 125l3 3h-6l3-3zm-192-893l-129 128H512v-128h1024zm-317 384l128 128H512v-128h707zm600 192l226 227-90 90-227-226-227 227-90-91 227-227-227-227 90-90 227 227 227-227 90 91-226 226z" />\r
</svg>`,Rd=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2048 2048">\r
  <path d="M221 1027h931l128-64-128-64H223L18 77l1979 883L18 1843l203-816z" />\r
</svg>`,na=`<?xml version="1.0" encoding="UTF-8" standalone="no"?>\r
<svg\r
   xmlns:dc="http://purl.org/dc/elements/1.1/"\r
   xmlns:cc="http://creativecommons.org/ns#"\r
   xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"\r
   xmlns:svg="http://www.w3.org/2000/svg"\r
   xmlns="http://www.w3.org/2000/svg"\r
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"\r
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"\r
   width="533.37976"\r
   height="479.4425"\r
   viewBox="0 0 141.12339 126.8525"\r
   version="1.1"\r
   id="svg8"\r
   inkscape:version="1.0.1 (c497b03c, 2020-09-10)"\r
   sodipodi:docname="brand-logo.svg">\r
  <defs\r
     id="defs2" />\r
  <sodipodi:namedview\r
     id="base"\r
     pagecolor="#ffffff"\r
     bordercolor="#666666"\r
     borderopacity="1.0"\r
     inkscape:pageopacity="0.0"\r
     inkscape:pageshadow="2"\r
     inkscape:zoom="0.4654497"\r
     inkscape:cx="303.64057"\r
     inkscape:cy="106.60712"\r
     inkscape:document-units="mm"\r
     inkscape:current-layer="layer1"\r
     inkscape:document-rotation="0"\r
     showgrid="false"\r
     inkscape:window-width="1187"\r
     inkscape:window-height="541"\r
     inkscape:window-x="119"\r
     inkscape:window-y="131"\r
     inkscape:window-maximized="0"\r
     units="px"\r
     fit-margin-top="0"\r
     fit-margin-left="0"\r
     fit-margin-right="0"\r
     fit-margin-bottom="0" />\r
  <metadata\r
     id="metadata5">\r
    <rdf:RDF>\r
      <cc:Work\r
         rdf:about="">\r
        <dc:format>image/svg+xml</dc:format>\r
        <dc:type\r
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />\r
        <dc:title></dc:title>\r
      </cc:Work>\r
    </rdf:RDF>\r
  </metadata>\r
  <g\r
     inkscape:label="Layer 1"\r
     inkscape:groupmode="layer"\r
     id="layer1"\r
     transform="translate(-18.235046,-25.370501)">\r
    <text\r
       xml:space="preserve"\r
       style="font-style:normal;font-weight:normal;font-size:18.7575px;line-height:1.25;font-family:sans-serif;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.468938"\r
       x="76.622147"\r
       y="77.940918"\r
       id="text837"\r
       transform="scale(0.95147583,1.0509988)"><tspan\r
         sodipodi:role="line"\r
         id="tspan835"\r
         x="76.622147"\r
         y="77.940918"\r
         style="stroke-width:0.468938">YOUR</tspan><tspan\r
         sodipodi:role="line"\r
         x="76.622147"\r
         y="101.38779"\r
         style="stroke-width:0.468938"\r
         id="tspan885">BRAND</tspan></text>\r
    <path\r
       sodipodi:type="star"\r
       style="opacity:0.99;fill:#eec4e6;fill-opacity:0.835294;fill-rule:evenodd;stroke-width:4.99999;stroke-linejoin:round"\r
       id="path887"\r
       sodipodi:sides="5"\r
       sodipodi:cx="55.752526"\r
       sodipodi:cy="87.899637"\r
       sodipodi:r1="26.130005"\r
       sodipodi:r2="13.065002"\r
       sodipodi:arg1="0.77001476"\r
       sodipodi:arg2="1.3983333"\r
       inkscape:flatsided="false"\r
       inkscape:rounded="0"\r
       inkscape:randomized="0"\r
       d="M 74.511266,106.08993 57.994602,100.77082 44.249297,111.36137 44.204142,94.009392 29.884399,84.209489 46.373155,78.804488 51.268372,62.157267 61.504139,76.168769 78.849293,75.680123 68.686589,89.744708 Z"\r
       inkscape:transform-center-x="1.3856798"\r
       inkscape:transform-center-y="-1.1403183" />\r
  </g>\r
</svg>\r
`;async function Od({question:n,type:e,approach:t,overrides:s,messages:r},{method:i,url:a,stream:l,signal:c,chatId:h,personalityId:u}){var g;if(e==="chat"&&(h!==void 0||u!==void 0)){const p=h?typeof h=="string"?Number.parseInt(h,10):h:null,v=u?typeof u=="string"?Number.parseInt(u,10):u:null,w=n||((g=r==null?void 0:r[r.length-1])==null?void 0:g.content)||"",L=a.replace(/\/$/,""),U=L.endsWith("/api/chat")?L:`${L}/api/chat`;return await fetch(U,{method:i,headers:{"Content-Type":"application/json"},credentials:"include",signal:c,body:JSON.stringify({input:w,chatId:p,personalityId:v,context:{...s,approach:t},stream:l})})}return await fetch(`${a}/${e}`,{method:i,headers:{"Content-Type":"application/json"},credentials:"include",signal:c,body:JSON.stringify({messages:[...r??[],{content:n,role:"user"}],context:{...s,approach:t},stream:e==="chat"?l:!1})})}async function Pd(n,e){const t=await Od(n,e);if(n.type!=="ask"&&e.stream)return t;const s=await t.json();if(t.status>299||!t.ok)throw new wr(t.statusText,t.status)||"API Response Error";return s}class Ld extends TransformStream{constructor(){let e;super({start:t=>{e=t},transform:t=>{const s=t.split(`
`).filter(Boolean);for(const r of s)try{this.buffer+=r,e.enqueue(JSON.parse(this.buffer)),this.buffer=""}catch{}}}),this.buffer=""}}function Dd(n){return n==null?void 0:n.pipeThrough(new TextDecoderStream).pipeThrough(new Ld).getReader()}async function*Md(n){if(!n)throw new Error("No response body or body is not readable");let e,t;for(;{value:e,done:t}=await n.read(),!t;)yield new Promise(s=>{setTimeout(()=>{s(e)},W.BOT_TYPING_EFFECT_INTERVAL)})}async function Bd({chatEntry:n,apiResponseBody:e,signal:t,onChunkRead:s,onCancel:r}){var i,a;const l=Dd(e),c=Md(l),h=[],u=[],g=[];let p=!1,v=!1,w=!1,L=0,U=0,Q=0,B={...n};for await(const R of c){if(t.aborted){r();return}if(R.chatId&&R.done){window.dispatchEvent(new CustomEvent("chat-created",{detail:{chatId:R.chatId}}));continue}if(R.error)throw new wr(R.message,R.statusCode);if(R.choices[0].finish_reason==="content_filter")throw new wr("Content filtered",400);const{content:D,context:se}=R.choices[0].delta;if(se!=null&&se.data_points){B.dataPoints=((i=se.data_points)==null?void 0:i.text)??[],B.thoughts=se.thoughts??"";continue}let re=D??"";if(re==="")continue;h.push(re);const ot=/(\d+)/;let Pe=(a=re.match(ot))==null?void 0:a[0];if(Pe){u.push(Pe);continue}if(!w&&re.includes("Next")||re.includes("<<")){w=!0,g.push(re);continue}else if(g.length>0&&re.includes("Question")){w=!0,g.push(re);continue}else if(re.includes("<<")&&w){w=!0;continue}else if(re.includes(`>
`)){L=L+1,w=!0;continue}else w&&(w=!0,re=re.replace(/:?\n/,"").replaceAll(">",""));u.length>0&&re.includes(".")?(p=!0,Pe=u[0],u.length=0):re.includes(`

`)&&p&&(v=!0),Pe||p||w?(Pe&&(re=""),U=Pe?Number(Pe)-1:U,B=Fd({chunkValue:re,textBlockIndex:Q,stepIndex:U,isFollowupQuestion:w,followUpQuestionIndex:L,chatEntry:B}),v&&(p=!1,v=!1,w=!1,U=0,Q++)):B=zd({chunkValue:re,textBlockIndex:Q,chatEntry:B});const Ct=Ud(h.join(""));B=Hd({citations:Ct,chatEntry:B}),s(B)}}function Hd({citations:n,chatEntry:e}){const t=e,s=(i,a)=>{const l=n.find(c=>c.text===a);return l?`<sup class="citation">${l.ref}</sup>`:i},r=t.text.map(i=>{var a;const l=i.value.replaceAll(/\[(.*?)]/g,s),c=(a=i.followingSteps)==null?void 0:a.map(h=>h.replaceAll(/\[(.*?)]/g,s));return{value:l,followingSteps:c}});return{...t,text:r,citations:n}}function Ud(n){const e=/\[(.*?)]/g,t={};let s=1;return n.replaceAll(e,(r,i)=>{const a=i.trim();return t[a]||(t[a]=s++),""}),Object.keys(t).map((r,i)=>({ref:i+1,text:r}))}function zd({chunkValue:n,textBlockIndex:e,chatEntry:t}){const{text:s}=t,r=s[e]??{value:"",followingSteps:[]},i=(r.value||"")+n;return{...t,text:Rn(s,e,{...r,value:i})}}function Fd({chunkValue:n,textBlockIndex:e,stepIndex:t,isFollowupQuestion:s,followUpQuestionIndex:r,chatEntry:i}){const{followupQuestions:a,text:l}=i;if(s&&a){const c=(a[r]||"")+n;return{...i,followupQuestions:Rn(a,r,c)}}if(l&&l[e]){const{followingSteps:c}=l[e];if(c){const h=(c[t]||"")+n;return{...i,text:Rn(l,e,{...l[e],followingSteps:Rn(c,t,h)})}}}return i}class qd{constructor(e){this._generatingAnswer=!1,this._isAwaitingResponse=!1,this._isProcessingResponse=!1,this._processingMessage=void 0,this._abortController=new AbortController,(this.host=e).addController(this)}get isAwaitingResponse(){return this._isAwaitingResponse}get isProcessingResponse(){return this._isProcessingResponse}get processingMessage(){return this._processingMessage}get generatingAnswer(){return this._generatingAnswer}set generatingAnswer(e){this._generatingAnswer=e,this.host.requestUpdate()}set processingMessage(e){this._processingMessage=e?{...e}:void 0,this.host.requestUpdate()}set isAwaitingResponse(e){this._isAwaitingResponse=e,this.host.requestUpdate()}set isProcessingResponse(e){this._isProcessingResponse=e,this.host.requestUpdate()}hostConnected(){}hostDisconnected(){}clear(){this._isAwaitingResponse=!1,this._isProcessingResponse=!1,this._generatingAnswer=!1,this.host.requestUpdate()}reset(){this._processingMessage=void 0,this.clear()}async processResponse(e,t=!1,s=!1){var r,i,a;const l=[],c=[],h=[],u=id();let g,p;const v=async(w,L)=>{this.processingMessage={id:crypto.randomUUID(),text:[{value:L?"":w,followingSteps:c}],followupQuestions:h,citations:[...new Set(l)],timestamp:u,isUserMessage:t,thoughts:g,dataPoints:p},L&&this.processingMessage&&(this.isProcessingResponse=!0,this._abortController=new AbortController,await Bd({chatEntry:this.processingMessage,signal:this._abortController.signal,apiResponseBody:w.body,onChunkRead:U=>{this.processingMessage=U},onCancel:()=>{this.clear()}}),this.clear())};if(t||typeof e=="string")await v(e,!1);else if(s)await v(e,!0);else{const w=e.choices[0].message,L=sd(w.content,[l,c,h]),U=L.replacedText;l.push(...L.arrays[0]),c.push(...L.arrays[1]),h.push(...L.arrays[2]),g=((r=w.context)==null?void 0:r.thoughts)??"",p=((a=(i=w.context)==null?void 0:i.data_points)==null?void 0:a.text)??[],await v(U,!1)}}async generateAnswer(e,t){const{question:s}=e;if(s)try{this.generatingAnswer=!0,e.type==="chat"&&await this.processResponse(s,!0,!1),this.isAwaitingResponse=!0,this.processingMessage=void 0;const r=await Pd(e,t);this.isAwaitingResponse=!1,await this.processResponse(r,!1,t.stream)}catch(r){const i=r,a={message:(i==null?void 0:i.code)===400?W.INVALID_REQUEST_ERROR:W.API_ERROR_MESSAGE};this.processingMessage||await this.processResponse("",!1,!1),this.processingMessage&&(this.processingMessage={...this.processingMessage,error:a})}finally{this.clear()}}cancelRequest(){this._abortController.abort()}}var Vd=Object.defineProperty,Wd=Object.getOwnPropertyDescriptor,ve=(n,e,t,s)=>{for(var r=s>1?void 0:s?Wd(e,t):e,i=n.length-1,a;i>=0;i--)(a=n[i])&&(r=(s?a(e,t,r):a(r))||r);return s&&r&&Vd(e,t,r),r};let pe=class extends Ne{constructor(){super(),this.inputPosition="sticky",this.isCustomBranding=W.IS_CUSTOM_BRANDING,this.useStream=or.stream,this.approach=Us.approach,this.overrides={},this.customStyles={},this.chatId=void 0,this.personalityId=void 0,this.currentQuestion="",this.isDisabled=!1,this.isResetInput=!1,this.chatController=new qd(this),this.chatContext=new Cc(this),this.chatThread=[],this.setQuestionInputValue=this.setQuestionInputValue.bind(this),this.renderChatThread=this.renderChatThread.bind(this)}set interactionModel(n){this.chatContext.interactionModel=n||"chat"}get interactionModel(){return this.chatContext.interactionModel}set apiUrl(n){this.chatContext.apiUrl=n}get apiUrl(){return this.chatContext.apiUrl}set isChatStarted(n){this.chatContext.isChatStarted=n}get isChatStarted(){return this.chatContext.isChatStarted}connectedCallback(){if(super.connectedCallback(),this.chatInputComponents)for(const n of this.chatInputComponents)n.attach(this,this.chatContext);if(this.chatInputFooterComponets)for(const n of this.chatInputFooterComponets)n.attach(this,this.chatContext);if(this.chatSectionControllers)for(const n of this.chatSectionControllers)n.attach(this,this.chatContext);if(this.chatActionControllers)for(const n of this.chatActionControllers)n.attach(this,this.chatContext);if(this.chatThreadControllers)for(const n of this.chatThreadControllers)n.attach(this,this.chatContext)}updated(n){super.updated(n),n.has("customStyles")&&(this.style.setProperty("--c-accent-high",this.customStyles.AccentHigh),this.style.setProperty("--c-accent-lighter",this.customStyles.AccentLight),this.style.setProperty("--c-accent-dark",this.customStyles.AccentDark),this.style.setProperty("--c-text-color",this.customStyles.TextColor),this.style.setProperty("--c-light-gray",this.customStyles.BackgroundColor),this.style.setProperty("--c-dark-gray",this.customStyles.ForegroundColor),this.style.setProperty("--c-base-gray",this.customStyles.FormBackgroundColor),this.style.setProperty("--radius-base",this.customStyles.BorderRadius),this.style.setProperty("--border-base",this.customStyles.BorderWidth),this.style.setProperty("--font-base",this.customStyles.FontBaseSize))}setQuestionInputValue(n){this.questionInput.value=ta.sanitize(n||""),this.currentQuestion=this.questionInput.value}handleInput(n){var e;n==null||n.preventDefault(),this.setQuestionInputValue((e=n==null?void 0:n.detail)==null?void 0:e.value)}handleCitationClick(n){var e,t;n==null||n.preventDefault();const s=(e=n==null?void 0:n.detail)==null?void 0:e.citation,r=(t=n==null?void 0:n.detail)==null?void 0:t.chatThreadEntry;s&&(this.chatContext.selectedCitation=s),r&&(this.chatContext.selectedChatEntry=r),this.chatContext.setState("showCitations",!0)}getMessageContext(){if(this.interactionModel==="ask")return[];let n=[...this.chatThread];if(this.chatThreadControllers)for(const e of this.chatThreadControllers)n=e.merge(n);return n.map(e=>({content:Za(e),role:e.isUserMessage?"user":"assistant"}))}async handleUserChatSubmit(n){n.preventDefault(),this.collapseAside(n);const e=ta.sanitize(this.questionInput.value);this.isChatStarted=!0,await this.chatController.generateAnswer({...Us,approach:this.approach,overrides:{...Us.overrides,...this.overrides},question:e,type:this.interactionModel,messages:this.getMessageContext()},{...or,url:this.apiUrl,stream:this.useStream,chatId:this.chatId,personalityId:this.personalityId}),this.interactionModel==="chat"&&this.saveChatThreads(this.chatThread),this.questionInput.value="",this.isResetInput=!1}resetInputField(n){n.preventDefault(),this.questionInput.value="",this.currentQuestion="",this.isResetInput=!1}saveChatThreads(n){if(this.chatThreadControllers)for(const e of this.chatThreadControllers)e.save(n)}loadMessages(n){this.chatThread=n.map(e=>{const t=new Date().toISOString();return{id:crypto.randomUUID(),text:[{value:e.content,followingSteps:[]}],citations:e.citations||[],followupQuestions:[],isUserMessage:e.role==="user",timestamp:t,thoughts:void 0,dataPoints:void 0}}),this.isChatStarted=this.chatThread.length>0,this.requestUpdate()}resetCurrentChat(n){this.isChatStarted=!1,this.chatThread=[],this.isDisabled=!1,this.chatContext.selectedCitation=void 0,this.chatController.reset(),this.saveChatThreads(this.chatThread),this.collapseAside(n),this.handleUserChatCancel(n)}handleOnInputChange(){this.isResetInput=!!this.questionInput.value}handleUserChatCancel(n){n==null||n.preventDefault(),this.chatController.cancelRequest()}collapseAside(n){if(n==null||n.preventDefault(),this.chatSectionControllers)for(const e of this.chatSectionControllers)e.close()}renderChatOrCancelButton(){const n=$`<button
      class="chatbox__button"
      data-testid="submit-question-button"
      @click="${this.handleUserChatSubmit}"
      title="${W.CHAT_BUTTON_LABEL_TEXT}"
      ?disabled="${this.isDisabled}"
    >
      ${rt(Rd)}
    </button>`,e=$`<button
      class="chatbox__button"
      data-testid="cancel-question-button"
      @click="${this.handleUserChatCancel}"
      title="${W.CHAT_CANCEL_BUTTON_LABEL_TEXT}"
    >
      ${rt($d)}
    </button>`;return this.chatController.isProcessingResponse?e:n}willUpdate(){if(this.isDisabled=this.chatController.generatingAnswer,this.chatController.processingMessage){const n=this.chatController.processingMessage,e=this.chatThread.findIndex(t=>t.id===n.id);this.chatThread=e>-1?Rn(this.chatThread,e,n):[...this.chatThread,n]}}renderChatThread(n){return $`<chat-thread-component
      .chatThread="${n}"
      .isDisabled="${this.isDisabled}"
      .isProcessingResponse="${this.chatController.isProcessingResponse}"
      .selectedCitation="${this.chatContext.selectedCitation}"
      .isCustomBranding="${this.isCustomBranding}"
      .svgIcon="${na}"
      .context="${this.chatContext}"
      @on-citation-click="${this.handleCitationClick}"
      @on-input="${this.handleInput}"
    >
    </chat-thread-component>`}renderChatInputComponents(n){return this.isResetInput||this.chatInputComponents===void 0?"":this.chatInputComponents.filter(e=>e.position===n).map(e=>e.render(this.setQuestionInputValue))}render(){var n,e,t,s,r;const i=(n=this.chatSectionControllers)==null?void 0:n.some(a=>a.isEnabled);return $`
      <div id="overlay" class="overlay ${i?"active":""}"></div>
      <section id="chat__containerWrapper" class="chat__containerWrapper ${i?"aside-open":""}">
        ${this.isCustomBranding&&!this.isChatStarted?$` <chat-stage
              svgIcon="${na}"
              pagetitle="${W.BRANDING_HEADLINE}"
              url="${W.BRANDING_URL}"
            >
            </chat-stage>`:""}
        <section class="chat__container" id="chat-container">
          ${this.isChatStarted?$`
                <div class="chat__header--thread">
                  ${(e=this.chatActionControllers)==null?void 0:e.map(a=>a.render(this.isDisabled))}
                  <chat-action-button
                    .label="${W.RESET_CHAT_BUTTON_TITLE}"
                    actionId="chat-reset-button"
                    @click="${this.resetCurrentChat}"
                    .svgIcon="${Id}"
                  >
                  </chat-action-button>
                </div>
                ${(t=this.chatThreadControllers)==null?void 0:t.map(a=>a.render(this.renderChatThread))}
                ${this.renderChatThread(this.chatThread)}
              `:""}
          ${this.chatController.isAwaitingResponse?$`<loading-indicator label="${W.LOADING_INDICATOR_TEXT}"></loading-indicator>`:""}
          <!-- Teaser List with Default Prompts -->
          <div class="chat__container">${this.renderChatInputComponents("top")}</div>
          <form
            id="chat-form"
            class="form__container ${this.inputPosition==="sticky"?"form__container-sticky":""}"
          >
            <div class="chatbox__container container-col container-row">
              <div class="chatbox__input-container display-flex-grow container-row">
                ${this.renderChatInputComponents("left")}
                <input
                  class="chatbox__input display-flex-grow"
                  data-testid="question-input"
                  id="question-input"
                  placeholder="${W.CHAT_INPUT_PLACEHOLDER}"
                  aria-labelledby="chatbox-label"
                  id="chatbox"
                  name="chatbox"
                  type="text"
                  :value=""
                  ?disabled="${this.isDisabled}"
                  autocomplete="off"
                  @keyup="${this.handleOnInputChange}"
                />
                ${this.renderChatInputComponents("right")}
              </div>
              ${this.renderChatOrCancelButton()}
              <button
                title="${W.RESET_BUTTON_TITLE_TEXT}"
                class="chatbox__button--reset"
                .hidden="${!this.isResetInput}"
                type="reset"
                id="resetBtn"
                title="Clear input"
                @click="${this.resetInputField}"
              >
                ${W.RESET_BUTTON_LABEL_TEXT}
              </button>
            </div>

            ${(s=this.chatInputFooterComponets)==null?void 0:s.map(a=>a.render(this.resetCurrentChat,this.isChatStarted))}
          </form>
        </section>
        ${i?(r=this.chatSectionControllers)==null?void 0:r.map(a=>a.render()):""}
      </section>
    `}};pe.styles=[Ed];ve([H({type:String,attribute:"data-input-position"})],pe.prototype,"inputPosition",2);ve([H({type:String,attribute:"data-interaction-model"})],pe.prototype,"interactionModel",1);ve([H({type:String,attribute:"data-api-url"})],pe.prototype,"apiUrl",1);ve([H({type:String,attribute:"data-custom-branding",converter:n=>(n==null?void 0:n.toLowerCase())==="true"})],pe.prototype,"isCustomBranding",2);ve([H({type:String,attribute:"data-use-stream",converter:n=>(n==null?void 0:n.toLowerCase())==="true"})],pe.prototype,"useStream",2);ve([H({type:String,attribute:"data-approach"})],pe.prototype,"approach",2);ve([H({type:String,attribute:"data-overrides",converter:n=>JSON.parse(n||"{}")})],pe.prototype,"overrides",2);ve([H({type:String,attribute:"data-custom-styles",converter:n=>JSON.parse(n||"{}")})],pe.prototype,"customStyles",2);ve([H({type:String,attribute:"data-chat-id"})],pe.prototype,"chatId",2);ve([H({type:String,attribute:"data-personality-id"})],pe.prototype,"personalityId",2);ve([H({type:String})],pe.prototype,"currentQuestion",2);ve([va("#question-input")],pe.prototype,"questionInput",2);ve([tn()],pe.prototype,"isDisabled",2);ve([tn()],pe.prototype,"isResetInput",2);ve([Rt(ne.ChatInput)],pe.prototype,"chatInputComponents",2);ve([Rt(ne.ChatInputFooter)],pe.prototype,"chatInputFooterComponets",2);ve([Rt(ne.ChatSection)],pe.prototype,"chatSectionControllers",2);ve([Rt(ne.ChatAction)],pe.prototype,"chatActionControllers",2);ve([Rt(ne.ChatThread)],pe.prototype,"chatThreadControllers",2);pe=ve([Ke("chat-component")],pe);const Gd="_container_c16l7_1",Yd={container:Gd},Zd=({className:n,onClick:e})=>o.jsxs("button",{className:`${Yd.container} ${n??""}`,onClick:e,"data-testid":"button__developer-settings",children:[o.jsx(io,{}),o.jsx(ts,{children:"Developer settings"})]}),Xd=({onChange:n})=>{const e={AccentHigh:"#692b61",AccentLight:"#f6d5f2",AccentDark:"#5e3c7d",TextColor:"#123f58",BackgroundColor:"#e3e3e3",ForegroundColor:"#4e5288",FormBackgroundColor:"#f5f5f5"},t={AccentHigh:"#dcdef8",AccentLight:"#032219",AccentDark:"#fdfeff",TextColor:"#fdfeff",BackgroundColor:"#e3e3e3",ForegroundColor:"#4e5288",FormBackgroundColor:"#32343e"},s=()=>{const l=localStorage.getItem("ms-azoaicc:customStyles"),h=localStorage.getItem("ms-azoaicc:isDarkTheme")==="true"?t:e;return l===""&&localStorage.setItem("ms-azoaicc:customStyles",JSON.stringify(h)),l?JSON.parse(l):{AccentHigh:h.AccentHigh,AccentLight:h.AccentLight,AccentDark:h.AccentDark,TextColor:h.TextColor,BackgroundColor:h.BackgroundColor,FormBackgroundColor:h.FormBackgroundColor,BorderRadius:"10px",BorderWidth:"3px",FontBaseSize:"14px"}},[r,i]=b.useState(s);b.useEffect(()=>{n(r)},[r,n]);const a=(l,c)=>{i(h=>({...h,[l]:c}))};return o.jsxs(o.Fragment,{children:[o.jsx("h3",{children:"Modify Styles"}),o.jsx("div",{className:"ms-style-picker colors",children:[{label:"Accent High",name:"AccentHigh",placeholder:"Accent high"},{label:"Accent Light",name:"AccentLight",placeholder:"Accent light"},{label:"Accent Dark",name:"AccentDark",placeholder:"Accent dark"},{label:"Text Color",name:"TextColor",placeholder:"Text color"},{label:"Background Color",name:"BackgroundColor",placeholder:"Background color"},{label:"Foreground Color",name:"ForegroundColor",placeholder:"Foreground color"},{label:"Form background",name:"FormBackgroundColor",placeholder:"Form Background color"}].map(l=>o.jsxs(Js.Fragment,{children:[o.jsx("label",{htmlFor:`accent-${l.name.toLowerCase()}-picker`,children:l.label}),o.jsx("input",{name:`accent-${l.name.toLowerCase()}-picker`,type:"color",placeholder:l.placeholder,value:r[l.name],onChange:c=>a(l.name,c.target.value)})]},l.name))}),o.jsx("div",{className:"ms-style-picker sliders",children:[{label:"Border Radius",name:"BorderRadius",min:0,max:25},{label:"Border Width",name:"BorderWidth",min:1,max:5},{label:"Font Base Size",name:"FontBaseSize",min:12,max:20}].map(l=>o.jsx(Js.Fragment,{children:o.jsxs("div",{className:"ms-settings-input-slider",children:[o.jsx("label",{htmlFor:`slider-${l.name.toLowerCase()}`,children:l.label}),o.jsx("input",{name:`slider-${l.name.toLowerCase()}`,type:"range",min:l.min,max:l.max,placeholder:`Slider for ${l.name.toLowerCase()}`,value:r[l.name],onChange:c=>a(l.name,`${c.target.value}px`)}),o.jsx("span",{className:"ms-setting-value",children:r[l.name]})]})},l.name))})]})},Qd=({onToggle:n,isDarkTheme:e,isConfigPanelOpen:t})=>{const s=()=>{n(!e)};return b.useEffect(()=>{document.body.classList.toggle("dark",e),document.documentElement.dataset.theme=e&&t?"dark":"",localStorage.removeItem("ms-azoaicc:isDarkTheme")},[e,t]),o.jsx("div",{className:"ms-toggle-wrapper",children:o.jsx(er,{label:"Select theme",onText:"Dark Theme",offText:"Light Theme",checked:e,onChange:s})})},Ye={approaches:"Retrieve first uses Azure Search. Read first uses LangChain.",promptTemplate:"Allows user to override the chatbot's prompt.",promptTemplatePrefix:"Allows user to provide a prefix to the chatbot's prompt. For example, `Answer the following question as if I were in high school.`",promptTemplateSuffix:"Allows user to provide a suffix to the chatbot's prompt. For example, `Return the first 50 words.`",retrieveNumber:"Number of results affecting final answer",excludeCategory:"Example categories include ...",useSemanticRanker:"Semantic ranker is a machine learning model to improve the relevance and accuracy of search results.",useQueryContextSummaries:"Can improve the relevance and accuracy of search results by providing a more concise and focused summary of the most relevant information related to the query or context.",suggestFollowupQuestions:"Provide follow-up questions to continue conversation.",retrievalMode:"The retrieval mode choices determine how the chatbot retrieves and ranks responses based on semantic similarity to the user's query. `Vectors + Text (Hybrid)` uses a combination of vector embeddings and text matching, `Vectors` uses only vector embeddings, and `Text` uses only text matching.",streamChat:"Continuously deliver responses as they are generated or wait until all responses are generated before delivering them."},Ze={styles:{beak:{background:"#D3D3D3"},beakCurtain:{background:"#D3D3D3"},calloutMain:{background:"#D3D3D3"}}},Kd="_container_121g3_1",Jd="_chatHeader_121g3_17",eh="_headerContent_121g3_35",th="_chatTitle_121g3_43",nh="_chatSubtitle_121g3_57",sh="_personalityDropdown_121g3_69",rh="_personalityLabel_121g3_81",ih="_personalitySelect_121g3_93",ah="_headerActions_121g3_111",oh="_settingsButton_121g3_121",lh="_chatContent_121g3_129",ch="_welcomeSection_121g3_143",dh="_welcomeText_121g3_153",hh="_starterPrompts_121g3_167",uh="_starterPromptCard_121g3_181",ph="_chatRoot_121g3_217",gh="_chatEmptyState_121g3_245",fh="_chatSettingsSeparator_121g3_397",mh="_loadingState_121g3_433",ee={container:Kd,chatHeader:Jd,headerContent:eh,chatTitle:th,chatSubtitle:nh,personalityDropdown:sh,personalityLabel:rh,personalitySelect:ih,headerActions:ah,settingsButton:oh,chatContent:lh,welcomeSection:ch,welcomeText:dh,starterPrompts:hh,starterPromptCard:uh,chatRoot:ph,chatEmptyState:gh,chatSettingsSeparator:fh,loadingState:mh},yh=["Help me set and achieve a goal","Improve my communication skills","Navigate a difficult conversation","Build better daily habits"],vh=()=>{const[n,e]=ao(),[t,s]=b.useState(!1),r=b.useRef(null),[i,a]=b.useState(),[l,c]=b.useState(!1),{user:h}=fn(),u=(h==null?void 0:h.role)==="admin",{personalities:g,selectedPersonalityId:p,setSelectedPersonalityId:v,isLoading:w}=ca();b.useEffect(()=>{const P=n.get("chatId");if(P){const M=Number.parseInt(P,10);!Number.isNaN(M)&&M!==i&&(a(M),L(M))}else a(void 0)},[n]),b.useEffect(()=>{const P=M=>{const{chatId:Se}=M.detail;Se&&!i&&(a(Se),e({chatId:Se.toString()}))};return window.addEventListener("chat-created",P),()=>{window.removeEventListener("chat-created",P)}},[i,e]);const L=async P=>{c(!0);try{const Se=(await bo(P)).messages||[];setTimeout(()=>{const He=r.current;if(He&&typeof He.loadMessages=="function"){const St=Se.map(et=>({role:et.role,content:et.content,citations:Array.isArray(et.citations)?et.citations:et.citations?JSON.parse(et.citations):[]}));He.loadMessages(St)}},100)}catch(M){console.error("Failed to load chat history:",M)}finally{c(!1)}},U=P=>{const M=r.current;M&&typeof M.sendMessage=="function"&&M.sendMessage(P)},[Q,B]=b.useState(""),[R,D]=b.useState(3),[se,re]=b.useState(pt.Hybrid),[ot,Pe]=b.useState(!0),[Ct,vn]=b.useState(!0),[me,Ot]=b.useState(!1),[Pt,Lt]=b.useState(""),[Dt,Mt]=b.useState(!0),sn=b.useRef(null),[lt,rn]=b.useState(()=>{const P=localStorage.getItem("ms-azoaicc:isBrandingEnabled");return P?JSON.parse(P):!1}),Bt=(P,M)=>{B(M||"")},ce=(P,M)=>{D(Number.parseInt(M||"3"))},Ht=(P,M,Se)=>{re((M==null?void 0:M.data)||pt.Hybrid)},N=(P,M)=>{Pe(!!M)},qe=(P,M)=>{Ot(!!M)},ie=(P,M)=>{vn(!!M)},K=(P,M)=>{Lt(M||"")},Ut=(P,M)=>{rn(!!M)},Je=(P,M)=>{Mt(!!M)},[Be,zt]=b.useState(()=>{const P=localStorage.getItem("ms-azoaicc:isDarkTheme");return P?JSON.parse(P):!1}),[ke,Ft]=b.useState(()=>{const Se=Be?{AccentHigh:"#dcdef8",AccentLight:"#032219",AccentDark:"#fdfeff",TextColor:"#fdfeff",BackgroundColor:"#32343e",ForegroundColor:"#4e5288",FormBackgroundColor:"#32343e",BorderRadius:"10px",BorderWidth:"3px",FontBaseSize:"14px"}:{AccentHigh:"#692b61",AccentLight:"#f6d5f2",AccentDark:"#5e3c7d",TextColor:"#123f58",BackgroundColor:"#e3e3e3",ForegroundColor:"#4e5288",FormBackgroundColor:"#f5f5f5",BorderRadius:"10px",BorderWidth:"3px",FontBaseSize:"14px"},He=localStorage.getItem("ms-azoaicc:customStyles");return He?JSON.parse(He):Se}),Le=P=>{Ft(P)},ct=P=>{const M=document.querySelector("chat-component");M&&(M.removeAttribute("style"),M.setAttribute("data-theme",P?"dark":"")),localStorage.removeItem("ms-azoaicc:customStyles"),zt(P)};b.useState(()=>{var P;localStorage.setItem("ms-azoaicc:customStyles",JSON.stringify(ke)),localStorage.setItem("ms-azoaicc:isBrandingEnabled",JSON.stringify(lt)),localStorage.setItem("ms-azoaicc:isDarkTheme",JSON.stringify(Be)),(P=sn.current)==null||P.scrollIntoView({behavior:"smooth"}),document.body.classList.toggle("dark",Be),document.documentElement.dataset.theme=Be?"dark":""});const[De,dt]=b.useState(!1),kt={retrieval_mode:se,top:R,semantic_ranker:ot,semantic_captions:me,exclude_category:Pt,prompt_template:Q,prompt_template_prefix:"",prompt_template_suffix:"",suggest_followup_questions:Dt};return o.jsxs("div",{className:ee.container,children:[o.jsxs("div",{className:ee.chatHeader,children:[o.jsxs("div",{className:ee.headerContent,children:[o.jsx("h1",{className:ee.chatTitle,children:"Your AI Coach"}),o.jsx("p",{className:ee.chatSubtitle,children:"Ready to help you grow, learn, and achieve your goals."}),g.length>0&&o.jsxs("div",{className:ee.personalityDropdown,children:[o.jsx("label",{htmlFor:"personality-select",className:ee.personalityLabel,children:"Personality:"}),o.jsxs("select",{id:"personality-select",className:ee.personalitySelect,value:p||"",onChange:P=>v(Number(P.target.value)),disabled:w,"aria-label":"Select coaching personality",children:[w&&o.jsx("option",{value:"",children:"Loading personalities..."}),!w&&g.map(P=>o.jsx("option",{value:P.id,children:P.name},P.id))]})]})]}),u&&o.jsx("div",{className:ee.headerActions,children:o.jsx(Zd,{className:ee.settingsButton,onClick:()=>s(!t)})})]}),o.jsxs("div",{className:ee.chatContent,children:[o.jsxs("div",{className:ee.welcomeSection,children:[o.jsxs("h2",{className:ee.welcomeText,children:["How can I help",h!=null&&h.name?`, ${h.name.split(" ")[0]}`:"","?"]}),o.jsx("div",{className:ee.starterPrompts,children:yh.map((P,M)=>o.jsx("button",{className:ee.starterPromptCard,onClick:()=>U(P),type:"button","aria-label":`Start conversation about: ${P}`,children:P},M))})]}),o.jsx("div",{className:ee.chatRoot,children:o.jsx("div",{className:ee.chatEmptyState,children:l?o.jsx("div",{className:ee.loadingState,children:"Loading chat history..."}):o.jsx("chat-component",{ref:r,title:"","data-input-position":"sticky","data-interaction-model":"chat","data-api-url":Z,"data-use-stream":Ct,"data-approach":"rrr","data-overrides":JSON.stringify(kt),"data-custom-styles":JSON.stringify(ke),"data-custom-branding":JSON.stringify(lt),"data-theme":Be?"dark":"","data-chat-id":(i==null?void 0:i.toString())||"","data-personality-id":(p==null?void 0:p.toString())||""})})})]}),o.jsxs(oo,{headerText:"Configure answer generation",isOpen:t,isBlocking:!1,onDismiss:()=>s(!1),closeButtonAriaLabel:"Close",onRenderFooterContent:()=>o.jsx(Ks,{onClick:()=>s(!1),children:"Close"}),isFooterAtBottom:!0,children:[o.jsx(Ge,{calloutProps:Ze,content:Ye.promptTemplate,children:o.jsx(Qd,{onToggle:ct,isDarkTheme:Be,isConfigPanelOpen:t})}),o.jsx(Ge,{calloutProps:Ze,content:Ye.promptTemplate,children:o.jsx(jt,{className:ee.chatSettingsSeparator,defaultValue:Q,label:"Override prompt template",multiline:!0,autoAdjustHeight:!0,onChange:Bt})}),o.jsx(Ge,{calloutProps:Ze,content:Ye.retrieveNumber,children:o.jsx(lo,{className:ee.chatSettingsSeparator,label:"Retrieve this many search results:",min:1,max:50,defaultValue:R.toString(),onChange:ce})}),o.jsx(Ge,{calloutProps:Ze,content:Ye.excludeCategory,children:o.jsx(jt,{className:ee.chatSettingsSeparator,label:"Exclude category",onChange:K})}),o.jsx(Ge,{calloutProps:Ze,content:Ye.useSemanticRanker,children:o.jsx(Gn,{className:ee.chatSettingsSeparator,checked:ot,label:"Use semantic ranker for retrieval",onChange:N})}),o.jsx(Ge,{calloutProps:Ze,content:Ye.useQueryContextSummaries,children:o.jsx(Gn,{className:ee.chatSettingsSeparator,checked:me,label:"Use query-contextual summaries instead of whole documents",onChange:qe,disabled:!ot})}),o.jsx(Ge,{calloutProps:Ze,content:Ye.suggestFollowupQuestions,children:o.jsx(Gn,{className:ee.chatSettingsSeparator,checked:Dt,label:"Suggest follow-up questions",onChange:Je})}),o.jsx(Ge,{calloutProps:Ze,content:Ye.retrievalMode,children:o.jsx(co,{className:ee.chatSettingsSeparator,label:"Retrieval mode",options:[{key:"hybrid",text:"Vectors + Text (Hybrid)",selected:se==pt.Hybrid,data:pt.Hybrid},{key:"vectors",text:"Vectors",selected:se==pt.Vectors,data:pt.Vectors},{key:"text",text:"Text",selected:se==pt.Text,data:pt.Text}],required:!0,onChange:Ht})}),o.jsx(Ge,{calloutProps:Ze,content:Ye.streamChat,children:o.jsx(Gn,{className:ee.chatSettingsSeparator,checked:Ct,label:"Stream chat completion responses",onChange:ie})}),o.jsxs("div",{children:[o.jsx(er,{label:"Customize chat styles",checked:De,onChange:()=>dt(!De)}),De&&o.jsx(o.Fragment,{children:o.jsx(Ge,{calloutProps:Ze,content:Ye.promptTemplate,children:o.jsx(Xd,{onChange:Le})})}),o.jsx(Ge,{calloutProps:Ze,content:Ye.promptTemplate,children:o.jsx(er,{label:"Enable Branding",checked:lt,onChange:Ut})})]})]})]})},bh="_authContainer_1dt5u_1",xh="_authCard_1dt5u_19",_h="_authHeader_1dt5u_39",wh="_authTitle_1dt5u_47",Ch="_authSubtitle_1dt5u_61",kh="_errorMessage_1dt5u_73",Sh="_selectRoleText_1dt5u_93",Ah="_roleGrid_1dt5u_105",Th="_roleButton_1dt5u_117",Nh="_roleButtonActive_1dt5u_169",jh="_roleIcon_1dt5u_179",Eh="_roleLabel_1dt5u_189",Ih="_roleDescription_1dt5u_203",$h="_loadingSpinner_1dt5u_213",Rh="_footerText_1dt5u_243",Oh="_authLink_1dt5u_257",ge={authContainer:bh,authCard:xh,authHeader:_h,authTitle:wh,authSubtitle:Ch,errorMessage:kh,selectRoleText:Sh,roleGrid:Ah,roleButton:Th,roleButtonActive:Nh,roleIcon:jh,roleLabel:Eh,roleDescription:Ih,loadingSpinner:$h,footerText:Rh,authLink:Oh},Ph=[{role:"coach",label:"Coach",icon:"🎓",description:"Guide clients through coaching"},{role:"client",label:"Client",icon:"💬",description:"Experience the coaching journey"},{role:"admin",label:"Admin",icon:"⚙️",description:"Full platform access"}];function Lh(){const[n,e]=b.useState(null),[t,s]=b.useState(""),{demoLoginWithRole:r}=fn(),i=jr(),a=async l=>{e(l),s("");try{await r(l),i("/")}catch(c){s(c.message||"Login failed"),e(null)}};return o.jsx("div",{className:ge.authContainer,children:o.jsxs("div",{className:ge.authCard,children:[o.jsxs("div",{className:ge.authHeader,children:[o.jsx("h1",{className:ge.authTitle,children:"🎯 Apex Coach AI"}),o.jsx("p",{className:ge.authSubtitle,children:"Your AI-powered coaching companion"})]}),t&&o.jsx("div",{className:ge.errorMessage,children:t}),o.jsx("p",{className:ge.selectRoleText,children:"Select a demo role to get started:"}),o.jsx("div",{className:ge.roleGrid,children:Ph.map(l=>o.jsx("button",{onClick:()=>a(l.role),disabled:n!==null,className:`${ge.roleButton} ${n===l.role?ge.roleButtonActive:""}`,children:n===l.role?o.jsx("div",{className:ge.loadingSpinner}):o.jsxs(o.Fragment,{children:[o.jsx("span",{className:ge.roleIcon,children:l.icon}),o.jsx("span",{className:ge.roleLabel,children:l.label}),o.jsx("span",{className:ge.roleDescription,children:l.description})]})},l.role))}),o.jsx("p",{className:ge.footerText,children:"No account needed • Instant access • Try all features"})]})})}function Dh(){const[n,e]=b.useState(""),[t,s]=b.useState(""),[r,i]=b.useState(""),[a,l]=b.useState(""),[c,h]=b.useState(!1),{signup:u}=fn(),g=jr(),p=async v=>{if(v.preventDefault(),l(""),t.length<8){l("Password must be at least 8 characters");return}h(!0);try{await u(n,t,r||void 0),g("/")}catch(w){l(w.message||"Signup failed")}finally{h(!1)}};return o.jsx("div",{className:ge.authContainer,children:o.jsx("div",{className:ge.authCard,children:o.jsxs(si,{tokens:{childrenGap:20},children:[o.jsxs("div",{className:ge.authHeader,children:[o.jsx(ts,{variant:"xxLarge",className:ge.authTitle,children:"Begin Your Journey"}),o.jsx(ts,{variant:"medium",className:ge.authSubtitle,children:"Create an account to unlock your potential"})]}),a&&o.jsx(Er,{messageBarType:tt.error,children:a}),o.jsx("form",{onSubmit:p,children:o.jsxs(si,{tokens:{childrenGap:15},children:[o.jsx(jt,{label:"Name (optional)",type:"text",value:r,onChange:(v,w)=>i(w||""),autoComplete:"name"}),o.jsx(jt,{label:"Email",type:"email",value:n,onChange:(v,w)=>e(w||""),required:!0,autoComplete:"email"}),o.jsx(jt,{label:"Password",type:"password",value:t,onChange:(v,w)=>s(w||""),required:!0,autoComplete:"new-password",description:"Must be at least 8 characters"}),o.jsx(cs,{text:c?"Creating account...":"Sign Up",type:"submit",disabled:c}),o.jsxs(ts,{variant:"small",className:ge.authLink,children:["Already have an account? ",o.jsx(aa,{to:"/login",children:"Sign in"})]})]})})]})})})}const Mh="_container_1bv2j_1",Bh="_loading_1bv2j_13",Hh="_title_1bv2j_31",Uh="_form_1bv2j_45",zh="_section_1bv2j_57",Fh="_sectionTitle_1bv2j_71",qh="_helpText_1bv2j_85",Vh="_formGroup_1bv2j_97",Wh="_label_1bv2j_113",Gh="_input_1bv2j_129",Yh="_select_1bv2j_131",Zh="_errorMessage_1bv2j_193",Xh="_successMessage_1bv2j_211",Qh="_actions_1bv2j_229",Kh="_saveButton_1bv2j_241",le={container:Mh,loading:Bh,title:Hh,form:Uh,section:zh,sectionTitle:Fh,helpText:qh,formGroup:Vh,label:Wh,input:Gh,select:Yh,errorMessage:Zh,successMessage:Xh,actions:Qh,saveButton:Kh};function Jh(){const{personalities:n,isLoading:e}=ca(),[t,s]=b.useState({userId:0,defaultPersonalityId:void 0,nickname:"",occupation:""}),[r,i]=b.useState(!0),[a,l]=b.useState(!1),[c,h]=b.useState(""),[u,g]=b.useState("");b.useEffect(()=>{async function v(){try{const w=await _o();s({userId:w.settings.userId,defaultPersonalityId:w.settings.defaultPersonalityId,nickname:w.settings.nickname||"",occupation:w.settings.occupation||""})}catch(w){console.error("Failed to load settings:",w),g("Failed to load settings. Please try again.")}finally{i(!1)}}v()},[]);const p=async v=>{v.preventDefault(),l(!0),h(""),g("");try{await wo({defaultPersonalityId:t.defaultPersonalityId,nickname:t.nickname||void 0,occupation:t.occupation||void 0}),h("Settings saved successfully!"),setTimeout(()=>h(""),3e3)}catch(w){console.error("Failed to save settings:",w),g("Failed to save settings. Please try again.")}finally{l(!1)}};return r||e?o.jsx("div",{className:le.container,children:o.jsx("div",{className:le.loading,children:"Loading settings..."})}):o.jsxs("div",{className:le.container,children:[o.jsx("h1",{className:le.title,children:"Settings"}),o.jsxs("form",{onSubmit:p,className:le.form,children:[n.length>0&&o.jsxs("section",{className:le.section,children:[o.jsx("h2",{className:le.sectionTitle,children:"Default Coaching Personality"}),o.jsx("p",{className:le.helpText,children:"This personality will be used for new chats by default. You can change it for any individual chat."}),o.jsxs("div",{className:le.formGroup,children:[o.jsx("label",{htmlFor:"defaultPersonality",className:le.label,children:"Default Personality"}),o.jsxs("select",{id:"defaultPersonality",className:le.select,value:t.defaultPersonalityId||"",onChange:v=>{const w=Number(v.target.value);s({...t,defaultPersonalityId:Number.isNaN(w)?void 0:w})},children:[o.jsx("option",{value:"",children:"None selected"}),n.map(v=>o.jsx("option",{value:v.id,children:v.name},v.id))]})]})]}),o.jsxs("section",{className:le.section,children:[o.jsx("h2",{className:le.sectionTitle,children:"Profile"}),o.jsx("p",{className:le.helpText,children:"Help your coach understand you better."}),o.jsxs("div",{className:le.formGroup,children:[o.jsx("label",{htmlFor:"nickname",className:le.label,children:"Preferred Name"}),o.jsx("input",{type:"text",id:"nickname",className:le.input,placeholder:"How would you like to be called?",value:t.nickname,onChange:v=>s({...t,nickname:v.target.value}),maxLength:100})]}),o.jsxs("div",{className:le.formGroup,children:[o.jsx("label",{htmlFor:"occupation",className:le.label,children:"Occupation"}),o.jsx("input",{type:"text",id:"occupation",className:le.input,placeholder:"What do you do?",value:t.occupation,onChange:v=>s({...t,occupation:v.target.value}),maxLength:200})]})]}),u&&o.jsx("div",{className:le.errorMessage,children:u}),c&&o.jsx("div",{className:le.successMessage,children:c}),o.jsx("div",{className:le.actions,children:o.jsx("button",{type:"submit",className:le.saveButton,disabled:a,children:a?"Saving...":"Save Settings"})})]})]})}const eu=()=>o.jsxs("div",{className:"flex h-screen bg-gray-100",children:[o.jsxs("div",{className:"w-64 bg-white shadow-md",children:[o.jsx("div",{className:"p-4",children:o.jsx("h1",{className:"text-2xl font-bold",children:"Admin"})}),o.jsx("nav",{children:o.jsxs("ul",{children:[o.jsx("li",{children:o.jsx(Yt,{to:"/admin/people",className:"block p-4 hover:bg-gray-200",children:"People"})}),o.jsx("li",{children:o.jsx(Yt,{to:"/admin/programs",className:"block p-4 hover:bg-gray-200",children:"Programs"})}),o.jsx("li",{children:o.jsx(Yt,{to:"/admin/knowledge-base",className:"block p-4 hover:bg-gray-200",children:"Knowledge Base"})}),o.jsx("li",{children:o.jsx(Yt,{to:"/admin/meta-prompts",className:"block p-4 hover:bg-gray-200",children:"Meta Prompts"})}),o.jsx("li",{children:o.jsx(Yt,{to:"/admin/analytics",className:"block p-4 hover:bg-gray-200",children:"Analytics"})}),o.jsx("li",{children:o.jsx(Yt,{to:"/admin/white-label",className:"block p-4 hover:bg-gray-200",children:"White Label"})}),o.jsx("li",{children:o.jsx(Yt,{to:"/admin/action-logs",className:"block p-4 hover:bg-gray-200",children:"Action Logs"})})]})})]}),o.jsx("div",{className:"flex-1 p-8",children:o.jsx(ia,{})})]}),tu=()=>{const[n,e]=b.useState([]),[t,s]=b.useState(!0);b.useEffect(()=>{r()},[]);const r=async()=>{s(!0);try{const a=await fetch(`${Z}/api/admin/users`,{credentials:"include"});if(a.ok){const l=await a.json();e(l)}}catch(a){console.error("Failed to fetch users:",a)}finally{s(!1)}},i=async(a,l)=>{try{await fetch(`${Z}/api/admin/users/${a}/role`,{method:"PUT",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify({role:l})}),r()}catch(c){console.error("Failed to update user role:",c)}};return o.jsx("div",{children:t?o.jsx("p",{children:"Loading..."}):o.jsxs("table",{className:"min-w-full bg-white",children:[o.jsx("thead",{children:o.jsxs("tr",{children:[o.jsx("th",{className:"py-2",children:"Name"}),o.jsx("th",{className:"py-2",children:"Email"}),o.jsx("th",{className:"py-2",children:"Role"}),o.jsx("th",{className:"py-2",children:"Created At"})]})}),o.jsx("tbody",{children:n.map(a=>o.jsxs("tr",{children:[o.jsx("td",{className:"border px-4 py-2",children:a.name||"-"}),o.jsx("td",{className:"border px-4 py-2",children:a.email}),o.jsx("td",{className:"border px-4 py-2",children:o.jsxs("select",{value:a.role,onChange:l=>i(a.id,l.target.value),children:[o.jsx("option",{value:"admin",children:"Admin"}),o.jsx("option",{value:"coach",children:"Coach"}),o.jsx("option",{value:"user",children:"User"})]})}),o.jsx("td",{className:"border px-4 py-2",children:new Date(a.created_at).toLocaleDateString()})]},a.id))})]})})},nu=()=>{const[n,e]=b.useState([]),[t,s]=b.useState(!0);b.useEffect(()=>{r()},[]);const r=async()=>{s(!0);try{const a=await fetch(`${Z}/api/admin/invitations`,{credentials:"include"});if(a.ok){const l=await a.json();e(l)}}catch(a){console.error("Failed to fetch invitations:",a)}finally{s(!1)}},i=async a=>{try{await fetch(`${Z}/api/admin/invitations/${a}/cancel`,{method:"POST",credentials:"include"}),r()}catch(l){console.error("Failed to cancel invitation:",l)}};return o.jsxs("div",{children:[o.jsx("h2",{className:"text-xl font-bold mb-4",children:"Invitations"}),t?o.jsx("p",{children:"Loading..."}):o.jsxs("table",{className:"min-w-full bg-white",children:[o.jsx("thead",{children:o.jsxs("tr",{children:[o.jsx("th",{className:"py-2",children:"Email"}),o.jsx("th",{className:"py-2",children:"Role"}),o.jsx("th",{className:"py-2",children:"Status"}),o.jsx("th",{className:"py-2",children:"Created At"}),o.jsx("th",{className:"py-2",children:"Actions"})]})}),o.jsx("tbody",{children:n.map(a=>o.jsxs("tr",{children:[o.jsx("td",{className:"border px-4 py-2",children:a.email}),o.jsx("td",{className:"border px-4 py-2",children:a.role}),o.jsx("td",{className:"border px-4 py-2",children:a.status}),o.jsx("td",{className:"border px-4 py-2",children:new Date(a.created_at).toLocaleDateString()}),o.jsx("td",{className:"border px-4 py-2",children:o.jsx("button",{onClick:()=>i(a.id),children:"Cancel"})})]},a.id))})]})]})},su=()=>{const[n,e]=b.useState("members");return o.jsxs("div",{children:[o.jsx("h1",{className:"text-2xl font-bold mb-4",children:"People"}),o.jsxs("div",{className:"flex mb-4",children:[o.jsx("button",{className:`py-2 px-4 ${n==="members"?"border-b-2 border-black":""}`,onClick:()=>e("members"),children:"Members"}),o.jsx("button",{className:`py-2 px-4 ${n==="invitations"?"border-b-2 border-black":""}`,onClick:()=>e("invitations"),children:"Invitations"})]}),n==="members"?o.jsx(tu,{}):o.jsx(nu,{})]})},ru=()=>{const[n,e]=b.useState([]),[t,s]=b.useState(!0),[r,i]=b.useState(""),[a,l]=b.useState("");b.useEffect(()=>{c()},[]);const c=async()=>{s(!0);try{const u=await fetch(`${Z}/api/admin/programs`,{credentials:"include"});if(u.ok){const g=await u.json();e(g)}}catch(u){console.error("Failed to fetch programs:",u)}finally{s(!1)}},h=async u=>{u.preventDefault();try{await fetch(`${Z}/api/admin/programs`,{method:"POST",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:r,description:a})}),i(""),l(""),c()}catch(g){console.error("Failed to create program:",g)}};return o.jsxs("div",{children:[o.jsx("h1",{className:"text-2xl font-bold mb-4",children:"Programs"}),o.jsx("div",{className:"mb-4",children:o.jsxs("form",{onSubmit:h,children:[o.jsx("input",{type:"text",placeholder:"Program Name",value:r,onChange:u=>i(u.target.value),className:"border p-2 mr-2"}),o.jsx("input",{type:"text",placeholder:"Program Description",value:a,onChange:u=>l(u.target.value),className:"border p-2 mr-2"}),o.jsx("button",{type:"submit",className:"bg-black text-white p-2",children:"Add Program"})]})}),t?o.jsx("p",{children:"Loading..."}):o.jsxs("table",{className:"min-w-full bg-white",children:[o.jsx("thead",{children:o.jsxs("tr",{children:[o.jsx("th",{className:"py-2",children:"Name"}),o.jsx("th",{className:"py-2",children:"Description"})]})}),o.jsx("tbody",{children:n.map(u=>o.jsxs("tr",{children:[o.jsx("td",{className:"border px-4 py-2",children:o.jsx(aa,{to:`/admin/programs/${u.id}`,children:u.name})}),o.jsx("td",{className:"border px-4 py-2",children:u.description||"-"})]},u.id))})]})]})},iu=()=>{const{id:n}=ho(),[e,t]=b.useState(void 0),[s,r]=b.useState([]),[i,a]=b.useState(!0);b.useEffect(()=>{l(),c()},[n]);const l=async()=>{try{const h=await fetch(`${Z}/api/admin/programs/${n}`,{credentials:"include"});if(h.ok){const u=await h.json();t(u)}}catch(h){console.error("Failed to fetch program:",h)}},c=async()=>{a(!0);try{const h=await fetch(`${Z}/api/admin/programs/${n}/assignments`,{credentials:"include"});if(h.ok){const u=await h.json();r(u)}}catch(h){console.error("Failed to fetch assignments:",h)}finally{a(!1)}};return o.jsxs("div",{children:[o.jsx("h1",{className:"text-2xl font-bold mb-4",children:e==null?void 0:e.name}),o.jsx("p",{className:"mb-4",children:e==null?void 0:e.description}),o.jsx("h2",{className:"text-xl font-bold mb-4",children:"Assignments"}),i?o.jsx("p",{children:"Loading..."}):o.jsx("ul",{children:s.map(h=>o.jsxs("li",{children:["User ",h.user_id," - ",h.role]},h.id))})]})},au=()=>{const[n,e]=b.useState(void 0),[t,s]=b.useState(!0);b.useEffect(()=>{r()},[]);const r=async()=>{s(!0);try{const i=await fetch(`${Z}/api/admin/knowledge-base`,{credentials:"include"});if(i.ok){const a=await i.json();e(a)}}catch(i){console.error("Failed to fetch knowledge base overview:",i)}finally{s(!1)}};return o.jsxs("div",{children:[o.jsx("h1",{className:"text-2xl font-bold mb-4",children:"Knowledge Base Overview"}),t?o.jsx("p",{children:"Loading..."}):n?o.jsxs("div",{children:[o.jsxs("div",{className:"grid grid-cols-4 gap-4 mb-4",children:[o.jsxs("div",{className:"bg-white p-4 shadow",children:[o.jsx("h2",{className:"text-lg font-bold",children:"Total Resources"}),o.jsx("p",{className:"text-2xl",children:n.totalResources})]}),o.jsxs("div",{className:"bg-white p-4 shadow",children:[o.jsx("h2",{className:"text-lg font-bold",children:"Trained Documents"}),o.jsx("p",{className:"text-2xl",children:n.trainedDocuments})]}),o.jsxs("div",{className:"bg-white p-4 shadow",children:[o.jsx("h2",{className:"text-lg font-bold",children:"Pending/Processing"}),o.jsx("p",{className:"text-2xl",children:n.pendingDocuments})]}),o.jsxs("div",{className:"bg-white p-4 shadow",children:[o.jsx("h2",{className:"text-lg font-bold",children:"Failed"}),o.jsx("p",{className:"text-2xl",children:n.failedDocuments})]})]}),o.jsxs("table",{className:"min-w-full bg-white",children:[o.jsx("thead",{children:o.jsxs("tr",{children:[o.jsx("th",{className:"py-2",children:"Resource Title"}),o.jsx("th",{className:"py-2",children:"Type"}),o.jsx("th",{className:"py-2",children:"Program"}),o.jsx("th",{className:"py-2",children:"Status"}),o.jsx("th",{className:"py-2",children:"Created At"}),o.jsx("th",{className:"py-2",children:"Updated At"})]})}),o.jsx("tbody",{children:n.documents.map(i=>o.jsxs("tr",{children:[o.jsx("td",{className:"border px-4 py-2",children:i.resource_title}),o.jsx("td",{className:"border px-4 py-2",children:i.type}),o.jsx("td",{className:"border px-4 py-2",children:i.program||"-"}),o.jsx("td",{className:"border px-4 py-2",children:i.status}),o.jsx("td",{className:"border px-4 py-2",children:new Date(i.created_at).toLocaleDateString()}),o.jsx("td",{className:"border px-4 py-2",children:new Date(i.updated_at).toLocaleDateString()})]},i.id))})]})]}):o.jsx("p",{children:"Failed to load overview."})]})},ou=()=>o.jsxs("div",{children:[o.jsx("h1",{className:"text-2xl font-bold",children:"Meta Prompts"}),o.jsx("p",{children:"Manage meta prompts."})]}),sa=()=>{const[n,e]=b.useState(void 0),[t,s]=b.useState(!0),[r,i]=b.useState("7d");return b.useEffect(()=>{(async()=>{s(!0);try{const l=await fetch(`${Z}/api/admin/analytics?range=${r}`,{credentials:"include"});if(l.ok){const c=await l.json();e(c)}}catch(l){console.error("Failed to fetch analytics snapshot:",l)}finally{s(!1)}})()},[r]),o.jsxs("div",{children:[o.jsx("h1",{className:"text-2xl font-bold mb-4",children:"Analytics"}),o.jsx("div",{className:"mb-4",children:o.jsxs("select",{value:r,onChange:a=>i(a.target.value),children:[o.jsx("option",{value:"7d",children:"Last 7 Days"}),o.jsx("option",{value:"30d",children:"Last 30 Days"}),o.jsx("option",{value:"90d",children:"Last 90 Days"}),o.jsx("option",{value:"365d",children:"Last Year"})]})}),t?o.jsx("p",{children:"Loading..."}):n?o.jsxs("div",{className:"grid grid-cols-5 gap-4",children:[o.jsxs("div",{className:"bg-white p-4 shadow",children:[o.jsx("h2",{className:"text-lg font-bold",children:"Total Users"}),o.jsx("p",{className:"text-2xl",children:n.totalUsers})]}),o.jsxs("div",{className:"bg-white p-4 shadow",children:[o.jsx("h2",{className:"text-lg font-bold",children:"Active Users"}),o.jsx("p",{className:"text-2xl",children:n.activeUsers})]}),o.jsxs("div",{className:"bg-white p-4 shadow",children:[o.jsx("h2",{className:"text-lg font-bold",children:"Total Chats"}),o.jsx("p",{className:"text-2xl",children:n.totalChats})]}),o.jsxs("div",{className:"bg-white p-4 shadow",children:[o.jsx("h2",{className:"text-lg font-bold",children:"Messages"}),o.jsx("p",{className:"text-2xl",children:n.messagesInPeriod})]}),o.jsxs("div",{className:"bg-white p-4 shadow",children:[o.jsx("h2",{className:"text-lg font-bold",children:"Resources Ingested"}),o.jsx("p",{className:"text-2xl",children:n.resourcesIngestedInPeriod})]})]}):o.jsx("p",{children:"Failed to load analytics snapshot."})]})},lu=()=>{const[n,e]=b.useState(null),[t,s]=b.useState(!0),[r,i]=b.useState(!1),[a,l]=b.useState(null),[c,h]=b.useState(""),[u,g]=b.useState(""),[p,v]=b.useState(""),[w,L]=b.useState("");b.useEffect(()=>{U()},[]);const U=async()=>{try{s(!0);const R=await fetch(`${Z}/api/white-label-settings`,{credentials:"include"});if(R.ok){const D=await R.json();e(D),h(D.logoUrl||""),g(D.brandColor||""),v(D.appName||""),L(D.customCss||"")}}catch(R){console.error("Failed to load white label settings:",R),l({type:tt.error,text:"Failed to load settings"})}finally{s(!1)}},Q=async()=>{try{i(!0),l(null);const R=await fetch(`${Z}/api/white-label-settings`,{method:"PUT",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify({logoUrl:c||null,brandColor:u||null,appName:p||null,customCss:w||null})});if(R.ok){const D=await R.json();e(D),l({type:tt.success,text:"Settings saved successfully!"})}else{const D=await R.json();l({type:tt.error,text:D.error||"Failed to save settings"})}}catch(R){console.error("Failed to save white label settings:",R),l({type:tt.error,text:"Failed to save settings"})}finally{i(!1)}},B=async()=>{if(window.confirm("Are you sure you want to reset all white label settings to default?"))try{i(!0),l(null);const R=await fetch(`${Z}/api/white-label-settings`,{method:"DELETE",credentials:"include"});if(R.ok)h(""),g(""),v(""),L(""),l({type:tt.success,text:"Settings reset to default"});else{const D=await R.json();l({type:tt.error,text:D.error||"Failed to reset settings"})}}catch(R){console.error("Failed to reset white label settings:",R),l({type:tt.error,text:"Failed to reset settings"})}finally{i(!1)}};return t?o.jsx("div",{className:"flex justify-center items-center h-64",children:o.jsx(Tr,{size:Nr.large,label:"Loading settings..."})}):o.jsxs("div",{className:"max-w-4xl",children:[o.jsxs("div",{className:"mb-6",children:[o.jsx("h2",{className:"text-2xl font-bold mb-2",children:"White Label Settings"}),o.jsx("p",{className:"text-gray-600",children:"Customize the branding and appearance of your application"})]}),a&&o.jsx(Er,{messageBarType:a.type,onDismiss:()=>l(null),className:"mb-4",children:a.text}),o.jsxs("div",{className:"bg-white shadow rounded-lg p-6 space-y-6",children:[o.jsx("div",{children:o.jsx(jt,{label:"Application Name",value:p,onChange:(R,D)=>v(D||""),placeholder:"Apex Coach AI",description:"The name that appears in the application header and title"})}),o.jsxs("div",{children:[o.jsx(jt,{label:"Logo URL",value:c,onChange:(R,D)=>h(D||""),placeholder:"https://example.com/logo.png",description:"URL to your logo image (recommended: PNG or SVG, max height 48px)"}),c&&o.jsxs("div",{className:"mt-2",children:[o.jsx("p",{className:"text-sm text-gray-600 mb-2",children:"Preview:"}),o.jsx("img",{src:c,alt:"Logo preview",className:"max-h-12",onError:()=>l({type:tt.warning,text:"Failed to load logo image"})})]})]}),o.jsxs("div",{children:[o.jsx("label",{className:"block text-sm font-medium mb-2",children:"Brand Color"}),o.jsxs("div",{className:"flex items-center gap-4",children:[o.jsx("input",{type:"color",value:u||"#0078D4",onChange:R=>g(R.target.value),className:"h-11 w-20 border border-gray-300 rounded cursor-pointer"}),o.jsx(jt,{value:u,onChange:(R,D)=>g(D||""),placeholder:"#0078D4",styles:{root:{width:120}}}),o.jsx("span",{className:"text-sm text-gray-600",children:"Primary brand color for buttons and accents"})]})]}),o.jsxs("div",{children:[o.jsx("label",{className:"block text-sm font-medium mb-2",children:"Custom CSS"}),o.jsx("textarea",{value:w,onChange:R=>L(R.target.value),placeholder:`/* Add custom CSS styles here */\r
.custom-class {\r
  /* your styles */\r
}`,rows:10,className:"w-full p-3 border border-gray-300 rounded font-mono text-sm"}),o.jsx("p",{className:"text-sm text-gray-600 mt-2",children:"Advanced: Add custom CSS to further customize the appearance"})]}),o.jsxs("div",{className:"flex gap-3 pt-4 border-t",children:[o.jsx(cs,{text:r?"Saving...":"Save Settings",onClick:Q,disabled:r}),o.jsx(cs,{text:"Reset to Default",onClick:B,disabled:r})]}),n&&o.jsxs("div",{className:"text-sm text-gray-500 pt-4 border-t",children:["Last updated: ",new Date(n.updatedAt).toLocaleString()]})]})]})},cu=()=>{const[n,e]=b.useState([]),[t,s]=b.useState(!0),[r,i]=b.useState(null),[a,l]=b.useState(1),[c]=b.useState(50);b.useEffect(()=>{h()},[a]);const h=async()=>{try{s(!0),i(null);const p=await fetch(`${Z}/api/admin-action-logs?limit=${c}&offset=${(a-1)*c}`,{credentials:"include"});if(p.ok){const v=await p.json();e(v.logs||[])}else{const v=await p.json();i(v.error||"Failed to load action logs")}}catch(p){console.error("Failed to load action logs:",p),i("Failed to load action logs")}finally{s(!1)}},u=p=>p.split("_").map(v=>v.charAt(0).toUpperCase()+v.slice(1)).join(" "),g=p=>p.includes("create")?"text-green-600 bg-green-50":p.includes("update")?"text-blue-600 bg-blue-50":p.includes("delete")||p.includes("cancel")?"text-red-600 bg-red-50":"text-gray-600 bg-gray-50";return t&&n.length===0?o.jsx("div",{className:"flex justify-center items-center h-64",children:o.jsx(Tr,{size:Nr.large,label:"Loading action logs..."})}):o.jsxs("div",{children:[o.jsxs("div",{className:"mb-6",children:[o.jsx("h2",{className:"text-2xl font-bold mb-2",children:"Admin Action Logs"}),o.jsx("p",{className:"text-gray-600",children:"View all administrative actions performed in the system"})]}),r&&o.jsx(Er,{messageBarType:tt.error,onDismiss:()=>i(null),className:"mb-4",children:r}),o.jsx("div",{className:"bg-white shadow rounded-lg overflow-hidden",children:n.length===0?o.jsx("div",{className:"p-8 text-center text-gray-500",children:"No action logs found"}):o.jsxs(o.Fragment,{children:[o.jsx("div",{className:"overflow-x-auto",children:o.jsxs("table",{className:"w-full",children:[o.jsx("thead",{className:"bg-gray-50 border-b",children:o.jsxs("tr",{children:[o.jsx("th",{className:"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Timestamp"}),o.jsx("th",{className:"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Action"}),o.jsx("th",{className:"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",children:"User ID"}),o.jsx("th",{className:"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Entity"}),o.jsx("th",{className:"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Description"})]})}),o.jsx("tbody",{className:"bg-white divide-y divide-gray-200",children:n.map(p=>o.jsxs("tr",{className:"hover:bg-gray-50",children:[o.jsx("td",{className:"px-6 py-4 whitespace-nowrap text-sm text-gray-500",children:new Date(p.created_at).toLocaleString()}),o.jsx("td",{className:"px-6 py-4 whitespace-nowrap",children:o.jsx("span",{className:`inline-flex px-2 py-1 text-xs font-medium rounded ${g(p.action)}`,children:u(p.action)})}),o.jsx("td",{className:"px-6 py-4 whitespace-nowrap text-sm text-gray-900",children:p.user_id}),o.jsx("td",{className:"px-6 py-4 whitespace-nowrap text-sm text-gray-500",children:p.entity_type&&p.entity_id?o.jsxs("span",{children:[p.entity_type," #",p.entity_id]}):o.jsx("span",{className:"text-gray-400",children:"-"})}),o.jsx("td",{className:"px-6 py-4 text-sm text-gray-900",children:o.jsx("div",{className:"max-w-md",children:p.description||o.jsx("span",{className:"text-gray-400",children:"No description"})})})]},p.id))})]})}),o.jsxs("div",{className:"px-6 py-4 border-t border-gray-200 flex justify-between items-center",children:[o.jsxs("div",{className:"text-sm text-gray-500",children:["Page ",a," • ",n.length," logs"]}),o.jsxs("div",{className:"flex gap-2",children:[o.jsx("button",{onClick:()=>l(p=>Math.max(1,p-1)),disabled:a===1,className:"px-3 py-1 text-sm border border-gray-300 rounded hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed",children:"Previous"}),o.jsx("button",{onClick:()=>l(p=>p+1),disabled:n.length<c,className:"px-3 py-1 text-sm border border-gray-300 rounded hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed",children:"Next"})]})]})]})})]})},du=({children:n})=>{const{user:e,loading:t}=fn();return t?o.jsx("div",{children:"Loading..."}):!e||e.role!=="admin"?o.jsx(ra,{to:"/"}):o.jsx(o.Fragment,{children:n})};uo();const hu=po([{path:"/login",element:o.jsx(Lh,{})},{path:"/signup",element:o.jsx(Dh,{})},{path:"/",element:o.jsx(So,{children:o.jsx(Yo,{})}),children:[{index:!0,element:o.jsx(vh,{})},{path:"settings",element:o.jsx(Jh,{})},{path:"qa",lazy:()=>ii(()=>import("./OneShot-Dxo89WPn.js"),__vite__mapDeps([0,1,2]))},{path:"*",lazy:()=>ii(()=>import("./NoPage-BMxcsfhS.js"),__vite__mapDeps([3,1]))}]},{path:"/admin",element:o.jsx(du,{children:o.jsx(eu,{})}),children:[{index:!0,element:o.jsx(sa,{})},{path:"people",element:o.jsx(su,{})},{path:"programs",element:o.jsx(ru,{})},{path:"programs/:id",element:o.jsx(iu,{})},{path:"knowledge-base",element:o.jsx(au,{})},{path:"meta-prompts",element:o.jsx(ou,{})},{path:"analytics",element:o.jsx(sa,{})},{path:"white-label",element:o.jsx(lu,{})},{path:"action-logs",element:o.jsx(cu,{})}]}]);go.createRoot(document.getElementById("root")).render(o.jsx(Js.StrictMode,{children:o.jsx(Co,{children:o.jsx(ko,{children:o.jsx(fo,{router:hu})})})}));export{vo as A,pt as R,Zd as S,Z as a,Ze as b,Ye as t};
//# sourceMappingURL=index-CSZfEXA3.js.map

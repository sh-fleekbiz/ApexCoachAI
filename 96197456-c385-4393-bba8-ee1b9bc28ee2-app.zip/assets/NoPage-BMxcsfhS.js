import{j as o}from"./vendor-9NzPy1Pf.js";function e(){return o.jsx("h1",{children:"404"})}e.displayName="NoPage";export{e as Component};
//# sourceMappingURL=NoPage-BMxcsfhS.js.map
